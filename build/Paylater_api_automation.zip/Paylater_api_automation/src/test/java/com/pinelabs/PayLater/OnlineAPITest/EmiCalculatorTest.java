package com.pinelabs.PayLater.OnlineAPITest;

import com.pinelabs.PayLater.API.Helpers.BaseUtils;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.API.Helpers.RetryTest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.EmiCalculatorRequest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.IppOfferRequest;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.EmiCalculatorResponse;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.IppOfferResponse;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceOnlineAPI;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import static com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.EmiCalculatorResponse.assertCalculatedValue;
import static com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.EmiCalculatorResponse.assertEmiCalculatorValueWithIppOffer;

public class EmiCalculatorTest extends BaseUtils {
    @BeforeSuite
    public void setReportName(){
        System.setProperty("ReportName","OnlineAPI");
    }
    private ResponseServiceOnlineAPI responseServiceOnlineAPI;
    @BeforeClass
    public void beforeClass() {
        responseServiceOnlineAPI = new ResponseServiceOnlineAPI();
    }

    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void emiCalculatorPositiveWhenInstallmentConfigTypeBank(HashMap<Object,Object> input) throws Exception {
        EmiCalculatorRequest emiCalculatorRequest = new EmiCalculatorRequest.Builder()
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .installmentConfigId(input.get("bankInstallmentConfigId").toString())
                .installmentConfigType("BANK")
                .issuerId(input.get("issuerId").toString()).terminalId(input.get("terminalId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .merchantCurrencyCode(input.get("merchantCurrencyCode").toString())
                .issuerCurrencyCode(input.get("issuerCurrencyCode").toString())
                .issuerCountryCodeNum(Integer.parseInt(input.get("issuerCountryCodeNum").toString())).build();

        EmiCalculatorResponse emiCalculatorResponse = responseServiceOnlineAPI.emiCalculatorRequest(emiCalculatorRequest, token());
        Assert.assertEquals(emiCalculatorResponse.getStatusCode(),200);
        Assert.assertEquals(emiCalculatorResponse.getAttrs()[14].getValue(),"BANK");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void emiCalculatorPositiveWhenInstallmentConfigTypeMerchant(HashMap<Object,Object> input) throws Exception {
        EmiCalculatorRequest emiCalculatorRequest = new EmiCalculatorRequest.Builder()
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .installmentConfigId(input.get("merchantInstallmentConfigId").toString())
                .installmentConfigType("MERCHANT")
                .issuerId(input.get("issuerId").toString()).terminalId(input.get("terminalId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .merchantCurrencyCode(input.get("merchantCurrencyCode").toString())
                .issuerCurrencyCode(input.get("issuerCurrencyCode").toString())
                .issuerCountryCodeNum(Integer.parseInt(input.get("issuerCountryCodeNum").toString())).build();

        EmiCalculatorResponse emiCalculatorResponse = responseServiceOnlineAPI.emiCalculatorRequest(emiCalculatorRequest, token());
        Assert.assertEquals(emiCalculatorResponse.getStatusCode(),200);
        Assert.assertEquals(emiCalculatorResponse.getAttrs()[18].getValue(),"MERCHANT");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void emiCalculatorFieldsComparisonWithIppOfferConfigTypeMerchant(HashMap<Object,Object> input) throws Exception {
        double amount=Double.parseDouble(input.get("totalAmount").toString());
        // EmiCalculator
        EmiCalculatorRequest emiCalculatorRequest = new EmiCalculatorRequest.Builder()
                .amount(amount)
                .installmentConfigId(input.get("merchantInstallmentConfigId").toString())
                .installmentConfigType("MERCHANT")
                .issuerId(input.get("issuerId").toString()).terminalId(input.get("terminalId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .merchantCurrencyCode(input.get("merchantCurrencyCode").toString())
                .issuerCurrencyCode(input.get("issuerCurrencyCode").toString())
                .issuerCountryCodeNum(Integer.parseInt(input.get("issuerCountryCodeNum").toString())).build();

        EmiCalculatorResponse emiCalculatorResponse = responseServiceOnlineAPI.emiCalculatorRequest(emiCalculatorRequest, token());
        Assert.assertEquals(emiCalculatorResponse.getStatusCode(),200);
        Assert.assertEquals(emiCalculatorResponse.getAttrs()[18].getValue(),"MERCHANT");
        assertEmiCalculatorValueWithIppOffer(input, emiCalculatorResponse,token(),responseServiceOnlineAPI,amount);
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void emiCalculatorFieldsComparisonWithIppOfferConfigTypeBank(HashMap<Object,Object> input) throws Exception {
        double amount=Double.parseDouble(input.get("totalBankAmount").toString());
        // EmiCalculator
        EmiCalculatorRequest emiCalculatorRequest = new EmiCalculatorRequest.Builder()
                .amount(amount)
                .installmentConfigId(input.get("bankInstallmentConfigId").toString())
                .installmentConfigType("BANK")
                .issuerId(input.get("issuerId").toString()).terminalId(input.get("terminalId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .merchantCurrencyCode(input.get("merchantCurrencyCode").toString())
                .issuerCurrencyCode(input.get("issuerCurrencyCode").toString())
                .issuerCountryCodeNum(Integer.parseInt(input.get("issuerCountryCodeNum").toString())).build();

        EmiCalculatorResponse emiCalculatorResponse = responseServiceOnlineAPI.emiCalculatorRequest(emiCalculatorRequest, token());
        Assert.assertEquals(emiCalculatorResponse.getStatusCode(),200);
        Assert.assertEquals(emiCalculatorResponse.getAttrs()[14].getValue(),"BANK");
        assertEmiCalculatorValueWithIppOffer(input,emiCalculatorResponse,token(),responseServiceOnlineAPI,amount);
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void emiCalculatorWithInvalidAmount(HashMap<Object,Object> input) throws Exception {
           EmiCalculatorRequest emiCalculatorRequest = new EmiCalculatorRequest.Builder()
                   .amount(0)
                   .installmentConfigId(input.get("merchantInstallmentConfigId").toString())
                   .installmentConfigType("MERCHANT")
                   .issuerId(input.get("issuerId").toString()).terminalId(input.get("terminalId").toString())
                   .tenure(Integer.parseInt(input.get("tenure").toString()))
                   .merchantCurrencyCode(input.get("merchantCurrencyCode").toString())
                   .issuerCurrencyCode(input.get("issuerCurrencyCode").toString())
                   .issuerCountryCodeNum(Integer.parseInt(input.get("issuerCountryCodeNum").toString())).build();

        EmiCalculatorResponse emiCalculatorResponse = responseServiceOnlineAPI.emiCalculatorRequest(emiCalculatorRequest, token());
        Assert.assertEquals(emiCalculatorResponse.getStatusCode(),400);
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getCode(),"ERROR_1082");
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getMessage(),"invalid Amount");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void emiCalculatorwithInvalidInstalmentConfigIdShouldShowError(HashMap<Object,Object> input) throws Exception {
        EmiCalculatorRequest emiCalculatorRequest = new EmiCalculatorRequest.Builder()
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .installmentConfigId("342")
                .installmentConfigType("BANK")
                .issuerId(input.get("issuerId").toString()).terminalId(input.get("terminalId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .merchantCurrencyCode(input.get("merchantCurrencyCode").toString())
                .issuerCurrencyCode(input.get("issuerCurrencyCode").toString())
                .issuerCountryCodeNum(Integer.parseInt(input.get("issuerCountryCodeNum").toString())).build();

        EmiCalculatorResponse emiCalculatorResponse = responseServiceOnlineAPI.emiCalculatorRequest(emiCalculatorRequest, token());
        Assert.assertEquals(emiCalculatorResponse.getStatusCode(), 400);
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getCode(),"ERROR_1056");
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getMessage(),"Scheme not found.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void emiCalculatorwithBlankInstalmentConfigType(HashMap<Object,Object> input) throws Exception {
        EmiCalculatorRequest emiCalculatorRequest = new EmiCalculatorRequest.Builder()
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .installmentConfigId(input.get("merchantInstallmentConfigId").toString())
                .installmentConfigType("")
                .issuerId(input.get("issuerId").toString()).terminalId(input.get("terminalId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .merchantCurrencyCode(input.get("merchantCurrencyCode").toString())
                .issuerCurrencyCode(input.get("issuerCurrencyCode").toString())
                .issuerCountryCodeNum(Integer.parseInt(input.get("issuerCountryCodeNum").toString())).build();

        EmiCalculatorResponse emiCalculatorResponse = responseServiceOnlineAPI.emiCalculatorRequest(emiCalculatorRequest, token());
        Assert.assertEquals(emiCalculatorResponse.getStatusCode(), 400);
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getCode(),"ERROR_4090");
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getMessage(),"EMPTY INSTALLMENT CONFIG TYPE");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void emiCalculatorwithInvalidIssuerId(HashMap<Object,Object> input) throws Exception {
        EmiCalculatorRequest emiCalculatorRequest = new EmiCalculatorRequest.Builder()
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .installmentConfigId(input.get("merchantInstallmentConfigId").toString())
                .installmentConfigType("MERCHANT")
                .issuerId("6024d33321db3aa7f1d27b").terminalId(input.get("terminalId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .merchantCurrencyCode(input.get("merchantCurrencyCode").toString())
                .issuerCurrencyCode(input.get("issuerCurrencyCode").toString())
                .issuerCountryCodeNum(Integer.parseInt(input.get("issuerCountryCodeNum").toString())).build();

        EmiCalculatorResponse emiCalculatorResponse = responseServiceOnlineAPI.emiCalculatorRequest(emiCalculatorRequest, token());
        Assert.assertEquals(emiCalculatorResponse.getStatusCode(), 400);
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getCode(),"ERROR_1049");
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getMessage(),"Field Name issuerId is either null or has invalid value.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void emiCalculatorwithInvalidTenure(HashMap<Object,Object> input) throws Exception {
        EmiCalculatorRequest emiCalculatorRequest = new EmiCalculatorRequest.Builder()
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .installmentConfigId(input.get("merchantInstallmentConfigId").toString())
                .installmentConfigType("MERCHANT")
                .issuerId(input.get("issuerId").toString()).terminalId(input.get("terminalId").toString())
                .tenure(7)
                .merchantCurrencyCode(input.get("merchantCurrencyCode").toString())
                .issuerCurrencyCode(input.get("issuerCurrencyCode").toString())
                .issuerCountryCodeNum(Integer.parseInt(input.get("issuerCountryCodeNum").toString())).build();

        EmiCalculatorResponse emiCalculatorResponse = responseServiceOnlineAPI.emiCalculatorRequest(emiCalculatorRequest, token());
        Assert.assertEquals(emiCalculatorResponse.getStatusCode(), 400);
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getCode(),"ERROR_1085");
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getMessage(),"invalid tenure");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void emiCalculatorwithBlankTerminalId(HashMap<Object,Object> input) throws Exception {
        EmiCalculatorRequest emiCalculatorRequest = new EmiCalculatorRequest.Builder()
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .installmentConfigId(input.get("merchantInstallmentConfigId").toString())
                .installmentConfigType("MERCHANT")
                .issuerId(input.get("issuerId").toString()).terminalId(input.get("terminalId").toString())
                .terminalId("")
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .merchantCurrencyCode(input.get("merchantCurrencyCode").toString())
                .issuerCurrencyCode(input.get("issuerCurrencyCode").toString())
                .issuerCountryCodeNum(Integer.parseInt(input.get("issuerCountryCodeNum").toString())).build();

        EmiCalculatorResponse emiCalculatorResponse = responseServiceOnlineAPI.emiCalculatorRequest(emiCalculatorRequest, token());
        Assert.assertEquals(emiCalculatorResponse.getStatusCode(), 200);
        Assert.assertEquals(emiCalculatorResponse.getMsg(),
                "Terminal Id should not be Empty ");
       }

    @Test(dataProvider="getDataFixdata",retryAnalyzer= RetryTest.class)
    public void emiCalculatorCalcucationCheckWithStaticData(HashMap<Object,Object> input) throws Exception {
        EmiCalculatorRequest emiCalculatorRequest = new EmiCalculatorRequest.Builder()
                .amount(Double.parseDouble(input.get("amount").toString()))
                .installmentConfigId(input.get("installmentConfigId").toString())
                .installmentConfigType(input.get("installmentConfigType").toString())
                .issuerId(input.get("issuerId").toString())
                .terminalId(input.get("terminalId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .merchantCurrencyCode(input.get("merchantCurrencyCode").toString())
                .issuerCurrencyCode(input.get("issuerCurrencyCode").toString())
                .issuerCountryCodeNum(Integer.parseInt(input.get("issuerCountryCodeNum").toString())).build();
        EmiCalculatorResponse emiCalculatorResponse = responseServiceOnlineAPI.emiCalculatorRequest(emiCalculatorRequest, token());
        Assert.assertEquals(emiCalculatorResponse.getStatusCode(), 200);
        assertCalculatedValue(input, emiCalculatorResponse);
    }




    @DataProvider
    public Object[][] getData() throws IOException {
        OnlineApiDataPropertiesConfig dataProperties=new OnlineApiDataPropertiesConfig();
        List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                (System.getProperty("user.dir")+ dataProperties.getProperty("Data"));
        Object[][] obj= new Object[data.size()][1];
        for(int i=0;i<data.size();i++){
            obj[i][0]=data.get(i);
        }
        return  obj;
    }
    @DataProvider
    public Object[][] getDataFixdata() throws IOException {
        OnlineApiDataPropertiesConfig dataProperties=new OnlineApiDataPropertiesConfig();
        List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                (System.getProperty("user.dir")+ dataProperties.getProperty("EmiCalculatorFixedData"));
        Object[][] obj= new Object[data.size()][1];
        for(int i=0;i<data.size();i++){
            obj[i][0]=data.get(i);
        }
        return  obj;
    }

}
