package com.pinelabs.PayLater.CrossBorderTest;

import com.pinelabs.PayLater.API.Helpers.BaseUtils;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.API.Helpers.PLEncrypt.PLEncrypt;
import com.pinelabs.PayLater.API.Helpers.RetryTest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.IppOfferRequest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.TransactionStatusRequest;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.IppOfferResponse;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.TransactionStatusResponse;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceOnlineAPI;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

public class TransactionStatusCrossBorderTest extends BaseUtils {
    @BeforeSuite
    public void setReportName(){System.setProperty("ReportName","CrossBorderOnlineAPI");}
    private ResponseServiceOnlineAPI responseServiceOnlineAPI;
    @BeforeClass()
    private void beforeClass() {responseServiceOnlineAPI = new ResponseServiceOnlineAPI();}
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With Positive flow")
    public void checkTransactionSale_TC01(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo=input.get("cardNumber").toString();
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
//                .cardApprovalCode(input.get("cardApprovalCode").toString())
//                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),200);
        Assert.assertEquals(transactionStatusResponse.getMerchantId(),input.get("merchantId").toString());
        Assert.assertEquals(transactionStatusResponse.getCardNumber(),Integer.parseInt(input.get("cardNumber").toString().substring(0,8)));
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With Invalid Merchant ID should throw error")
    public void checkTransactionSale_TC02(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo=input.get("cardNumber").toString();
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId("123456zxcvb")
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
//                .cardApprovalCode(input.get("cardApprovalCode").toString())
//                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),400);
        Assert.assertEquals(transactionStatusResponse.getErrors()[0].getMessage(),"Field Name merchantId has invalid value.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With Invalid Card Number should throw error")
    public void checkTransactionSale_TC03(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo="1234567812345678";
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(fullCardNo.substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
//                .cardApprovalCode(input.get("cardApprovalCode").toString())
//                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),400);
        Assert.assertEquals(transactionStatusResponse.getErrors()[0].getMessage(),
                "Eligibility check failed: Invalid Card Number,");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With Invalid transaction Status should throw error")
    public void checkTransactionSale_TC04(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo=input.get("cardNumber").toString();
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
//                .cardApprovalCode(input.get("cardApprovalCode").toString())
//                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(1)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),400);
        Assert.assertEquals(transactionStatusResponse.getErrors()[0].getMessage(),
                "Invalid value for transactionStatus field");
         }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With Invalid Issuer Id should throw error")
    public void checkTransactionSale_TC05(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo=input.get("cardNumber").toString();
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId("xyz")
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
//                .cardApprovalCode(input.get("cardApprovalCode").toString())
//                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),400);
        Assert.assertEquals(transactionStatusResponse.getErrors()[0].getMessage(),
                "Field Name issuerId is either null or has invalid value.");

    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With Tenure Not In Scheme should throw error")
    public void checkTransactionSale_TC06(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo=input.get("cardNumber").toString();
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(1)
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
//                .cardApprovalCode(input.get("cardApprovalCode").toString())
//                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),400);
        Assert.assertEquals(transactionStatusResponse.getErrors()[0].getMessage(),
                "Eligibility check failed: Invalid tenure,");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With Total Amount Not In Scheme should throw error")
    public void checkTransactionSale_TC07(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo=input.get("cardNumber").toString();
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(currencyConverter(
                        input.get("merchantCurrencyCode").toString(),
                        input.get("issuerCurrencyCode").toString(),
                        Double.parseDouble(input.get("invalidTotalAmount").toString())))
                .pspId(input.get("pspId").toString())
                .amount(currencyConverter(
                        input.get("merchantCurrencyCode").toString(),
                        input.get("issuerCurrencyCode").toString(),
                        Double.parseDouble(input.get("invalidTotalAmount").toString())))
//                .cardApprovalCode(input.get("cardApprovalCode").toString())
//                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),400);
        Assert.assertEquals(transactionStatusResponse.getErrors()[0].getMessage(),
                "Eligibility check failed: Amount not in range,");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With Total Amount Zero should throw error")
    public void checkTransactionSale_TC08(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo=input.get("cardNumber").toString();
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(0)
                .pspId(input.get("pspId").toString())
                .amount(0)
//                .cardApprovalCode(input.get("cardApprovalCode").toString())
//                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),400);
        Assert.assertEquals(transactionStatusResponse.getErrors()[0].getMessage(),
                "totalAmount required and value should be greater than 0 in ippData in request body");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With Invalid Scheme Id should throw error")
    public void checkTransactionSale_TC09(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo=input.get("cardNumber").toString();
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
//                .cardApprovalCode(input.get("cardApprovalCode").toString())
//                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId("invalid_schemeID")
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),400);
        Assert.assertEquals(transactionStatusResponse.getErrors()[0].getMessage(),
                "Scheme not found for provided schemeId");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With Blank Scheme Id should throw error")
    public void checkTransactionSale_TC10(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo=input.get("cardNumber").toString();
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
//                .cardApprovalCode(input.get("cardApprovalCode").toString())
//                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId("")
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),400);
        Assert.assertEquals(transactionStatusResponse.getErrors()[0].getMessage(),
                "schemeId required in ippData required in request body");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With Wrong Monthly Installment should throw error")
    public void checkTransactionSale_TC11(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo=input.get("cardNumber").toString();
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
//                .cardApprovalCode(input.get("cardApprovalCode").toString())
//                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(123456)
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),400);
        Assert.assertEquals(transactionStatusResponse.getErrors()[0].getMessage(),
                "monthlyInstallment does not match with EMI calculated value");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With Mismatch Of CardNumber And Encryption Card Value should throw error")
    public void checkTransactionSale_TC12(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String invalidCard="12345678998765432";
        String comboOfEncryptKey= PLEncrypt.generate(invalidCard);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
//                .cardApprovalCode(input.get("cardApprovalCode").toString())
//                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),400);
        Assert.assertEquals(transactionStatusResponse.getErrors()[0].getMessage(),
                "request cardNumber does not match with velocity check response funding bin value");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With Auth Code More Than Six Character should throw error")
    public void checkTansactionSale_TC13(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo=input.get("cardNumber").toString();
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .cardApprovalCode("AC123456")
//                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),400);
        Assert.assertEquals(transactionStatusResponse.getErrors()[0].getMessage(),
                "cardApprovalCode required in pspResponse in pspDetails and maximum length should be 6");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With Invalid PspId should throw error")
    public void checkTransactionSale_TC14(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo=input.get("cardNumber").toString();
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId("12345678765")
                .amount(convertedAmount)
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),400);
        Assert.assertEquals(transactionStatusResponse.getErrors()[0].getMessage(),
                "Invalid PSP Id.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With Invalid Acquirer Id should throw error")
    public void checkTransactionSale_TC15(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo=input.get("cardNumber").toString();
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId("898765")
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),400);
        Assert.assertEquals(transactionStatusResponse.getErrors()[0].getMessage(),
                "psp_acquirer_mapping not found for given pspId & acquirerId");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With TxnDateTime Not In Scheme Life should throw error")
    public void checkTransactionSale_TC16(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo=input.get("cardNumber").toString();
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime("2020050517061")
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),400);
        Assert.assertEquals(transactionStatusResponse.getErrors()[0].getMessage(),
                "Scheme has expired");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With Invalid TxnDateTime should throw error")
    public void checkTransactionSale_TC17(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo=input.get("cardNumber").toString();
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime("2020555517061")
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),400);
        Assert.assertEquals(transactionStatusResponse.getErrors()[0].getMessage(),
                "Invalid date found for txnTime in request body");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With Merchant Currency in Card Holder Currency code should throw error")
    public void checkTransactionSale_TC18(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo=input.get("cardNumber").toString();
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),400);
        Assert.assertEquals(transactionStatusResponse.getErrors()[0].getMessage(),
                "cardCurrCode in request should be issuer currency code.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With Card Holder Currency in Merchant Currency code should throw error")
    public void checkTansactionSale_TC19(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo=input.get("cardNumber").toString();
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .currencyCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),400);
        Assert.assertEquals(transactionStatusResponse.getErrors()[0].getMessage(),
                "currencyCode in request should be merchant currency code.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With isCrossBorder 0 should throw error")
    public void checkTransactionSale_TC20(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo=input.get("cardNumber").toString();
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(0)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),400);
        Assert.assertEquals(transactionStatusResponse.getErrors()[0].getMessage(),
                "isCrossBorder in request body does not match with currency conversion response value");
         }

    @DataProvider
    public Object[][] getData() throws IOException {
        OnlineApiDataPropertiesConfig dataProperties =new OnlineApiDataPropertiesConfig();
        List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                (System.getProperty("user.dir")+ dataProperties.getProperty("CrossBorderData"));
        Object[][] obj= new Object[data.size()][1];
        for(int i=0;i<data.size();i++){
            obj[i][0]=data.get(i);
        }
        return  obj;
    }
}
