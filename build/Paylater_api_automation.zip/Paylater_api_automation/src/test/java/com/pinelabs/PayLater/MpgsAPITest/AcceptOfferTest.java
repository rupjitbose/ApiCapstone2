package com.pinelabs.PayLater.MpgsAPITest;

import com.pinelabs.PayLater.API.Helpers.BaseUtils;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS.AcceptOfferRequest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS.CartOfferRequest;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoMPGS.AcceptOfferResponse;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoMPGS.CartOfferResponse;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceMPGS;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.testng.Assert.assertEquals;

public class AcceptOfferTest extends BaseUtils {

    @BeforeSuite
    public void setReportName(){
        System.setProperty("ReportName","MPGS");
    }
    private ResponseServiceMPGS responseServiceMPGS;

    @BeforeClass
    private void beforeClass() {
        responseServiceMPGS = new ResponseServiceMPGS();
    }
    @Test(dataProvider = "getData",description = "hitting accept Offer API with bank scheme")
    public void acceptOfferTC_01(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("CIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("CIBMerchantId").toString(), String.valueOf(cartOfferId));
        assertEquals(acceptOfferResponse.getStatusCode(),200);
        assertEquals(acceptOfferResponse.getResponse(),"ACCEPTED");
      //  assertAcceptOfferInDB(cartOfferId,"0");
    }

    @Test(dataProvider = "getData",description = "hitting accept Offer API with merchant scheme")
    public void acceptOfferTC_02(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("MIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("MIBMerchantId").toString(), cartOfferId);
        assertEquals(acceptOfferResponse.getStatusCode(),200);
        assertEquals(acceptOfferResponse.getResponse(),"ACCEPTED");
    }

    @Test(dataProvider = "getData",description = "hitting accept Offer API with invalid currency Code")
    public void acceptOfferTC_03(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("MIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode("JKL")
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("MIBMerchantId").toString(), cartOfferId);
        assertEquals(acceptOfferResponse.getStatusCode(),200);
        assertEquals(acceptOfferResponse.getResponse(),"REJECTED");
        assertEquals(acceptOfferResponse.getRejection().getReason(),
                "Request MerchantCurrency does not match with CartOffer MerchantCurrency");
    }

    @Test(dataProvider = "getData",description = "hitting accept Offer API with invalid amount(cart offer API amount is not equal to accept offer API amount")
    public void acceptOfferTC_04(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("MIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount("1001").termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("MIBMerchantId").toString(), cartOfferId);
        assertEquals(acceptOfferResponse.getStatusCode(),200);
        assertEquals(acceptOfferResponse.getResponse(),"REJECTED");
        assertEquals(acceptOfferResponse.getRejection().getReason(),
                "Request PaymentAmount does not match with CartOffer PaymentAmount");
    }

    @Test(dataProvider = "getData",description = "hitting accept Offer API with invalid cartid")
    public void acceptOfferTC_05(HashMap<Object, Object> input) throws Exception {

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount("1001").termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId("hgvhg").mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("MIBMerchantId").toString(), "423");
        assertEquals(acceptOfferResponse.getStatusCode(),200);
        assertEquals(acceptOfferResponse.getResponse(),"REJECTED");
        assertEquals(acceptOfferResponse.getRejection().getReason(),
                "No CartOffer Found for given CartOfferId");
    }

    @Test(dataProvider = "getData",description = "hitting accept Offer API with invalid value in terms and condition")
    public void acceptOfferTC_06(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("MIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("MIBMerchantId").toString(), cartOfferId);
        assertEquals(acceptOfferResponse.getStatusCode(),400);
        assertEquals(acceptOfferResponse.getErrors()[0].getDescription(),
                "Unexpected value 'ACCPTED'");
    }

    @Test(dataProvider = "getData",description = "hitting accept Offer API with invalid card number prefix")
    public void acceptOfferTC_07(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("MIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix("54208500").build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("MIBMerchantId").toString(), cartOfferId);
        assertEquals(acceptOfferResponse.getStatusCode(),200);
        assertEquals(acceptOfferResponse.getResponse(),"REJECTED");
        assertEquals(acceptOfferResponse.getRejection().getReason(),
                "Invalid Card Number,");
    }

    @Test(dataProvider = "getData",description = "hitting accept Offer API with blank delivery Country")
    public void acceptOfferTC_08(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("MIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry("").currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("MIBMerchantId").toString(), cartOfferId);
        assertEquals(acceptOfferResponse.getStatusCode(),400);
        assertEquals(acceptOfferResponse.getErrors()[0].getField(),"deliveryCountry");
        assertEquals(acceptOfferResponse.getErrors()[0].getDescription(),"size must be between 2 and 2");
    }

    @Test(dataProvider = "getData",description = "hitting accept Offer API with invalid merchant id")
    public void acceptOfferTC_09(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("MIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), "jhvjh3", cartOfferId);
        assertEquals(acceptOfferResponse.getStatusCode(),200);
        assertEquals(acceptOfferResponse.getResponse(),"REJECTED");
        assertEquals(acceptOfferResponse.getRejection().getReason(),"Request MerchantId does not match with CartOffer MerchantId");
    }


    @Test(dataProvider = "getData",description = "hitting accept Offer API with brand scheme")
    public void acceptOfferTC_10(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
            List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity")));
    CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
            .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
            .items(listOfItem).build();
    CartOfferResponse cartOfferResponse  = responseServiceMPGS
            .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
    String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        List<AcceptOfferRequest.Items> listOfItem1=new ArrayList<>();
        listOfItem1.add(new AcceptOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity"),new String[] {"342"}));
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).items(listOfItem1).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);
        assertEquals(acceptOfferResponse.getStatusCode(),200);
        assertEquals(acceptOfferResponse.getResponse(),"ACCEPTED");
    }

    @Test(dataProvider = "getData",description = "hitting accept Offer API with brand scheme without serialNumbers")
    public void acceptOfferTC_11(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        List<AcceptOfferRequest.Items> listOfItem1=new ArrayList<>();
        listOfItem1.add(new AcceptOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity"),new String[]{}));
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).items(listOfItem1).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);
        assertEquals(acceptOfferResponse.getStatusCode(),200);
        assertEquals(acceptOfferResponse.getResponse(),"ACCEPTED_SERIAL_NUMBERS_REQUIRED");
    }

    @Test(dataProvider = "getData",description = "hitting accept Offer API with invalid sku")
    public void acceptOfferTC_12(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        List<AcceptOfferRequest.Items> listOfItem1=new ArrayList<>();
        listOfItem1.add(new AcceptOfferRequest.Items().setItems("ash_m01",(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity"),new String[]{"67"}));
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).items(listOfItem1).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);
        assertEquals(acceptOfferResponse.getStatusCode(),200);
        assertEquals(acceptOfferResponse.getResponse(),"REJECTED");
        assertEquals(acceptOfferResponse.getRejection().getReason(),"Request Sku does not match with CartOffer ProductCode");
    }

    @Test(dataProvider = "getData",description = "hitting accept Offer API with sku for which isSerialNUmberRequired is false")
    public void acceptOfferTC_13(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku2").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        List<AcceptOfferRequest.Items> listOfItem1=new ArrayList<>();
        listOfItem1.add(new AcceptOfferRequest.Items().setItems(input.get("sku2").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity"),new String[]{}));
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).items(listOfItem1).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);
        assertEquals(acceptOfferResponse.getStatusCode(),200);
        assertEquals(acceptOfferResponse.getResponse(),"ACCEPTED");
    }

    @Test(dataProvider = "getData",description = "hitting accept Offer API with cartid which is accepted in the system")
    public void acceptOfferTC_14(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        List<AcceptOfferRequest.Items> listOfItem1=new ArrayList<>();
        listOfItem1.add(new AcceptOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity"),new String[] {"342"}));
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).items(listOfItem1).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);
        AcceptOfferResponse acceptOfferResponse1 = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("BrandMerchantId").toString(), "34524");
        assertEquals(acceptOfferResponse1.getStatusCode(),200);
        assertEquals(acceptOfferResponse1.getResponse(),"REJECTED");
        assertEquals(acceptOfferResponse1.getRejection().getReason(),"Cart Offer is already accepted in the system.");
    }

    @Test(dataProvider = "getData",description = "hitting accept Offer API with cartid which is ACCEPTED_SERIAL_NUMBERS_REQUIRED in the system")
    public void acceptOfferTC_15(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        List<AcceptOfferRequest.Items> listOfItem1=new ArrayList<>();
        listOfItem1.add(new AcceptOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity"),new String[] {}));
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).items(listOfItem1).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);
        AcceptOfferResponse acceptOfferResponse1 = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("BrandMerchantId").toString(), "34524");
        assertEquals(acceptOfferResponse1.getStatusCode(),200);
        assertEquals(acceptOfferResponse1.getResponse(),"REJECTED");
        assertEquals(acceptOfferResponse1.getRejection().getReason(),"Cart Offer is already accepted in the system.");
    }

    @Test(dataProvider = "getData",description = "hitting accept Offer API with card number prefix less than 8 digits")
    public void acceptOfferTC_16(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("CIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix("5420830").build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("CIBMerchantId").toString(), cartOfferId);
        assertEquals(acceptOfferResponse.getStatusCode(),400);
        assertEquals(acceptOfferResponse.getErrors()[0].getField(),"accountIdentifier.cardNumberPrefix");
        assertEquals(acceptOfferResponse.getErrors()[0].getDescription(),"size must be between 8 and 8");
    }

    @Test(dataProvider = "getData",description = "hitting accept Offer API with brand scheme with quantity zero")
    public void acceptOfferTC_17(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        List<AcceptOfferRequest.Items> listOfItem1=new ArrayList<>();
        listOfItem1.add(new AcceptOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,0,new String[] {"342"}));
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).items(listOfItem1).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);
        assertEquals(acceptOfferResponse.getStatusCode(),400);
        assertEquals(acceptOfferResponse.getErrors()[0].getField(),"items[0].quantity");
        assertEquals(acceptOfferResponse.getErrors()[0].getDescription(),"must be greater than 0");
    }

    @Test(dataProvider = "getData",description = "hitting accept Offer API with quantity*unit amount not equals to payment amount")
    public void acceptOfferTC_18(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        List<AcceptOfferRequest.Items> listOfItem1=new ArrayList<>();
        listOfItem1.add(new AcceptOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,2,new String[] {"342"}));
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).items(listOfItem1).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);
        assertEquals(acceptOfferResponse.getStatusCode(),200);
        assertEquals(acceptOfferResponse.getResponse(),"REJECTED");
        assertEquals(acceptOfferResponse.getRejection().getReason(),"Actual Total Amount not matching with Expected Total Amount.");
    }

    @DataProvider
    public Object[][] getData() throws IOException {
        OnlineApiDataPropertiesConfig dataProperties =new OnlineApiDataPropertiesConfig();
        List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                (System.getProperty("user.dir")+ dataProperties.getProperty("MPGSData"));
        Object[][] obj= new Object[data.size()][1];
        for(int i=0;i<data.size();i++){
            obj[i][0]=data.get(i);
        }
        return obj;
    }
}
