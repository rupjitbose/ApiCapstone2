package com.pinelabs.PayLater.MpgsAPITest;

import com.pinelabs.PayLater.API.Helpers.BaseUtils;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.API.Helpers.PLEncrypt.PLEncrypt;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS.AcceptOfferRequest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS.CartOfferRequest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS.PostTransactionRequest;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoMPGS.CancelTransactionResponse;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoMPGS.CartOfferResponse;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoMPGS.PostTransactionResponse;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceMPGS;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

public class CancelTransactionTest extends BaseUtils {
    @BeforeSuite
    public void setReportName(){
        System.setProperty("ReportName","MPGS");
    }
    private ResponseServiceMPGS responseServiceMPGS;

    @BeforeClass
    private void beforeClass() {
        responseServiceMPGS = new ResponseServiceMPGS();
    }
    @Test(dataProvider = "getData",description = "Hitting cancel transaction APi with bank program type and txn type = PURCHASE")
    public void cancelTransactionTC_01(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("CIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).build();
        responseServiceMPGS.acceptOfferRequest(acceptOfferRequest, token(), input.get("CIBMerchantId").toString(), cartOfferId);

        //post transaction api
        PostTransactionRequest postTransactionRequest =new PostTransactionRequest.Builder()
                .acquirerMerchantId("8798323").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("PURCHASE")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest, token(), input.get("CIBMerchantId").toString(), cartOfferId);

        //Cancel transaction API
        CancelTransactionResponse cancelTransactionResponse = responseServiceMPGS
                .cancelTransactionRequest(token(),input.get("CIBMerchantId").toString(), cartOfferId);
        Assert.assertEquals(cancelTransactionResponse.getResponse(),"ACKNOWLEDGE");
        Assert.assertEquals(cancelTransactionResponse.getStatusCode(),200);
    }

    @Test(dataProvider = "getData",description = "Hitting cancel transaction APi with merchant program type and txn type = PURCHASE")
    public void cancelTransactionTC_02(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("MIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).build();
        responseServiceMPGS.acceptOfferRequest(acceptOfferRequest, token(), input.get("MIBMerchantId").toString(), cartOfferId);

        //post transaction api
        PostTransactionRequest postTransactionRequest =new PostTransactionRequest.Builder()
                .acquirerMerchantId("8798323").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("PURCHASE")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest, token(), input.get("MIBMerchantId").toString(), cartOfferId);

        //Cancel transaction API
        CancelTransactionResponse cancelTransactionResponse = responseServiceMPGS
                .cancelTransactionRequest(token(),input.get("MIBMerchantId").toString(), cartOfferId);
        Assert.assertEquals(cancelTransactionResponse.getResponse(),"ACKNOWLEDGE");
        Assert.assertEquals(cancelTransactionResponse.getStatusCode(),200);
    }

    @Test(dataProvider = "getData",description = "Hitting cancel transaction APi with brand program type and type = PURCHASE")
    public void cancelTransactionTC_03(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        List<AcceptOfferRequest.Items> listOfItem1=new ArrayList<>();
        listOfItem1.add(new AcceptOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity"),new String[] {"342"}));
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).items(listOfItem1).build();
        responseServiceMPGS.acceptOfferRequest(acceptOfferRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);

        //post transaction api
        PostTransactionRequest postTransactionRequest =new PostTransactionRequest.Builder()
                .acquirerMerchantId("6546722").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("PURCHASE")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);

        //Cancel transaction API
        CancelTransactionResponse cancelTransactionResponse = responseServiceMPGS
                .cancelTransactionRequest(token(),input.get("BrandMerchantId").toString(), cartOfferId);
        assertEquals(cancelTransactionResponse.getResponse(),"ACKNOWLEDGE");
        assertEquals(cancelTransactionResponse.getStatusCode(),200);
    }

    @Test(dataProvider = "getData",description = "Hitting cancel transaction APi with bank program type and txn type = AUTHORIZATION")
    public void cancelTransactionTC_04(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("CIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).build();
        responseServiceMPGS.acceptOfferRequest(acceptOfferRequest, token(), input.get("CIBMerchantId").toString(), cartOfferId);

        //post transaction api
        PostTransactionRequest postTransactionRequest =new PostTransactionRequest.Builder()
                .acquirerMerchantId("8798323").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("AUTHORIZATION")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest, token(), input.get("CIBMerchantId").toString(), cartOfferId);

        //Cancel transaction API
        CancelTransactionResponse cancelTransactionResponse = responseServiceMPGS
                .cancelTransactionRequest(token(),input.get("CIBMerchantId").toString(), cartOfferId);
        Assert.assertEquals(cancelTransactionResponse.getResponse(),"ACKNOWLEDGE");
        Assert.assertEquals(cancelTransactionResponse.getStatusCode(),200);
    }

    @Test(dataProvider = "getData",description = "Hitting cancel transaction APi with merchant program type and txn type = AUTHORIZATION")
    public void cancelTransactionTC_05(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("MIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).build();
        responseServiceMPGS.acceptOfferRequest(acceptOfferRequest, token(), input.get("MIBMerchantId").toString(), cartOfferId);

        //post transaction api
        PostTransactionRequest postTransactionRequest =new PostTransactionRequest.Builder()
                .acquirerMerchantId("8798323").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("AUTHORIZATION")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest, token(), input.get("MIBMerchantId").toString(), cartOfferId);

        //Cancel transaction API
        CancelTransactionResponse cancelTransactionResponse = responseServiceMPGS
                .cancelTransactionRequest(token(),input.get("MIBMerchantId").toString(), cartOfferId);
        Assert.assertEquals(cancelTransactionResponse.getResponse(),"ACKNOWLEDGE");
        Assert.assertEquals(cancelTransactionResponse.getStatusCode(),200);
    }

    @Test(dataProvider = "getData",description = "Hitting cancel transaction APi with brand program type and type = AUTHORIZATION")
    public void cancelTransactionTC_06(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        List<AcceptOfferRequest.Items> listOfItem1=new ArrayList<>();
        listOfItem1.add(new AcceptOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity"),new String[] {"342"}));
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).items(listOfItem1).build();
        responseServiceMPGS.acceptOfferRequest(acceptOfferRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);

        //post transaction api
        PostTransactionRequest postTransactionRequest =new PostTransactionRequest.Builder()
                .acquirerMerchantId("6546722").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("AUTHORIZATION")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);

        //Cancel transaction API
        CancelTransactionResponse cancelTransactionResponse = responseServiceMPGS
                .cancelTransactionRequest(token(),input.get("BrandMerchantId").toString(), cartOfferId);
        assertEquals(cancelTransactionResponse.getResponse(),"ACKNOWLEDGE");
        assertEquals(cancelTransactionResponse.getStatusCode(),200);
    }

    @Test(dataProvider = "getData",description = "Hitting cancel transaction APi with bank program type and txn type = CAPTURE")
    public void cancelTransactionTC_07(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("CIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).build();
        responseServiceMPGS.acceptOfferRequest(acceptOfferRequest, token(), input.get("CIBMerchantId").toString(), cartOfferId);

        //post transaction api with type = "AUTHORIZATION"
        PostTransactionRequest postTransactionRequest =new PostTransactionRequest.Builder()
                .acquirerMerchantId("8798323").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("AUTHORIZATION")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest, token(), input.get("CIBMerchantId").toString(), cartOfferId);

        //Capturing the pre auth txn
        PostTransactionRequest postTransactionRequest1 =new PostTransactionRequest.Builder()
                .acquirerMerchantId("8798323").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("CAPTURE")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest1, token(), input.get("CIBMerchantId").toString(), cartOfferId);

        //Cancel transaction API
        CancelTransactionResponse cancelTransactionResponse = responseServiceMPGS
                .cancelTransactionRequest(token(),input.get("CIBMerchantId").toString(), cartOfferId);
        assertEquals(cancelTransactionResponse.getResponse(),"DENY");
        assertEquals(cancelTransactionResponse.getStatusCode(),200);

    }

    @Test(dataProvider = "getData",description = "Hitting cancel transaction APi with merchant program type and txn type = CAPTURE")
    public void cancelTransactionTC_08(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("MIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).build();
        responseServiceMPGS.acceptOfferRequest(acceptOfferRequest, token(), input.get("MIBMerchantId").toString(), cartOfferId);

        //post transaction api with type = "AUTHORIZATION"
        PostTransactionRequest postTransactionRequest =new PostTransactionRequest.Builder()
                .acquirerMerchantId("8798323").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("AUTHORIZATION")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest, token(), input.get("MIBMerchantId").toString(), cartOfferId);

        //Capturing the pre auth txn
        PostTransactionRequest postTransactionRequest1 =new PostTransactionRequest.Builder()
                .acquirerMerchantId("8798323").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("CAPTURE")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
       responseServiceMPGS.postTransactionRequest(postTransactionRequest1, token(), input.get("MIBMerchantId").toString(), cartOfferId);

        //Cancel transaction API
        CancelTransactionResponse cancelTransactionResponse = responseServiceMPGS
                .cancelTransactionRequest(token(),input.get("MIBMerchantId").toString(), cartOfferId);
        assertEquals(cancelTransactionResponse.getResponse(),"DENY");
        assertEquals(cancelTransactionResponse.getStatusCode(),200);
    }

    @Test(dataProvider = "getData",description = "Hitting cancel transaction APi with brand program type and txn type = CAPTURE")
    public void cancelTransactionTC_09(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        List<AcceptOfferRequest.Items> listOfItem1=new ArrayList<>();
        listOfItem1.add(new AcceptOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity"),new String[] {"342"}));
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).items(listOfItem1).build();
        responseServiceMPGS.acceptOfferRequest(acceptOfferRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);

        //post transaction api with type = AUTHORIZATION
        PostTransactionRequest postTransactionRequest =new PostTransactionRequest.Builder()
                .acquirerMerchantId("6546722").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("AUTHORIZATION")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);

        //Capturing the pre auth txn
        PostTransactionRequest postTransactionRequest1 =new PostTransactionRequest.Builder()
                .acquirerMerchantId("6546722").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("CAPTURE")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest1, token(), input.get("BrandMerchantId").toString(), cartOfferId);

        //Cancel transaction API
        CancelTransactionResponse cancelTransactionResponse = responseServiceMPGS
                .cancelTransactionRequest(token(),input.get("BrandMerchantId").toString(), cartOfferId);
        assertEquals(cancelTransactionResponse.getResponse(),"DENY");
        assertEquals(cancelTransactionResponse.getStatusCode(),200);
    }

    @Test(dataProvider = "getData",description = "Hitting cancel transaction APi with bank program type and txn type = VOID_AUTHORIZATION")
    public void cancelTransactionTC_10(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("CIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).build();
        responseServiceMPGS.acceptOfferRequest(acceptOfferRequest, token(), input.get("CIBMerchantId").toString(), cartOfferId);

        //post transaction api with type = "AUTHORIZATION"
        PostTransactionRequest postTransactionRequest =new PostTransactionRequest.Builder()
                .acquirerMerchantId("8798323").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("AUTHORIZATION")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest, token(), input.get("CIBMerchantId").toString(), cartOfferId);

        //Cancelling the pre auth txn
        PostTransactionRequest postTransactionRequest1 =new PostTransactionRequest.Builder()
                .acquirerMerchantId("8798323").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("VOID_AUTHORIZATION")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
      responseServiceMPGS.postTransactionRequest(postTransactionRequest1, token(), input.get("CIBMerchantId").toString(), cartOfferId);

        //Cancel transaction API
        CancelTransactionResponse cancelTransactionResponse = responseServiceMPGS
                .cancelTransactionRequest(token(),input.get("CIBMerchantId").toString(), cartOfferId);
        assertEquals(cancelTransactionResponse.getResponse(),"DENY");
        assertEquals(cancelTransactionResponse.getStatusCode(),200);
    }

    @Test(dataProvider = "getData",description = "Hitting cancel transaction APi with merchant program type and txn type = VOID_AUTHORIZATION")
    public void cancelTransactionTC_11(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("MIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).build();
        responseServiceMPGS.acceptOfferRequest(acceptOfferRequest, token(), input.get("MIBMerchantId").toString(), cartOfferId);

        //post transaction api with type = "AUTHORIZATION"
        PostTransactionRequest postTransactionRequest =new PostTransactionRequest.Builder()
                .acquirerMerchantId("8798323").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("AUTHORIZATION")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest, token(), input.get("MIBMerchantId").toString(), cartOfferId);

        //Cancelling the pre auth txn
        PostTransactionRequest postTransactionRequest1 =new PostTransactionRequest.Builder()
                .acquirerMerchantId("8798323").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("VOID_AUTHORIZATION")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest1, token(), input.get("MIBMerchantId").toString(), cartOfferId);

        //Cancel transaction API
        CancelTransactionResponse cancelTransactionResponse = responseServiceMPGS
                .cancelTransactionRequest(token(),input.get("MIBMerchantId").toString(), cartOfferId);
        assertEquals(cancelTransactionResponse.getResponse(),"DENY");
        assertEquals(cancelTransactionResponse.getStatusCode(),200);
    }

    @Test(dataProvider = "getData",description = "Hitting cancel transaction APi with brand program type and txn type = VOID_AUTHORIZATION")
    public void cancelTransactionTC_12(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        List<AcceptOfferRequest.Items> listOfItem1=new ArrayList<>();
        listOfItem1.add(new AcceptOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity"),new String[] {"342"}));
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).items(listOfItem1).build();
        responseServiceMPGS.acceptOfferRequest(acceptOfferRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);

        //post transaction api with type = AUTHORIZATION
        PostTransactionRequest postTransactionRequest =new PostTransactionRequest.Builder()
                .acquirerMerchantId("6546722").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("AUTHORIZATION")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);

        //Cancelling the pre auth txn
        PostTransactionRequest postTransactionRequest1 =new PostTransactionRequest.Builder()
                .acquirerMerchantId("6546722").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("VOID_AUTHORIZATION")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest1, token(), input.get("BrandMerchantId").toString(), cartOfferId);

        //Cancel transaction API
        CancelTransactionResponse cancelTransactionResponse = responseServiceMPGS
                .cancelTransactionRequest(token(),input.get("BrandMerchantId").toString(), cartOfferId);
        assertEquals(cancelTransactionResponse.getResponse(),"DENY");
        assertEquals(cancelTransactionResponse.getStatusCode(),200);
    }

    @Test(dataProvider = "getData",description = "Hitting cancel transaction APi with bank program type and txn type = REFUND")
    public void cancelTransactionTC_13(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("CIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).build();
        responseServiceMPGS.acceptOfferRequest(acceptOfferRequest, token(), input.get("CIBMerchantId").toString(), cartOfferId);

        //post transaction api with type = "PURCHASE"
        PostTransactionRequest postTransactionRequest =new PostTransactionRequest.Builder()
                .acquirerMerchantId("8798323").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("PURCHASE")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest, token(), input.get("CIBMerchantId").toString(), cartOfferId);

        //Refunding the purchase txn
        PostTransactionRequest postTransactionRequest1 =new PostTransactionRequest.Builder()
                .acquirerMerchantId("8798323").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("REFUND")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest1, token(), input.get("CIBMerchantId").toString(), cartOfferId);

        //Cancel transaction API
        CancelTransactionResponse cancelTransactionResponse = responseServiceMPGS
                .cancelTransactionRequest(token(),input.get("CIBMerchantId").toString(), cartOfferId);
        assertEquals(cancelTransactionResponse.getResponse(),"DENY");
        assertEquals(cancelTransactionResponse.getStatusCode(),200);
    }

    @Test(dataProvider = "getData",description = "Hitting cancel transaction APi with merchant program type and txn type = REFUND")
    public void cancelTransactionTC_14(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("MIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).build();
        responseServiceMPGS.acceptOfferRequest(acceptOfferRequest, token(), input.get("MIBMerchantId").toString(), cartOfferId);

        //post transaction api with type = "PURCHASE"
        PostTransactionRequest postTransactionRequest =new PostTransactionRequest.Builder()
                .acquirerMerchantId("8798323").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("PURCHASE")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest, token(), input.get("MIBMerchantId").toString(), cartOfferId);

        //Refunding the purchase txn
        PostTransactionRequest postTransactionRequest1 =new PostTransactionRequest.Builder()
                .acquirerMerchantId("8798323").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("REFUND")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest1, token(), input.get("MIBMerchantId").toString(), cartOfferId);

        //Cancel transaction API
        CancelTransactionResponse cancelTransactionResponse = responseServiceMPGS
                .cancelTransactionRequest(token(),input.get("MIBMerchantId").toString(), cartOfferId);
        assertEquals(cancelTransactionResponse.getResponse(),"DENY");
        assertEquals(cancelTransactionResponse.getStatusCode(),200);
    }

    @Test(dataProvider = "getData",description = "Hitting cancel transaction APi with brand program type and txn type = REFUND")
    public void cancelTransactionTC_15(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        List<AcceptOfferRequest.Items> listOfItem1=new ArrayList<>();
        listOfItem1.add(new AcceptOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity"),new String[] {"342"}));
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).items(listOfItem1).build();
        responseServiceMPGS.acceptOfferRequest(acceptOfferRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);

        //post transaction api with type = PURCHASE
        PostTransactionRequest postTransactionRequest =new PostTransactionRequest.Builder()
                .acquirerMerchantId("6546722").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("PURCHASE")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);

        //REfunding the purchase txn
        PostTransactionRequest postTransactionRequest1 =new PostTransactionRequest.Builder()
                .acquirerMerchantId("6546722").providerAcquirerId(input.get("MPGSAcquirerId").toString())
//               .authorizationCode(input.get("authCode").toString())
//               .rrn(input.get("rrn").toString())
                .stan("45345")
                .type("REFUND")
                .encryptedAccountIdentifier(PLEncrypt.getMpgsEncryptedAccountIdentifier(input.get("cardNumber").toString())).build();
        responseServiceMPGS.postTransactionRequest(postTransactionRequest1, token(), input.get("BrandMerchantId").toString(), cartOfferId);

        //Cancel transaction API
        CancelTransactionResponse cancelTransactionResponse = responseServiceMPGS
                .cancelTransactionRequest(token(),input.get("BrandMerchantId").toString(), cartOfferId);
        assertEquals(cancelTransactionResponse.getResponse(),"DENY");
        assertEquals(cancelTransactionResponse.getStatusCode(),200);
    }

    @Test(dataProvider = "getData",description = "Hitting cancel transaction APi with invalid pid")
    public void cancelTransactionTC_16(HashMap<Object, Object> input) throws Exception {

        //Cancel transaction API
        CancelTransactionResponse cancelTransactionResponse = responseServiceMPGS
                .cancelTransactionRequest(token(),input.get("BrandMerchantId").toString(), "jhvadf");
        assertEquals(cancelTransactionResponse.getErrors()[0].getDescription(),"ERROR_5001::Invalid PID");
        assertEquals(cancelTransactionResponse.getStatusCode(),400);
    }

    @DataProvider
    public Object[][] getData() throws IOException {
        OnlineApiDataPropertiesConfig dataProperties =new OnlineApiDataPropertiesConfig();
        List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                (System.getProperty("user.dir")+ dataProperties.getProperty("MPGSData"));
        Object[][] obj= new Object[data.size()][1];
        for(int i=0;i<data.size();i++){
            obj[i][0]=data.get(i);
        }
        return obj;
    }
}
