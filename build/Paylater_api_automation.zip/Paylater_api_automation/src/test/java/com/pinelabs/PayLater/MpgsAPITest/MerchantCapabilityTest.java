package com.pinelabs.PayLater.MpgsAPITest;

import com.pinelabs.PayLater.API.Helpers.BaseUtils;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS.MerchantCapabilityRequest;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoMPGS.MerchantCapabilityResponse;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceMPGS;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceOnlineAPI;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.pinelabs.PayLater.API.Helpers.BaseUtils.getJsonArrayToListOfHashMap;
import static com.pinelabs.PayLater.API.Helpers.BaseUtils.token;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class MerchantCapabilityTest extends BaseUtils {
    @BeforeSuite
    public void setReportName(){
        System.setProperty("ReportName","MPGS");
    }
    private ResponseServiceMPGS responseServiceMPGS;

    @BeforeClass
    private void beforeClass() {
        responseServiceMPGS = new ResponseServiceMPGS();
    }
    @Test(dataProvider = "getData",description = "hitting merchant capability API with bank scheme")
    public void merchantCapabilityTC_01(HashMap<Object, Object> input) throws Exception {
        MerchantCapabilityRequest merchantCapabilityRequest = new MerchantCapabilityRequest.Builder()
                .merchantCountry("HK")
                .build();

        MerchantCapabilityResponse merchantCapabilityResponse = responseServiceMPGS
                .merchantCapabilityRequest(merchantCapabilityRequest,token(),input.get("CIBMerchantId").toString(),"NORMAL");
        assertEquals(merchantCapabilityResponse.getStatusCode(),200);
        assertEquals(merchantCapabilityResponse.getSupportedOfferTypes(),"CART");
    }

    @Test(dataProvider = "getData",description = "hitting merchant capability API with merchant scheme")
    public void merchantCapabilityTC_02(HashMap<Object, Object> input) throws Exception {
        MerchantCapabilityRequest merchantCapabilityRequest = new MerchantCapabilityRequest.Builder()
                .merchantCountry("HK").build();
        MerchantCapabilityResponse merchantCapabilityResponse = responseServiceMPGS
                .merchantCapabilityRequest(merchantCapabilityRequest,token(),input.get("MIBMerchantId").toString(),"NORMAL");
        assertEquals(merchantCapabilityResponse.getStatusCode(),200);
        assertEquals(merchantCapabilityResponse.getSupportedOfferTypes(),"CART");
    }

    @Test(dataProvider = "getData",description = "hitting merchant capability API with brand scheme")
    public void merchantCapabilityTC_03(HashMap<Object, Object> input) throws Exception {
        MerchantCapabilityRequest merchantCapabilityRequest = new MerchantCapabilityRequest.Builder()
                .merchantCountry("HK").build();
        MerchantCapabilityResponse merchantCapabilityResponse = responseServiceMPGS
                .merchantCapabilityRequest(merchantCapabilityRequest, token(), input.get("BrandMerchantId").toString(),"NORMAL");
        assertEquals(merchantCapabilityResponse.getStatusCode(), 200);
        assertEquals(merchantCapabilityResponse.getSupportedOfferTypes(), "SKU");
        assertTrue(merchantCapabilityResponse.getOffersSupportedForSkus().contains("ash_ma01"));
        assertTrue(merchantCapabilityResponse.getOffersSupportedForSkus().contains("ash_ma02"));
    }

    @Test(description = "hitting merchant capability API with invalid merchant Id")
    public void merchantCapabilityTC_04() throws Exception {
        MerchantCapabilityRequest merchantCapabilityRequest = new MerchantCapabilityRequest.Builder()
                .merchantCountry("HK").build();
        MerchantCapabilityResponse merchantCapabilityResponse = responseServiceMPGS
                .merchantCapabilityRequest(merchantCapabilityRequest,token(),"64478a8576893802aa466e","NORMAL");
        assertEquals(merchantCapabilityResponse.getStatusCode(),400);
        assertEquals(merchantCapabilityResponse.getErrors().get(0).getDescription(),
                "ERROR_1025::Field Name merchantId has invalid value.");
    }

    @Test(dataProvider = "getData",description = "hitting merchant capability API with invalid merchant country")
    public void merchantCapabilityTC_05(HashMap<Object, Object> input) throws Exception {
        MerchantCapabilityRequest merchantCapabilityRequest = new MerchantCapabilityRequest.Builder()
                .merchantCountry("HJ").build();
        MerchantCapabilityResponse merchantCapabilityResponse = responseServiceMPGS
                .merchantCapabilityRequest(merchantCapabilityRequest,token(),input.get("BrandMerchantId").toString(),"NORMAL");
        assertEquals(merchantCapabilityResponse.getStatusCode(),500);
        assertEquals(merchantCapabilityResponse.getErrors().get(0).getDescription(),
                "ERROR_500::Couldn't find 3-letter country code for HJ");
    }

    @Test(dataProvider = "getData",description = "hitting merchant capability API with merchant country more than 2 characters")
    public void merchantCapabilityTC_06(HashMap<Object, Object> input) throws Exception {
        MerchantCapabilityRequest merchantCapabilityRequest = new MerchantCapabilityRequest.Builder()
                .merchantCountry("HJL").build();
        MerchantCapabilityResponse merchantCapabilityResponse = responseServiceMPGS
                .merchantCapabilityRequest(merchantCapabilityRequest,token(),input.get("BrandMerchantId").toString(),"NORMAL");
        assertEquals(merchantCapabilityResponse.getStatusCode(),400);
        assertEquals(merchantCapabilityResponse.getErrors().get(0).getDescription(),
                "size must be between 2 and 2");
    }

    @Test(dataProvider = "getData",description = "hitting merchant capability API with merchant country SG and scheme country is HK")
    public void merchantCapabilityTC_07(HashMap<Object, Object> input) throws Exception {
        MerchantCapabilityRequest merchantCapabilityRequest = new MerchantCapabilityRequest.Builder()
                .merchantCountry("SG").build();
        MerchantCapabilityResponse merchantCapabilityResponse = responseServiceMPGS
                .merchantCapabilityRequest(merchantCapabilityRequest,token(),input.get("BrandMerchantId").toString(),"NORMAL");
        assertEquals(merchantCapabilityResponse.getStatusCode(),400);
        assertEquals(merchantCapabilityResponse.getErrors().get(0).getDescription(),
                "ERROR_4106::Merchant Country should match with the country extracted from the mid present in request");
    }

    @Test(dataProvider = "getData",description = "hitting merchant capability API with merchant which has all schemes types attached")
    public void merchantCapabilityTC_08(HashMap<Object, Object> input) throws Exception {
        MerchantCapabilityRequest merchantCapabilityRequest = new MerchantCapabilityRequest.Builder()
                .merchantCountry("HK").build();
        MerchantCapabilityResponse merchantCapabilityResponse = responseServiceMPGS
                .merchantCapabilityRequest(merchantCapabilityRequest,token(),input.get("AllMerchantId").toString(),"NORMAL");
        assertEquals(merchantCapabilityResponse.getStatusCode(),200);
        assertEquals(merchantCapabilityResponse.getSupportedOfferTypes(),"SKU,CART");
        assertTrue(merchantCapabilityResponse.getOffersSupportedForSkus().contains("ash_ma14"));
    }

    @Test(dataProvider = "getData",description = "hitting merchant capability API with blank merchant country")
    public void merchantCapabilityTC_09(HashMap<Object, Object> input) throws Exception {
        MerchantCapabilityRequest merchantCapabilityRequest = new MerchantCapabilityRequest.Builder()
                .merchantCountry("").build();
        MerchantCapabilityResponse merchantCapabilityResponse = responseServiceMPGS
                .merchantCapabilityRequest(merchantCapabilityRequest,token(),input.get("CIBMerchantId").toString(),"NORMAL");
        assertEquals(merchantCapabilityResponse.getStatusCode(),400);
        assertEquals(merchantCapabilityResponse.getErrors().get(0).getDescription(),
                "size must be between 2 and 2");
    }

    @Test(dataProvider = "getData",description = "hitting merchant capability API with merchant id which don't have any schemes attatached")
    public void merchantCapabilityTC_10(HashMap<Object, Object> input) throws Exception {
        MerchantCapabilityRequest merchantCapabilityRequest = new MerchantCapabilityRequest.Builder()
                .merchantCountry(input.get("merchantCountry").toString()).build();
        MerchantCapabilityResponse merchantCapabilityResponse = responseServiceMPGS
                .merchantCapabilityRequest(merchantCapabilityRequest,token(),input.get("MerchantIdWithNoScheme").toString(),"NORMAL");
        assertEquals(merchantCapabilityResponse.getStatusCode(),200);
        assertEquals(merchantCapabilityResponse.getSupportedOfferTypes(),
                "NONE");
    }

    @Test(dataProvider = "getData",description = "hitting merchant capability API with request type as MONITORING")
    public void merchantCapabilityTC_11(HashMap<Object, Object> input) throws Exception {
        MerchantCapabilityRequest merchantCapabilityRequest = new MerchantCapabilityRequest.Builder()
                .merchantCountry("HK").build();
            Response response = responseServiceMPGS
                    .RequestHeaderType(merchantCapabilityRequest,token(),input.get("CIBMerchantId").toString(),"MONITORING");
        assertEquals(response.getStatusCode(),501);
    }

    @DataProvider
    public Object[][] getData() throws IOException {
        OnlineApiDataPropertiesConfig dataProperties =new OnlineApiDataPropertiesConfig();
        List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                (System.getProperty("user.dir")+ dataProperties.getProperty("MPGSData"));
        Object[][] obj= new Object[data.size()][1];
        for(int i=0;i<data.size();i++){
            obj[i][0]=data.get(i);
        }
        return  obj;
    }
}
