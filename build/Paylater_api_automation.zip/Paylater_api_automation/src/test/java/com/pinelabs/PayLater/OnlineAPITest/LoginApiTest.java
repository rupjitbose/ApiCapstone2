package com.pinelabs.PayLater.OnlineAPITest;

import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.LoginApiRequest;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.LoginApiResponse;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceOnlineAPI;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class LoginApiTest {
    @BeforeSuite
    public void setReportName(){
        System.setProperty("ReportName","OnlineAPI");
    }

    private ResponseServiceOnlineAPI responseServiceOnlineAPI;
    @BeforeClass
    private void beforeClass(){
        responseServiceOnlineAPI =new ResponseServiceOnlineAPI();
    }
    @Test
    public void triggerLoginAuthApiWithCorrectUserNameAndPassWord() throws Exception {
        //arrange
        LoginApiRequest loginApiRequest=new LoginApiRequest.Builder()
                .username(new OnlineApiDataPropertiesConfig().getProperty("username"))
                .password(new OnlineApiDataPropertiesConfig().getProperty("password"))
                .build();
        //act
        LoginApiResponse loginApiResponse= responseServiceOnlineAPI.createLoginRequest(loginApiRequest);
        //assert
        Assert.assertEquals(loginApiResponse.getStatus().booleanValue(),true,"\nValues did not match for status");
    }
    @Test
    public void triggerLoginAuthApiWithWrongUserName() throws Exception {
        //arrange
        LoginApiRequest loginApiRequest=new LoginApiRequest.Builder()
                .username("xxyz")
                .password(new OnlineApiDataPropertiesConfig().getProperty("password"))
                .build();
        //act
        LoginApiResponse loginApiResponse= responseServiceOnlineAPI.createLoginRequest(loginApiRequest);
        //assert
        Assert.assertEquals(loginApiResponse.getStatus().booleanValue(),false,"\nValues did not match for status");
        Assert.assertEquals(loginApiResponse.getResponseMessage(),"invalid username/password");
    }
    @Test
    public void triggerLoginAuthApiWithWrongPassword() throws Exception {
        //arrange
        LoginApiRequest loginApiRequest=new LoginApiRequest.Builder()
                .username(new OnlineApiDataPropertiesConfig().getProperty("username"))
                .password("xyzx")
                .build();
        //act
        LoginApiResponse loginApiResponse= responseServiceOnlineAPI.createLoginRequest(loginApiRequest);
        //assert
        Assert.assertEquals(loginApiResponse.getStatus().booleanValue(),false,"\nValues did not match for status");
        Assert.assertEquals(loginApiResponse.getResponseMessage(),"invalid username/password");
    }

}
