package com.pinelabs.PayLater.MpgsAPITest;

import com.pinelabs.PayLater.API.Helpers.BaseUtils;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS.AcceptOfferRequest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS.CartOfferRequest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS.SerialNumbersRequest;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoMPGS.AcceptOfferResponse;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoMPGS.CartOfferResponse;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoMPGS.SerialNumbersResponse;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceMPGS;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.pinelabs.PayLater.API.Helpers.BaseUtils.getJsonArrayToListOfHashMap;
import static org.testng.Assert.assertEquals;

public class SerialNumbersTest extends BaseUtils {

    @BeforeSuite
    public void setReportName(){
        System.setProperty("ReportName","MPGS");
    }
    private ResponseServiceMPGS responseServiceMPGS;

    @BeforeClass
    private void beforeClass() {
        responseServiceMPGS = new ResponseServiceMPGS();
    }
    @Test(dataProvider = "getData",description = "hitting serial Number API for which cart id is accepted_serial_numbers_required")
    public void serialNumbersTC_01(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        List<AcceptOfferRequest.Items> listOfItem1=new ArrayList<>();
        listOfItem1.add(new AcceptOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity"),new String[] {}));
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).items(listOfItem1).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);

        //Serial Numbers API
        List<SerialNumbersRequest.UpdatedItems> listOfItem2=new ArrayList<>();
        listOfItem2.add(new SerialNumbersRequest.UpdatedItems().setItems(input.get("sku").toString(), new String[] {"435"}));
        SerialNumbersRequest serialNumbersRequest = new SerialNumbersRequest.Builder().updatedItems(listOfItem2).build();
        SerialNumbersResponse serialNumbersResponse = responseServiceMPGS
                .serialNumbersRequest(serialNumbersRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);
        assertEquals(serialNumbersResponse.getStatusCode(),200);
        assertEquals(serialNumbersResponse.getResponse(),"ACCEPTED");
    }

    @Test(dataProvider = "getData",description = "hitting serial Number API for which cart id is ACCEPTED already")
    public void serialNumbersTC_02(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        List<AcceptOfferRequest.Items> listOfItem1=new ArrayList<>();
        listOfItem1.add(new AcceptOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity"),new String[] {"235"}));
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).items(listOfItem1).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);

        //Serial Numbers API
        List<SerialNumbersRequest.UpdatedItems> listOfItem2=new ArrayList<>();
        listOfItem2.add(new SerialNumbersRequest.UpdatedItems().setItems(input.get("sku").toString(), new String[] {"435"}));
        SerialNumbersRequest serialNumbersRequest = new SerialNumbersRequest.Builder().updatedItems(listOfItem2).build();
        SerialNumbersResponse serialNumbersResponse = responseServiceMPGS
                .serialNumbersRequest(serialNumbersRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);
        assertEquals(serialNumbersResponse.getStatusCode(),200);
        assertEquals(serialNumbersResponse.getResponse(),"REJECTED");
        assertEquals(serialNumbersResponse.getSerialNumberRejections()[0].getReason(),"Serial number validation not applicable for this product");
    }

    @Test(dataProvider = "getData",description = "hitting serial Number API with invalid pid")
    public void serialNumbersTC_03(HashMap<Object, Object> input) throws Exception {

        //Serial Numbers API
        List<SerialNumbersRequest.UpdatedItems> listOfItem2=new ArrayList<>();
        listOfItem2.add(new SerialNumbersRequest.UpdatedItems().setItems(input.get("sku").toString(), new String[] {"435"}));
        SerialNumbersRequest serialNumbersRequest = new SerialNumbersRequest.Builder().updatedItems(listOfItem2).build();
        SerialNumbersResponse serialNumbersResponse = responseServiceMPGS
                .serialNumbersRequest(serialNumbersRequest, token(), input.get("BrandMerchantId").toString(), "23422");
        assertEquals(serialNumbersResponse.getStatusCode(),400);
        assertEquals(serialNumbersResponse.getErrors()[0].getDescription(),"ERROR_5001::Invalid PID");
    }

    @Test(dataProvider = "getData",description = "hitting serial Number API with blank sku")
    public void serialNumbersTC_04(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Serial Numbers API
        List<SerialNumbersRequest.UpdatedItems> listOfItem2=new ArrayList<>();
        listOfItem2.add(new SerialNumbersRequest.UpdatedItems().setItems("", new String[] {"435"}));
        SerialNumbersRequest serialNumbersRequest = new SerialNumbersRequest.Builder().updatedItems(listOfItem2).build();
        SerialNumbersResponse serialNumbersResponse = responseServiceMPGS
                .serialNumbersRequest(serialNumbersRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);
        assertEquals(serialNumbersResponse.getStatusCode(),400);
        assertEquals(serialNumbersResponse.getErrors()[0].getField(),"updatedItems[0].sku");
        assertEquals(serialNumbersResponse.getErrors()[0].getDescription(),"size must be between 1 and 127");
    }

    @Test(dataProvider = "getData",description = "hitting serial Number API with non brand merchant details")
    public void serialNumbersTC_05(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("CIBMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //Accept offer api
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("CIBMerchantId").toString(), cartOfferId);

        //Serial Numbers API
        List<SerialNumbersRequest.UpdatedItems> listOfItem2=new ArrayList<>();
        listOfItem2.add(new SerialNumbersRequest.UpdatedItems().setItems(input.get("sku").toString(), new String[] {"435"}));
        SerialNumbersRequest serialNumbersRequest = new SerialNumbersRequest.Builder().updatedItems(listOfItem2).build();
        SerialNumbersResponse serialNumbersResponse = responseServiceMPGS
                .serialNumbersRequest(serialNumbersRequest, token(), input.get("CIBMerchantId").toString(), cartOfferId);
        assertEquals(serialNumbersResponse.getStatusCode(),200);
        assertEquals(serialNumbersResponse.getResponse(),"REJECTED");
        assertEquals(serialNumbersResponse.getSerialNumberRejections()[0].getReason(),"Serial number validation not applicable for this product");
    }

    @Test(dataProvider = "getData",description = "hitting serial Number API with empty serial numbers")
    public void serialNumbersTC_06(HashMap<Object, Object> input) throws Exception {

        //Hitting cart offer API to get cart offer Id
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        String cartOfferId = cartOfferResponse.getOffers()[0].getCartOfferId();

        //accept offer API
        List<AcceptOfferRequest.Items> listOfItem1=new ArrayList<>();
        listOfItem1.add(new AcceptOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount")
                ,(Integer) input.get("quantity"),new String[] {}));
        AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest.Builder()
                .deliveryCountry(input.get("deliveryCountry").toString()).currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .paymentAmount(input.get("paymentAmount").toString()).termsAndConditionsAcceptance("ACCEPTED")
                .cartOfferId(cartOfferId).mask(input.get("mask").toString()).raw(input.get("raw").toString())
                .cardNumberPrefix(input.get("cardNumberPrefix").toString()).items(listOfItem1).build();
        AcceptOfferResponse acceptOfferResponse = responseServiceMPGS
                .acceptOfferRequest(acceptOfferRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);


        //Serial Numbers API
        List<SerialNumbersRequest.UpdatedItems> listOfItem2=new ArrayList<>();
        listOfItem2.add(new SerialNumbersRequest.UpdatedItems().setItems(input.get("sku").toString(), new String[] {}));
        SerialNumbersRequest serialNumbersRequest = new SerialNumbersRequest.Builder().updatedItems(listOfItem2).build();
        SerialNumbersResponse serialNumbersResponse = responseServiceMPGS
                .serialNumbersRequest(serialNumbersRequest, token(), input.get("BrandMerchantId").toString(), cartOfferId);
        assertEquals(serialNumbersResponse.getStatusCode(),500);
        assertEquals(serialNumbersResponse.getErrors()[0].getDescription(),"ERROR_500::Index: 0, Size: 0");
    }

    @DataProvider
    public Object[][] getData() throws IOException {
        OnlineApiDataPropertiesConfig dataProperties =new OnlineApiDataPropertiesConfig();
        List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                (System.getProperty("user.dir")+ dataProperties.getProperty("MPGSData"));
        Object[][] obj= new Object[data.size()][1];
        for(int i=0;i<data.size();i++){
            obj[i][0]=data.get(i);
        }
        return obj;
    }
}
