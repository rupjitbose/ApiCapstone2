package com.pinelabs.PayLater.CrossBorderTest;

import com.pinelabs.PayLater.API.Helpers.BaseUtils;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.API.Helpers.RetryTest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.MciCurrencyConversionRequest;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.MciCurrencyConversionResponse;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceOnlineAPI;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;


public class CurrencyConversionTest extends BaseUtils {

    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void check(HashMap<Object,Object> input) throws Exception {
        System.out.println(currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString())));
    }

    @DataProvider
    public Object[][] getData() throws IOException {
        OnlineApiDataPropertiesConfig dataProperties =new OnlineApiDataPropertiesConfig();
        List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                (System.getProperty("user.dir")+ dataProperties.getProperty("CrossBorderData"));
        Object[][] obj= new Object[data.size()][1];
        for(int i=0;i<data.size();i++){
            obj[i][0]=data.get(i);
        }
        return  obj;
    }
}
