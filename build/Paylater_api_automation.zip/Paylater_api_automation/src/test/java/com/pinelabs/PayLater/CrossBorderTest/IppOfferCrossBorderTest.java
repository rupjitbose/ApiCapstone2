package com.pinelabs.PayLater.CrossBorderTest;

import com.pinelabs.PayLater.API.Helpers.BaseUtils;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.API.Helpers.RetryTest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.IppOfferRequest;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.IppOfferResponse;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceOnlineAPI;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

public class IppOfferCrossBorderTest extends BaseUtils {
    @BeforeSuite
    public void setReportName(){
        System.setProperty("ReportName","CrossBorderOnlineAPI");
    }
    private ResponseServiceOnlineAPI responseServiceOnlineAPI;
    @BeforeClass()
    private void beforeClass() {responseServiceOnlineAPI = new ResponseServiceOnlineAPI();}
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class, description="trigger Cross Border IppOffer Api With Correct DataSet")
    public void crossBorderIppOfferApi_TC01(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(currencyConverter(
                        input.get("merchantCurrencyCode").toString(),
                        input.get("issuerCurrencyCode").toString(),
                        Double.parseDouble(input.get("totalAmount").toString())))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        //act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest,token());
        //assert
        Assert.assertEquals(ippOfferResponse.getStatusCode(), 200);
        Assert.assertEquals(ippOfferResponse.getMerchantId(), input.get("merchantId").toString());
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border IppOffer Api With Converted Amount Not In Scheme Range")
    public void crossBorderIppOfferApi_TC02(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(currencyConverter(
                        input.get("merchantCurrencyCode").toString(),
                        input.get("issuerCurrencyCode").toString(),
                        Double.parseDouble(input.get("invalidTotalAmount").toString())))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        //act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI
                .createIppOfferRequest(ippOfferRequest,token());
        //assert
        Assert.assertEquals(ippOfferResponse.getStatusCode(), 400);
        Assert.assertEquals(ippOfferResponse.getErrors()[0].getMessage(),
                "No schemes present for the value in total amount field");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border IppOffer Api With Invalid Merchant ID Should Throw Error")
    public void crossBorderIppOfferApi_TC03(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(currencyConverter(
                        input.get("merchantCurrencyCode").toString(),
                        input.get("issuerCurrencyCode").toString(),
                        Double.parseDouble(input.get("invalidTotalAmount").toString())))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId("xyztestdata").build();
        //act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI
                .createIppOfferRequest(ippOfferRequest,token());
        //assert
        Assert.assertEquals(ippOfferResponse.getStatusCode(), 400);
        Assert.assertEquals(ippOfferResponse.getErrors()[0].getMessage(),
                "Field Name merchantId has invalid value.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border IppOffer Api With Invalid Country Code Should Throw Error")
    public void crossBorderIppOfferApi_TC04(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(currencyConverter(
                        input.get("merchantCurrencyCode").toString(),
                        input.get("issuerCurrencyCode").toString(),
                        Double.parseDouble(input.get("invalidTotalAmount").toString())))
                .issuerCountryCode(999)
                .merchantId(input.get("merchantId").toString()).build();
        //act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI
                .createIppOfferRequest(ippOfferRequest,token());
        //assert
        Assert.assertEquals(ippOfferResponse.getStatusCode(), 400);
        Assert.assertEquals(ippOfferResponse.getErrors()[0].getMessage(),
                "Currency not found for given issuer country.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border IppOffer Api With Merchant Country Code Should Throw Error")
    public void crossBorderIppOfferApi_TC05(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(currencyConverter(
                        input.get("merchantCurrencyCode").toString(),
                        input.get("issuerCurrencyCode").toString(),
                        Double.parseDouble(input.get("invalidTotalAmount").toString())))
                .issuerCountryCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        //act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI
                .createIppOfferRequest(ippOfferRequest,token());
        //assert
        Assert.assertEquals(ippOfferResponse.getStatusCode(), 400);
        Assert.assertEquals(ippOfferResponse.getErrors()[0].getMessage(),
                "No scheme found for the issuer country code");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border IppOffer Api With Amount 'Null' Should Throw Error")
    public void crossBorderIppOfferApi_TC06(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(null)
                .issuerCountryCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        //act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI
                .createIppOfferRequest(ippOfferRequest,token());
        //assert
        Assert.assertEquals(ippOfferResponse.getStatusCode(), 400);
        Assert.assertEquals(ippOfferResponse.getErrors()[0].getMessage(),
                "Invalid Request.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border IppOffer Api With Amount '0' Should Throw Error")
    public void crossBorderIppOfferApi_TC07(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(0.0)
                .issuerCountryCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        //act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI
                .createIppOfferRequest(ippOfferRequest,token());
        //assert
        Assert.assertEquals(ippOfferResponse.getStatusCode(), 400);
        Assert.assertEquals(ippOfferResponse.getErrors()[0].getMessage(),
                "invalid Amount");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border IppOffer Api With Negative Amount Should Throw Error")
    public void crossBorderIppOfferApi_TC08(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(-100.0)
                .issuerCountryCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        //act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI
                .createIppOfferRequest(ippOfferRequest,token());
        //assert
        Assert.assertEquals(ippOfferResponse.getStatusCode(), 400);
        Assert.assertEquals(ippOfferResponse.getErrors()[0].getMessage(),
                "invalid Amount");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border IppOffer Api With Invalid Access Token Should Throw Error")
    public void crossBorderIppOfferApi_TC09(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(currencyConverter(
                        input.get("merchantCurrencyCode").toString(),
                        input.get("issuerCurrencyCode").toString(),
                        Double.parseDouble(input.get("invalidTotalAmount").toString())))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        //act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI
                .createIppOfferRequest(ippOfferRequest,"invalid token");
        //assert
        Assert.assertEquals(ippOfferResponse.getStatusCode(), 401);
        Assert.assertEquals(ippOfferResponse.getMsg(),
                "Unauthorized Request");
    }

    @DataProvider
    public Object[][] getData() throws IOException {
        OnlineApiDataPropertiesConfig dataProperties =new OnlineApiDataPropertiesConfig();
        List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                (System.getProperty("user.dir")+ dataProperties.getProperty("CrossBorderData"));
        Object[][] obj= new Object[data.size()][1];
        for(int i=0;i<data.size();i++){
            obj[i][0]=data.get(i);
        }
        return  obj;
    }
}
