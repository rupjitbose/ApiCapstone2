package com.pinelabs.PayLater.CrossBorderTest;

import com.pinelabs.PayLater.API.Helpers.BaseUtils;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.API.Helpers.RetryTest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.EmiCalculatorRequest;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.EmiCalculatorResponse;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceOnlineAPI;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

public class EmiCalculatorCrossBorderTest extends BaseUtils {
    @BeforeSuite
    public void setReportName(){
        System.setProperty("ReportName","CrossBorderOnlineAPI");
    }
    private ResponseServiceOnlineAPI responseServiceOnlineAPI;
    @BeforeClass
    public void beforeClass() {
        responseServiceOnlineAPI = new ResponseServiceOnlineAPI();
    }

    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="Cross Border Emi Calculator Check currency conversion is 'ture' for cross border")
    public void emiCalculatorCrossBorder_TC01(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        EmiCalculatorRequest emiCalculatorRequest = new EmiCalculatorRequest.Builder()
                .amount(convertedAmount)
                .installmentConfigId(input.get("installmentConfigId").toString())
                .installmentConfigType(input.get("installmentConfigType").toString())
                .issuerId(input.get("issuerId").toString())
                .terminalId(input.get("terminalId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .merchantCurrencyCode(input.get("merchantCurrencyCode").toString())
                .issuerCurrencyCode(input.get("issuerCurrencyCode").toString())
                .issuerCountryCodeNum(Integer.parseInt(input.get("issuerCountryCodeNum").toString())).build();

        EmiCalculatorResponse emiCalculatorResponse = responseServiceOnlineAPI.emiCalculatorRequest(emiCalculatorRequest, token());
        Assert.assertEquals(emiCalculatorResponse.getStatusCode(),200);
        Assert.assertTrue(emiCalculatorResponse.getAttrs()[20].getValue().contains("true"));
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="Cross Border Emi Calculator With Invalid Amount should throw error")
    public void emiCalculatorCrossBorder_TC02(HashMap<Object,Object> input) throws Exception {
        EmiCalculatorRequest emiCalculatorRequest = new EmiCalculatorRequest.Builder()
                .amount(0)
                .installmentConfigId(input.get("installmentConfigId").toString())
                .installmentConfigType(input.get("installmentConfigType").toString())
                .issuerId(input.get("issuerId").toString()).terminalId(input.get("terminalId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .merchantCurrencyCode(input.get("merchantCurrencyCode").toString())
                .issuerCurrencyCode(input.get("issuerCurrencyCode").toString())
                .issuerCountryCodeNum(Integer.parseInt(input.get("issuerCountryCodeNum").toString())).build();
        EmiCalculatorResponse emiCalculatorResponse = responseServiceOnlineAPI.emiCalculatorRequest(emiCalculatorRequest, token());
        Assert.assertEquals(emiCalculatorResponse.getStatusCode(),400);
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getCode(),"ERROR_1082");
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getMessage(),"invalid Amount");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="Cross Border Emi Calculator with Invalid Instalment ConfigId Should Show Error")
    public void emiCalculatorCrossBorder_TC03(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        EmiCalculatorRequest emiCalculatorRequest = new EmiCalculatorRequest.Builder()
                .amount(convertedAmount)
                .installmentConfigId("01010101010")
                .installmentConfigType(input.get("installmentConfigType").toString())
                .issuerId(input.get("issuerId").toString()).terminalId(input.get("terminalId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .merchantCurrencyCode(input.get("merchantCurrencyCode").toString())
                .issuerCurrencyCode(input.get("issuerCurrencyCode").toString())
                .issuerCountryCodeNum(Integer.parseInt(input.get("issuerCountryCodeNum").toString())).build();

        EmiCalculatorResponse emiCalculatorResponse = responseServiceOnlineAPI.emiCalculatorRequest(emiCalculatorRequest, token());
        Assert.assertEquals(emiCalculatorResponse.getStatusCode(), 400);
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getCode(),"ERROR_1056");
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getMessage(),"Scheme not found.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="Cross Border Emi Calculator with Blank Instalment Config Type")
    public void emiCalculatorCrossBorder_TC04(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        EmiCalculatorRequest emiCalculatorRequest = new EmiCalculatorRequest.Builder()
                .amount(convertedAmount)
                .installmentConfigId(input.get("installmentConfigId").toString())
                .installmentConfigType("")
                .issuerId(input.get("issuerId").toString()).terminalId(input.get("terminalId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .merchantCurrencyCode(input.get("merchantCurrencyCode").toString())
                .issuerCurrencyCode(input.get("issuerCurrencyCode").toString())
                .issuerCountryCodeNum(Integer.parseInt(input.get("issuerCountryCodeNum").toString())).build();

        EmiCalculatorResponse emiCalculatorResponse = responseServiceOnlineAPI.emiCalculatorRequest(emiCalculatorRequest, token());
        Assert.assertEquals(emiCalculatorResponse.getStatusCode(), 400);
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getCode(),"ERROR_4090");
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getMessage(),"EMPTY INSTALLMENT CONFIG TYPE");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="Cross Border Emi Calculator with Invalid IssuerId")
    public void emiCalculatorCrossBorder_TC05(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        EmiCalculatorRequest emiCalculatorRequest = new EmiCalculatorRequest.Builder()
                .amount(convertedAmount)
                .installmentConfigId(input.get("installmentConfigId").toString())
                .installmentConfigType(input.get("installmentConfigType").toString())
                .issuerId("6024d33321db3aa7f1d27b").terminalId(input.get("terminalId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .merchantCurrencyCode(input.get("merchantCurrencyCode").toString())
                .issuerCurrencyCode(input.get("issuerCurrencyCode").toString())
                .issuerCountryCodeNum(Integer.parseInt(input.get("issuerCountryCodeNum").toString())).build();

        EmiCalculatorResponse emiCalculatorResponse = responseServiceOnlineAPI.emiCalculatorRequest(emiCalculatorRequest, token());
        Assert.assertEquals(emiCalculatorResponse.getStatusCode(), 400);
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getCode(),"ERROR_1049");
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getMessage(),"Field Name issuerId is either null or has invalid value.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="Cross Border Emi Calculator with Invalid Tenure")
    public void emiCalculatorCrossBorder_TC06(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        EmiCalculatorRequest emiCalculatorRequest = new EmiCalculatorRequest.Builder()
                .amount(convertedAmount)
                .installmentConfigId(input.get("installmentConfigId").toString())
                .installmentConfigType(input.get("installmentConfigType").toString())
                .issuerId(input.get("issuerId").toString()).terminalId(input.get("terminalId").toString())
                .tenure(7)
                .merchantCurrencyCode(input.get("merchantCurrencyCode").toString())
                .issuerCurrencyCode(input.get("issuerCurrencyCode").toString())
                .issuerCountryCodeNum(Integer.parseInt(input.get("issuerCountryCodeNum").toString())).build();

        EmiCalculatorResponse emiCalculatorResponse = responseServiceOnlineAPI.emiCalculatorRequest(emiCalculatorRequest, token());
        Assert.assertEquals(emiCalculatorResponse.getStatusCode(), 400);
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getCode(),"ERROR_1085");
        Assert.assertEquals(emiCalculatorResponse.getErrors()[0].getMessage(),"invalid tenure");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="Cross Border Emi Calculator with Blank Terminal Id")
    public void emiCalculatorCrossBorder_TC07(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        EmiCalculatorRequest emiCalculatorRequest = new EmiCalculatorRequest.Builder()
                .amount(convertedAmount)
                .installmentConfigId(input.get("installmentConfigId").toString())
                .installmentConfigType(input.get("installmentConfigType").toString())
                .issuerId(input.get("issuerId").toString()).terminalId(input.get("terminalId").toString())
                .terminalId("")
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .merchantCurrencyCode(input.get("merchantCurrencyCode").toString())
                .issuerCurrencyCode(input.get("issuerCurrencyCode").toString())
                .issuerCountryCodeNum(Integer.parseInt(input.get("issuerCountryCodeNum").toString())).build();

        EmiCalculatorResponse emiCalculatorResponse = responseServiceOnlineAPI.emiCalculatorRequest(emiCalculatorRequest, token());
        Assert.assertEquals(emiCalculatorResponse.getStatusCode(), 200);
        Assert.assertEquals(emiCalculatorResponse.getMsg(),
                "Terminal Id should not be Empty ");
    }

    @DataProvider
    public Object[][] getData() throws IOException {
        OnlineApiDataPropertiesConfig dataProperties=new OnlineApiDataPropertiesConfig();
        List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                (System.getProperty("user.dir")+ dataProperties.getProperty("CrossBorderData"));
        Object[][] obj= new Object[data.size()][1];
        for(int i=0;i<data.size();i++){
            obj[i][0]=data.get(i);
        }
        return  obj;
    }

}
