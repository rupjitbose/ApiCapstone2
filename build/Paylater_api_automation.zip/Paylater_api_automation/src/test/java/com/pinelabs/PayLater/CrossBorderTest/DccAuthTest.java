package com.pinelabs.PayLater.CrossBorderTest;

import com.pinelabs.PayLater.API.Helpers.BaseUtils;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.API.Helpers.PLEncrypt.PLEncrypt;
import com.pinelabs.PayLater.API.Helpers.RetryTest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.IppOfferRequest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.TransactionStatusRequest;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.IppOfferResponse;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.TransactionStatusResponse;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceOnlineAPI;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

public class DccAuthTest extends BaseUtils {
    @BeforeSuite
    public void setReportName(){System.setProperty("ReportName","CrossBorderOnlineAPI");}
    private ResponseServiceOnlineAPI responseServiceOnlineAPI;
    @BeforeClass()
    private void beforeClass() {responseServiceOnlineAPI = new ResponseServiceOnlineAPI();}
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="trigger Cross Border Transaction Sale Api With cross border as 1 and dcc auth as 0 " +
            "and check if is_cross_border_txn=1 and dcc_auth=0 in DB")
    public void crossBorderDBTest_TC1(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //IppOffer API
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //indexing
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo=input.get("cardNumber").toString();
        String comboOfEncryptKey= PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest=new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse= responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest,token());
        //assert
        Assert.assertEquals(transactionStatusResponse.getStatusCode(),200);
        Assert.assertEquals(transactionStatusResponse.getMerchantId(),input.get("merchantId").toString());
        Assert.assertEquals(transactionStatusResponse.getCardNumber(),Integer.parseInt(input.get("cardNumber").toString().substring(0,8)));
        assertTransactionInDB(transactionStatusResponse.getTransactionId(),9);
        assertFieldValueInTransactionDB("sale", transactionStatusResponse.getTransactionId(), "is_cross_border_txn", "1");
    }

    @DataProvider
    public Object[][] getData() throws IOException {
        OnlineApiDataPropertiesConfig dataProperties =new OnlineApiDataPropertiesConfig();
        List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                (System.getProperty("user.dir")+ dataProperties.getProperty("CrossBorderData"));
        Object[][] obj= new Object[data.size()][1];
        for(int i=0;i<data.size();i++){
            obj[i][0]=data.get(i);
        }
        return  obj;
    }
}
