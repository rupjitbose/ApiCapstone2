package com.pinelabs.PayLater.OnlineAPITest;

import com.pinelabs.PayLater.API.Helpers.BaseUtils;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.API.Helpers.PLEncrypt.PLEncrypt;
import com.pinelabs.PayLater.API.Helpers.RetryTest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.*;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.*;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceOnlineAPI;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

public class AuthCancelTest extends BaseUtils {
    @BeforeSuite
    public void setReportName(){
        System.setProperty("ReportName","OnlineAPI");
    }
    private ResponseServiceOnlineAPI responseServiceOnlineAPI;
    @BeforeClass
    private void beforeClass() {
        responseServiceOnlineAPI = new ResponseServiceOnlineAPI();}

    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void AuthCancelPositiveFlow(HashMap<Object,Object> input) throws Exception {

      //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);


        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(7)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(0)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        long transactionId = transactionStatusResponse.getTransactionId();
       AuthCancelRequest authCancelRequest = new AuthCancelRequest.Builder()
        //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .transactionAmount(Double.parseDouble(input.get("totalAmount").toString()))
               //get transaction Id from transaction API response
               .transactionId(transactionId).build();

        AuthCancelResponse authCancelResponse = responseServiceOnlineAPI.
                authCancelRequest(authCancelRequest, token());

        Assert.assertEquals(authCancelResponse.getStatusCode(),200);
        Assert.assertEquals(authCancelResponse.getMerchantId(),input.get("merchantId").toString());
        Assert.assertEquals(authCancelResponse.getTransactionId(),transactionId);
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void triggerAuthCancelTwice(HashMap<Object,Object> input) throws Exception {
//Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest,token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);


        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(7)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(0)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        long transactionId = transactionStatusResponse.getTransactionId();
        AuthCancelRequest authCancelRequest = new AuthCancelRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .transactionAmount(Double.parseDouble(input.get("totalAmount").toString()))
                //get transaction Id from transaction API response
                .transactionId(transactionId).build();

        AuthCancelResponse authCancelResponse = responseServiceOnlineAPI.
                authCancelRequest(authCancelRequest, token());

        AuthCancelResponse authCancelResponse1 = responseServiceOnlineAPI.
                authCancelRequest(authCancelRequest, token());

        Assert.assertEquals(authCancelResponse1.getStatusCode(),400);
        Assert.assertEquals(authCancelResponse1.getErrors()[0].getMessage(),
                "Auth cancel not allowed as transaction id : "+transactionId+" status is not auth.");
        Assert.assertEquals(authCancelResponse1.getErrors()[0].getCode(),"ERROR_4111");

    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void triggerAuthCancelForCaptureTxnType(HashMap<Object,Object> input) throws Exception {
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);


        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(7)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(0)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        long transactionId = transactionStatusResponse.getTransactionId();

        //Arrange data for auth capture API
        AuthCaptureRequest authCaptureRequest=new AuthCaptureRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .transactionId(transactionId)
                .build();

        //Send request for auth capture API
        AuthCaptureResponse authCaptureResponse= responseServiceOnlineAPI
                .authCaptureRequest(authCaptureRequest,token());

        AuthCancelRequest authCancelRequest = new AuthCancelRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .transactionAmount(Double.parseDouble(input.get("totalAmount").toString()))
                //get transaction Id from transaction API response
                .transactionId(transactionId).build();

        AuthCancelResponse authCancelResponse = responseServiceOnlineAPI.
                authCancelRequest(authCancelRequest, token());

        Assert.assertEquals(authCancelResponse.getStatusCode(),400);
       Assert.assertEquals(authCancelResponse.getErrors()[0].getMessage(),
                "Auth cancel not allowed as transaction id : "+transactionId+" status is not auth.");
        Assert.assertEquals(authCancelResponse.getErrors()[0].getCode(),"ERROR_4111");

    }
    @Test(dataProvider = "getData",retryAnalyzer= RetryTest.class)
    public void triggerAuthCancelforSaleTxnType(HashMap<Object,Object> input) throws Exception {
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);


        //Placing a sale transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(0)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        long transactionId = transactionStatusResponse.getTransactionId();

        //arrange data for auth cancel API
        AuthCancelRequest authCancelRequest = new AuthCancelRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .transactionAmount(Double.parseDouble(input.get("totalAmount").toString()))
                //get transaction Id from transaction API response
                .transactionId(transactionId).build();

        AuthCancelResponse authCancelResponse = responseServiceOnlineAPI.
                authCancelRequest(authCancelRequest, token());

        Assert.assertEquals(authCancelResponse.getStatusCode(),400);
       Assert.assertEquals(authCancelResponse.getErrors()[0].getMessage(),
                "Auth cancel not allowed as transaction id : "+transactionId+" status is not auth.");
        Assert.assertEquals(authCancelResponse.getErrors()[0].getCode(),"ERROR_4111");
    }
    @Test(dataProvider = "getData",retryAnalyzer= RetryTest.class)
    public void triggerAuthCancelforRefundedTxnType(HashMap<Object,Object> input) throws Exception {
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);


        //Placing a sale transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(0)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        long transactionId = transactionStatusResponse.getTransactionId();

        //arrange
        RefundApiRequest refundApiRequest=new RefundApiRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .refundDateTime(input.get("refundDateTime").toString())
                .transactionId(transactionId)
                .transactionAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .build();
        //Act
        RefundApiResponse refundApiResponse= responseServiceOnlineAPI
                .refundRequest(refundApiRequest,token());

        //arrange data for auth cancel API
        AuthCancelRequest authCancelRequest = new AuthCancelRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .transactionAmount(Double.parseDouble(input.get("totalAmount").toString()))
                //get transaction Id from transaction API response
                .transactionId(transactionId).build();

        AuthCancelResponse authCancelResponse = responseServiceOnlineAPI.
                authCancelRequest(authCancelRequest, token());

        Assert.assertEquals(authCancelResponse.getStatusCode(),400);
       Assert.assertEquals(authCancelResponse.getErrors()[0].getMessage(),
                "Auth cancel not allowed as transaction id : "+transactionId+" status is not auth.");
        Assert.assertEquals(authCancelResponse.getErrors()[0].getCode(),"ERROR_4111");
    }
    @Test(dataProvider = "getData",retryAnalyzer= RetryTest.class)
    public void triggerAuthCancelAPIwithInvalidMerchantId(HashMap<Object,Object> input) throws Exception {
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);


        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(7)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(0)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        long transactionId = transactionStatusResponse.getTransactionId();

        //arrange data for auth cancel API
        AuthCancelRequest authCancelRequest = new AuthCancelRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId("63f80a7912ed")
                .pspId(input.get("pspId").toString())
                .transactionAmount(Double.parseDouble(input.get("totalAmount").toString()))
                //get transaction Id from transaction API response
                .transactionId(transactionId).build();

        AuthCancelResponse authCancelResponse = responseServiceOnlineAPI.
                authCancelRequest(authCancelRequest, token());

        Assert.assertEquals(authCancelResponse.getStatusCode(),400);
       Assert.assertEquals(authCancelResponse.getErrors()[0].getMessage(),
                "Field Name merchantId has invalid value.");
        Assert.assertEquals(authCancelResponse.getErrors()[0].getCode(),"ERROR_1025");
    }
    @Test(dataProvider = "getData",retryAnalyzer= RetryTest.class)
    public void triggerAuthCancelAPIwithInvalidPSPId(HashMap<Object,Object> input) throws Exception {
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);


        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(7)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(0)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        long transactionId = transactionStatusResponse.getTransactionId();

        //arrange data for auth cancel API
        AuthCancelRequest authCancelRequest = new AuthCancelRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .pspId("87698752")
                .transactionAmount(Double.parseDouble(input.get("totalAmount").toString()))
                //get transaction Id from transaction API response
                .transactionId(transactionId).build();

        AuthCancelResponse authCancelResponse = responseServiceOnlineAPI.
                authCancelRequest(authCancelRequest, token());

        Assert.assertEquals(authCancelResponse.getStatusCode(),400);
       Assert.assertEquals(authCancelResponse.getErrors()[0].getMessage(),
                "Invalid PSP ID");
        Assert.assertEquals(authCancelResponse.getErrors()[0].getCode(),"ERROR_4112");
    }
    @Test(dataProvider = "getData",retryAnalyzer= RetryTest.class)
    public void triggerAuthCancelAPIwithDifferentAmount(HashMap<Object,Object> input) throws Exception {
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);


        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(7)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(0)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        long transactionId = transactionStatusResponse.getTransactionId();

        //arrange data for auth cancel API
        AuthCancelRequest authCancelRequest = new AuthCancelRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                        .pspId(input.get("pspId").toString())
                        .transactionAmount(Double.parseDouble("500"))
                        //get transaction Id from transaction API response
                        .transactionId(transactionId).build();

        AuthCancelResponse authCancelResponse = responseServiceOnlineAPI.
                authCancelRequest(authCancelRequest, token());

        Assert.assertEquals(authCancelResponse.getStatusCode(),400);
       Assert.assertEquals(authCancelResponse.getErrors()[0].getMessage(),
                "invalid Amount");
        Assert.assertEquals(authCancelResponse.getErrors()[0].getCode(),"ERROR_1082");
    }
    @Test(dataProvider = "getData",retryAnalyzer= RetryTest.class)
    public void triggerAuthCancelAPIwithoutRequestId(HashMap<Object,Object> input) throws Exception {
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);


        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(7)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(0)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        long transactionId = transactionStatusResponse.getTransactionId();

        //arrange data for auth cancel API
        AuthCancelRequest authCancelRequest = new AuthCancelRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .transactionAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .requestId("")
                //get transaction Id from transaction API response
                .transactionId(transactionId).build();

        AuthCancelResponse authCancelResponse = responseServiceOnlineAPI.
                authCancelRequest(authCancelRequest, token());
       Assert.assertEquals(authCancelResponse.getStatusCode(),400);
       Assert.assertEquals(authCancelResponse.getErrors()[0].getMessage(),
                "requestId is required in request body");
        Assert.assertEquals(authCancelResponse.getErrors()[0].getCode(),"ERROR_4029");
    }
    @Test(dataProvider = "getData",retryAnalyzer= RetryTest.class)
    public void triggerAuthCancelAPIinvalidTransactionId(HashMap<Object,Object> input) throws Exception {
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);

        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(7)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(0)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());

        //arrange data for auth cancel API
        AuthCancelRequest authCancelRequest = new AuthCancelRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .transactionAmount(Double.parseDouble(input.get("totalAmount").toString()))
                //get transaction Id from transaction API response
                .transactionId(Long.parseLong("19789235")).build();

        AuthCancelResponse authCancelResponse = responseServiceOnlineAPI.
                authCancelRequest(authCancelRequest, token());

        Assert.assertEquals(authCancelResponse.getStatusCode(),400);
       Assert.assertEquals(authCancelResponse.getErrors()[0].getMessage(),
                "Invalid TransactionId ");
        Assert.assertEquals(authCancelResponse.getErrors()[0].getCode(),"ERROR_4002");
    }


    @DataProvider
    public Object[][] getData() throws IOException {
        OnlineApiDataPropertiesConfig dataProperties =new OnlineApiDataPropertiesConfig();
        List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                (System.getProperty("user.dir")+ dataProperties.getProperty("Data"));
        Object[][] obj= new Object[data.size()][1];
        for(int i=0;i<data.size();i++){
            obj[i][0]=data.get(i);
        }
        return  obj;
    }
}


