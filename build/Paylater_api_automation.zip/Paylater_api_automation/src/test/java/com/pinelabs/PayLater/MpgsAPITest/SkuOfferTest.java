package com.pinelabs.PayLater.MpgsAPITest;

import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS.MerchantCapabilityRequest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS.SkuOfferRequest;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoMPGS.MerchantCapabilityResponse;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoMPGS.SkuOfferResponse;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceMPGS;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.pinelabs.PayLater.API.Helpers.BaseUtils.getJsonArrayToListOfHashMap;
import static com.pinelabs.PayLater.API.Helpers.BaseUtils.token;

public class SkuOfferTest {

    @BeforeSuite
    public void setReportName(){
        System.setProperty("ReportName","MPGS");
    }
    private ResponseServiceMPGS responseServiceMPGS;

    @BeforeClass
    private void beforeClass() {
        responseServiceMPGS = new ResponseServiceMPGS();
    }

    @Test(dataProvider = "getData",description = "Check if response is getting valid for a valid merchant id for which brand scheme is mapped.")
    public void skuTC_01(HashMap<Object, Object> input) throws Exception {
        List<SkuOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku1").toString(),1000));
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku2").toString(),900));

        SkuOfferRequest skuOfferRequest = new SkuOfferRequest.Builder()
                .currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .merchantCountry(input.get("merchantCountry").toString())
                .items(listOfItem)
                .build();
        SkuOfferResponse skuOfferResponse= responseServiceMPGS
                .skuOfferRequest(skuOfferRequest,token(),input.get("BrandMerchantId").toString());
        Assert.assertEquals(skuOfferResponse.getStatusCode(),200);
        Assert.assertEquals(skuOfferResponse.getItems().size(),listOfItem.size());
    }
    @Test(dataProvider = "getData",description = "check When Invalid Merchant We Get Error")
    public void skuTC_02(HashMap<Object, Object> input) throws Exception {
        List<SkuOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku1").toString(),1000));
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku2").toString(),900));

        SkuOfferRequest skuOfferRequest = new SkuOfferRequest.Builder()
                .currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .merchantCountry(input.get("merchantCountry").toString())
                .items(listOfItem)
                .build();
        SkuOfferResponse skuOfferResponse= responseServiceMPGS
                .skuOfferRequest(skuOfferRequest,token(),"34567786564321");
        Assert.assertEquals(skuOfferResponse.getStatusCode(),400);
        Assert.assertEquals(skuOfferResponse.getErrors()[0].getDescription(),
                "ERROR_5011::No Sku Offer found for given input.");
    }
    @Test(dataProvider = "getData",description = "check When Invalid Currency We Get Error")
    public void skuTC_03(HashMap<Object, Object> input) throws Exception {
        List<SkuOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku1").toString(),1000));
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku2").toString(),900));

        SkuOfferRequest skuOfferRequest = new SkuOfferRequest.Builder()
                .currencyCode("HKA")
                .merchantCountry(input.get("merchantCountry").toString())
                .items(listOfItem)
                .build();
        SkuOfferResponse skuOfferResponse= responseServiceMPGS
                .skuOfferRequest(skuOfferRequest,token(),input.get("BrandMerchantId").toString());
        Assert.assertEquals(skuOfferResponse.getStatusCode(),400);
        Assert.assertEquals(skuOfferResponse.getErrors()[0].getDescription(),
                "ERROR_5011::No Sku Offer found for given input.");
    }
    @Test(dataProvider = "getData",description = "check When more than 3 chars in currency code We Get Error")
    public void skuTC_04(HashMap<Object, Object> input) throws Exception {
        List<SkuOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku1").toString(),1000));
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku2").toString(),900));

        SkuOfferRequest skuOfferRequest = new SkuOfferRequest.Builder()
                .currencyCode("HKKD")
                .merchantCountry(input.get("merchantCountry").toString())
                .items(listOfItem)
                .build();
        SkuOfferResponse skuOfferResponse= responseServiceMPGS
                .skuOfferRequest(skuOfferRequest,token(),input.get("BrandMerchantId").toString());
        Assert.assertEquals(skuOfferResponse.getStatusCode(),400);
        Assert.assertEquals(skuOfferResponse.getErrors()[0].getField(),
                "currencyCode");
        Assert.assertEquals(skuOfferResponse.getErrors()[0].getDescription(),
                "size must be between 3 and 3");
    }
    @Test(dataProvider = "getData",description = "check When less than 3 chars in currency code We Get Error")
    public void skuTC_05(HashMap<Object, Object> input) throws Exception {
        List<SkuOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku1").toString(),1000));
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku2").toString(),900));

        SkuOfferRequest skuOfferRequest = new SkuOfferRequest.Builder()
                .currencyCode("HK")
                .merchantCountry(input.get("merchantCountry").toString())
                .items(listOfItem)
                .build();
        SkuOfferResponse skuOfferResponse= responseServiceMPGS
                .skuOfferRequest(skuOfferRequest,token(),input.get("BrandMerchantId").toString());
        Assert.assertEquals(skuOfferResponse.getStatusCode(),400);
        Assert.assertEquals(skuOfferResponse.getErrors()[0].getField(),
                "currencyCode");
        Assert.assertEquals(skuOfferResponse.getErrors()[0].getDescription(),
                "size must be between 3 and 3");
    }

    @Test(dataProvider = "getData",description = "check When Invalid Merchant country We Get Error")
    public void skuTC_06(HashMap<Object, Object> input) throws Exception {
        List<SkuOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku1").toString(),1000));
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku2").toString(),900));

        SkuOfferRequest skuOfferRequest = new SkuOfferRequest.Builder()
                .currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .merchantCountry("XY")
                .items(listOfItem)
                .build();
        SkuOfferResponse skuOfferResponse= responseServiceMPGS
                .skuOfferRequest(skuOfferRequest,token(),input.get("BrandMerchantId").toString());
        Assert.assertEquals(skuOfferResponse.getStatusCode(),500);
        Assert.assertEquals(skuOfferResponse.getErrors()[0].getDescription(),
                "ERROR_500::Couldn't find 3-letter country code for XY");
    }

    @Test(dataProvider = "getData",description = "check When more than 2 chars in merchant country We Get Error")
    public void skuTC_07(HashMap<Object, Object> input) throws Exception {
        List<SkuOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku1").toString(),1000));
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku2").toString(),900));

        SkuOfferRequest skuOfferRequest = new SkuOfferRequest.Builder()
                .currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .merchantCountry("HKD")
                .items(listOfItem)
                .build();
        SkuOfferResponse skuOfferResponse= responseServiceMPGS
                .skuOfferRequest(skuOfferRequest,token(),input.get("BrandMerchantId").toString());
        Assert.assertEquals(skuOfferResponse.getStatusCode(),400);
        Assert.assertEquals(skuOfferResponse.getErrors()[0].getField(),
                "merchantCountry");
        Assert.assertEquals(skuOfferResponse.getErrors()[0].getDescription(),
                "size must be between 2 and 2");
    }

    @Test(dataProvider = "getData",description = "check When less than 2 chars in merchant country We Get Error")
    public void sku_TC08(HashMap<Object, Object> input) throws Exception {
        List<SkuOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku1").toString(),1000));
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku2").toString(),900));

        SkuOfferRequest skuOfferRequest = new SkuOfferRequest.Builder()
                .currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .merchantCountry("H")
                .items(listOfItem)
                .build();
        SkuOfferResponse skuOfferResponse= responseServiceMPGS
                .skuOfferRequest(skuOfferRequest,token(),input.get("BrandMerchantId").toString());
        Assert.assertEquals(skuOfferResponse.getStatusCode(),400);
        Assert.assertEquals(skuOfferResponse.getErrors()[0].getField(),
                "merchantCountry");
        Assert.assertEquals(skuOfferResponse.getErrors()[0].getDescription(),
                "size must be between 2 and 2");
    }

    @Test(dataProvider = "getData",description = "check When Invalid SKU We Get Error")
    public void sku_TC09(HashMap<Object, Object> input) throws Exception {
        List<SkuOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new SkuOfferRequest.Items().setItems("invalidSKU",1000));

        SkuOfferRequest skuOfferRequest = new SkuOfferRequest.Builder()
                .currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .merchantCountry(input.get("merchantCountry").toString())
                .items(listOfItem)
                .build();
        SkuOfferResponse skuOfferResponse= responseServiceMPGS
                .skuOfferRequest(skuOfferRequest,token(),input.get("BrandMerchantId").toString());
        Assert.assertEquals(skuOfferResponse.getStatusCode(),400);
        Assert.assertEquals(skuOfferResponse.getErrors()[0].getDescription(),
                "ERROR_5011::No Sku Offer found for given input.");
    }
    @Test(dataProvider = "getData",description = "check When blank SKU We Get Error")
    public void sku_TC10(HashMap<Object, Object> input) throws Exception {
        List<SkuOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new SkuOfferRequest.Items().setItems("",1000));

        SkuOfferRequest skuOfferRequest = new SkuOfferRequest.Builder()
                .currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .merchantCountry(input.get("merchantCountry").toString())
                .items(listOfItem)
                .build();
        SkuOfferResponse skuOfferResponse= responseServiceMPGS
                .skuOfferRequest(skuOfferRequest,token(),input.get("BrandMerchantId").toString());
        Assert.assertEquals(skuOfferResponse.getStatusCode(),400);
        Assert.assertTrue(skuOfferResponse.getErrors()[0].getField().contains("sku"));
        Assert.assertEquals(skuOfferResponse.getErrors()[0].getDescription(),
                "size must be between 1 and 127");
    }

    @Test(dataProvider = "getData",description = "check When unit amount is not in range We Get Error")
    public void sku_TC11(HashMap<Object, Object> input) throws Exception {
        List<SkuOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku1").toString(),99));

        SkuOfferRequest skuOfferRequest = new SkuOfferRequest.Builder()
                .currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .merchantCountry(input.get("merchantCountry").toString())
                .items(listOfItem)
                .build();
        SkuOfferResponse skuOfferResponse= responseServiceMPGS
                .skuOfferRequest(skuOfferRequest,token(),input.get("BrandMerchantId").toString());
        Assert.assertEquals(skuOfferResponse.getStatusCode(),400);
        Assert.assertEquals(skuOfferResponse.getErrors()[0].getDescription(),
                "ERROR_5011::No Sku Offer found for given input.");
    }

    @Test(dataProvider = "getData",description = "Check if merchant scheme is shown in response for a valid merchant id for which bank & merchant schemes are mapped.")
    public void skuTC_12(HashMap<Object, Object> input) throws Exception {
        List<SkuOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku1").toString(),1000));

        SkuOfferRequest skuOfferRequest = new SkuOfferRequest.Builder()
                .currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .merchantCountry(input.get("merchantCountry").toString())
                .items(listOfItem)
                .build();
        SkuOfferResponse skuOfferResponse= responseServiceMPGS
                .skuOfferRequest(skuOfferRequest,token(),input.get("MerchantIdWithBankMerchant").toString());
        Assert.assertEquals(skuOfferResponse.getStatusCode(),200);
        Assert.assertEquals(skuOfferResponse.getItems().size(),listOfItem.size());
        Assert.assertEquals(skuOfferResponse.getItems().get(0).getOffers()[0].getName(),"635319319-3");
    }

    @Test(dataProvider = "getData",description = "Check if brand scheme is shown in response for a valid merchant id for which bank, merchant & brand schemes are mapped.")
    public void skuTC_13(HashMap<Object, Object> input) throws Exception {
        List<SkuOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku3").toString(),1000));

        SkuOfferRequest skuOfferRequest = new SkuOfferRequest.Builder()
                .currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .merchantCountry(input.get("merchantCountry").toString())
                .items(listOfItem)
                .build();
        SkuOfferResponse skuOfferResponse= responseServiceMPGS
                .skuOfferRequest(skuOfferRequest,token(),input.get("AllMerchantId").toString());
        Assert.assertEquals(skuOfferResponse.getStatusCode(),200);
        Assert.assertEquals(skuOfferResponse.getItems().size(),listOfItem.size());
        Assert.assertEquals(skuOfferResponse.getItems().get(0).getOffers()[0].getName(),"635319317-3");
    }

    @Test(dataProvider = "getData",description = "Check if merchant scheme is shown in response for a merchant id for which bank, merchant & brand schemes are mapped and sku is invalid")
    public void skuTC_14(HashMap<Object, Object> input) throws Exception {
        List<SkuOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new SkuOfferRequest.Items().setItems("ash",1000));

        SkuOfferRequest skuOfferRequest = new SkuOfferRequest.Builder()
                .currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .merchantCountry(input.get("merchantCountry").toString())
                .items(listOfItem)
                .build();
        SkuOfferResponse skuOfferResponse= responseServiceMPGS
                .skuOfferRequest(skuOfferRequest,token(),input.get("AllMerchantId").toString());
        Assert.assertEquals(skuOfferResponse.getStatusCode(),200);
        Assert.assertEquals(skuOfferResponse.getItems().size(),listOfItem.size());
        Assert.assertEquals(skuOfferResponse.getItems().get(0).getOffers()[0].getName(),"635319319-3");
    }

    @Test(dataProvider = "getData",description = "Check if brand scheme is shown in response for a valid merchant id for which merchant & brand schemes are mapped")
    public void skuTC_15(HashMap<Object, Object> input) throws Exception {
        List<SkuOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new SkuOfferRequest.Items().setItems(input.get("sku4").toString(),1000));

        SkuOfferRequest skuOfferRequest = new SkuOfferRequest.Builder()
                .currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .merchantCountry(input.get("merchantCountry").toString())
                .items(listOfItem)
                .build();
        SkuOfferResponse skuOfferResponse= responseServiceMPGS
                .skuOfferRequest(skuOfferRequest,token(),input.get("MerchantIdWithBrandMerchant").toString());
        Assert.assertEquals(skuOfferResponse.getStatusCode(),200);
        Assert.assertEquals(skuOfferResponse.getItems().size(),listOfItem.size());
        Assert.assertEquals(skuOfferResponse.getItems().get(0).getOffers()[0].getName(),"635319317-3");
    }

    @DataProvider
    public Object[][] getData() throws IOException {
        OnlineApiDataPropertiesConfig dataProperties =new OnlineApiDataPropertiesConfig();
        List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                (System.getProperty("user.dir")+dataProperties.getProperty("MPGSData"));
        Object[][] obj= new Object[data.size()][1];
        for(int i=0;i<data.size();i++){
            obj[i][0]=data.get(i);
        }
        return  obj;
    }
}
