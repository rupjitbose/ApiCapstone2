package com.pinelabs.PayLater.MpgsAPITest;

import com.beust.ah.A;
import com.pinelabs.PayLater.API.Helpers.BaseUtils;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS.CartOfferRequest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS.MerchantCapabilityRequest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS.SkuOfferRequest;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoMPGS.CartOfferResponse;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoMPGS.MerchantCapabilityResponse;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceMPGS;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class CartOfferTest extends BaseUtils {
    @BeforeSuite
    public void setReportName(){
        System.setProperty("ReportName","MPGS");
    }
    private ResponseServiceMPGS responseServiceMPGS;

    @BeforeClass
    private void beforeClass() {
        responseServiceMPGS = new ResponseServiceMPGS();
    }

    @Test(dataProvider = "getData",description = "hitting cart Offer API with bank scheme")
    public void cartOfferTC_01(HashMap<Object, Object> input) throws Exception {
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("CIBMerchantId").toString());
        Assert.assertEquals(cartOfferResponse.getStatusCode(),200);
        Assert.assertEquals(cartOfferResponse.getOffers()[0].getFundingInstitution(),"MASTERCOM");
    }

    @Test(dataProvider = "getData",description = "hitting cart Offer API with merchant scheme")
    public void cartOfferTC_02(HashMap<Object, Object> input) throws Exception {
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("MIBMerchantId").toString());
        Assert.assertEquals(cartOfferResponse.getStatusCode(),200);
        Assert.assertEquals(cartOfferResponse.getOffers()[0].getFundingInstitution(),"MASTERCOM");
    }

    @Test(dataProvider = "getData",description = "hitting cart Offer API with invalid merchant id")
    public void cartOfferTC_03(HashMap<Object, Object> input) throws Exception {
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),"4365334");
        Assert.assertEquals(cartOfferResponse.getStatusCode(),400);
        Assert.assertEquals(cartOfferResponse.getErrors()[0].getDescription(),
                "ERROR_1025::Field Name merchantId has invalid value.");
    }

    @Test(dataProvider = "getData",description = "hitting cart Offer API with invalid currency code")
    public void cartOfferTC_04(HashMap<Object, Object> input) throws Exception {
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode("DJK")
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount")).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("MIBMerchantId").toString());
        Assert.assertEquals(cartOfferResponse.getStatusCode(),400);
        Assert.assertEquals(cartOfferResponse.getErrors()[0].getDescription(),
                "ERROR_4107::Merchant Currency should match with the country extracted from the mid present in request");
    }

    @Test(dataProvider = "getData",description = "hitting cart Offer API with amount which is not present in scheme")
    public void cartOfferTC_05(HashMap<Object, Object> input) throws Exception {
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount(10).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("MIBMerchantId").toString());
        Assert.assertEquals(cartOfferResponse.getStatusCode(),400);
        Assert.assertEquals(cartOfferResponse.getErrors()[0].getDescription(),
                "ERROR_2156::No schemes present for the value in total amount field");
    }

    @Test(dataProvider = "getData",description = "hitting cart Offer API with payment amount is zero")
    public void cartOfferTC_06(HashMap<Object, Object> input) throws Exception {
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount(0).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("MIBMerchantId").toString());
        Assert.assertEquals(cartOfferResponse.getStatusCode(),400);
        Assert.assertEquals(cartOfferResponse.getErrors()[0].getDescription(),
                "ERROR_1082::Amount should be greater than 0");
    }

    @Test(dataProvider = "getData",description = "hitting cart Offer API with brand scheme")
    public void cartOfferTC_07(HashMap<Object, Object> input) throws Exception {
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount"),(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        Assert.assertEquals(cartOfferResponse.getStatusCode(),200);
        Assert.assertNotNull(cartOfferResponse.getOffers()[0].getCartOfferId());
        Assert.assertEquals(cartOfferResponse.getOffers()[2].getFundingInstitution(),"MASTERCOM");
    }

    @Test(dataProvider = "getData",description = "hitting cart Offer API with brand scheme with invalid merchant id")
    public void cartOfferTC_08(HashMap<Object, Object> input) throws Exception {
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount"),(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),"8798789");
        Assert.assertEquals(cartOfferResponse.getStatusCode(),400);
        Assert.assertEquals(cartOfferResponse.getErrors()[0].getDescription()
                ,"ERROR_1025::Field Name merchantId has invalid value.");
    }

    @Test(dataProvider = "getData",description = "hitting cart Offer API with brand scheme with invalid currency code")
    public void cartOfferTC_09(HashMap<Object, Object> input) throws Exception {
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),(Integer) input.get("unitAmount"),(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode("HJK")
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        Assert.assertEquals(cartOfferResponse.getStatusCode(),400);
        Assert.assertEquals(cartOfferResponse.getErrors()[0].getDescription()
                ,"ERROR_4107::Merchant Currency should match with the country extracted from the mid present in request");
    }

    @Test(dataProvider = "getData",description = "hitting cart Offer API with brand scheme with amount which is not in range with scheme")
    public void cartOfferTC_10(HashMap<Object, Object> input) throws Exception {
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),99,(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount(99)
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        Assert.assertEquals(cartOfferResponse.getStatusCode(),400);
        Assert.assertEquals(cartOfferResponse.getErrors()[0].getDescription()
                ,"ERROR_2156::No schemes present for the value in total amount field");
    }

    @Test(dataProvider = "getData",description = "hitting cart Offer API with brand scheme with invalid sku")
    public void cartOfferTC_11(HashMap<Object, Object> input) throws Exception {
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems("ash_56",(Integer) input.get("unitAmount"),(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        Assert.assertEquals(cartOfferResponse.getStatusCode(),400);
        Assert.assertEquals(cartOfferResponse.getErrors()[0].getDescription()
                ,"ERROR_2156::No schemes present for the value in total amount field");
    }

    @Test(dataProvider = "getData",description = "hitting cart Offer API with brand scheme with unit amount which is not in product amount range")
    public void cartOfferTC_12(HashMap<Object, Object> input) throws Exception {
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),6000,(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount(6000)
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        Assert.assertEquals(cartOfferResponse.getStatusCode(),400);
        Assert.assertEquals(cartOfferResponse.getErrors()[0].getDescription()
                ,"ERROR_4097::Offer not found for product");
    }

    @Test(dataProvider = "getData",description = "hitting cart Offer API with brand scheme with different unit and payment amount")
    public void cartOfferTC_13(HashMap<Object, Object> input) throws Exception {
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),6000,(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount(600)
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        Assert.assertEquals(cartOfferResponse.getStatusCode(),400);
        Assert.assertEquals(cartOfferResponse.getErrors()[0].getDescription()
                ,"ERROR_4112::Actual Total Amount not matching with Expected Total Amount.");
    }

    @Test(dataProvider = "getData",description = "hitting cart Offer API with brand scheme with different unit and payment amount, change in quantity")
    public void cartOfferTC_14(HashMap<Object, Object> input) throws Exception {
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems(input.get("sku").toString(),600,2));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount(600)
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        Assert.assertEquals(cartOfferResponse.getStatusCode(),400);
        Assert.assertEquals(cartOfferResponse.getErrors()[0].getDescription()
                ,"ERROR_4112::Actual Total Amount not matching with Expected Total Amount.");
    }

    @Test(dataProvider = "getData",description = "hitting cart Offer API with brand scheme with blank sku")
    public void cartOfferTC_15(HashMap<Object, Object> input) throws Exception {
        List<CartOfferRequest.Items> listOfItem=new ArrayList<>();
        listOfItem.add(new CartOfferRequest.Items().setItems("",(Integer) input.get("unitAmount"),(Integer) input.get("quantity")));
        CartOfferRequest cartOfferRequest = new CartOfferRequest.Builder().currencyCode(input.get("merchantCurrencyCodeNum").toString())
                .deliveryCountry(input.get("deliveryCountry").toString()).paymentAmount((Integer) input.get("paymentAmount"))
                .items(listOfItem).build();
        CartOfferResponse cartOfferResponse  = responseServiceMPGS
                .cartOfferRequest(cartOfferRequest,token(),input.get("BrandMerchantId").toString());
        Assert.assertEquals(cartOfferResponse.getStatusCode(),400);
        Assert.assertEquals(cartOfferResponse.getErrors()[0].getField(),"items[0].sku");
        Assert.assertEquals(cartOfferResponse.getErrors()[0].getDescription()
                ,"size must be between 1 and 127");
    }

    @DataProvider
    public Object[][] getData() throws IOException {
        OnlineApiDataPropertiesConfig dataProperties =new OnlineApiDataPropertiesConfig();
        List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                (System.getProperty("user.dir")+ dataProperties.getProperty("MPGSData"));
        Object[][] obj= new Object[data.size()][1];
        for(int i=0;i<data.size();i++){
            obj[i][0]=data.get(i);
        }
        return obj;
    }
}
