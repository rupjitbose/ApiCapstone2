package com.pinelabs.PayLater.OnlineAPITest;

import com.pinelabs.PayLater.API.Helpers.BaseUtils;
import com.pinelabs.PayLater.API.Helpers.RetryTest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.IppOfferRequest;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.IppOfferResponse;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceOnlineAPI;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;

import org.testng.Assert;
import org.testng.annotations.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

public class IppOfferTest extends BaseUtils {
    @BeforeSuite
    public void setReportName(){
        System.setProperty("ReportName","OnlineAPI");
    }
    private ResponseServiceOnlineAPI responseServiceOnlineAPI;

    @BeforeClass()
    private void beforeClass() {
        responseServiceOnlineAPI = new ResponseServiceOnlineAPI();}

    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void triggerIppOfferApiWithCorrectDataSet(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        //act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest,token());
        //assert
        Assert.assertEquals(ippOfferResponse.getMerchantId(), input.get("merchantId").toString());
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void triggerIppOfferApiWhenBothBankAndMerchantSchemeConfiguredOnlyMerchantShouldShow(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(1000.00)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        //act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest,token());
        //assert
        Assert.assertEquals(ippOfferResponse.getMerchantId(), input.get("merchantId"));

        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));

        Assert.assertEquals(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                tenureIndex).getProgramType(),"MERCHANT");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void triggerIppOfferApiWhenBothBankAndMerchantSchemeWithAmountNotInMerchantRangeBankDataShouldShow(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(100.00)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        //act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //assert
        Assert.assertEquals(ippOfferResponse.getMerchantId(), input.get("merchantId"));

        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));

        Assert.assertEquals(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                tenureIndex).getProgramType(),"BANK");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void triggerIppOfferApiWithInvalidMerchantIDShouldThrowError(HashMap<Object,Object> input) throws Exception  {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId("xyztestdata").build();
        //Act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest,token());
        //assert
        Assert.assertEquals(ippOfferResponse.getErrors()[0].getMessage(), "Field Name merchantId has invalid value.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void triggerIppOfferApiWithInvalidCountryCodeShouldThrowError(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(500.00)
                .issuerCountryCode(999)
                .merchantId(input.get("merchantId").toString()).build();
        //Act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest,token());
        //assert
        Assert.assertEquals(ippOfferResponse.getErrors()[0].getMessage(),
                "Currency not found for given issuer country.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void triggerIppOfferApiWithAmountLessThanRangeValueShouldThrowError(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("lessTotalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        //Act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest,token());
        //assert
        Assert.assertEquals(ippOfferResponse.getErrors()[0].getMessage(), "No schemes present for the value in total amount field");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void triggerIppOfferApiWithAmountMoreThanRangeValueShouldThrowError(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("moreTotalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        //Act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest,token());
        //assert
        Assert.assertEquals(ippOfferResponse.getErrors()[0].getMessage(), "No schemes present for the value in total amount field");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void triggerIppOfferApiWithOfflineSchemeMappedToMerchantShouldThrowError(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("offlineTotalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("offlineIssuerCountryCode").toString()))
                .merchantId(input.get("offlineMerchantId").toString()).build();
        //Act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest,token());
        //assert
        Assert.assertEquals(ippOfferResponse.getErrors()[0].getMessage(), "No schemes present for the value in total amount field");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void triggerIppOfferApiWithMerchantWithOutSchemeShouldThrowError(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantIdWithOutScheme").toString()).build();
        //Act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest,token());
        //assert
        Assert.assertEquals(ippOfferResponse.getErrors()[0].getMessage(), "No schemes present for the value in total amount field");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void triggerIppOfferApiWithInvalidAmountNullShouldThrowError(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(null)
                .issuerCountryCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        //Act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest,token());
        //assert
        Assert.assertEquals(ippOfferResponse.getStatusCode(), 400);
        Assert.assertEquals(ippOfferResponse.getErrors()[0].getMessage(),
                "Invalid Request.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void triggerIppOfferApiWithInvalidAmountZeroShouldThrowError(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(0.0)
                .issuerCountryCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        //Act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest,token());
        //assert
        Assert.assertEquals(ippOfferResponse.getErrors()[0].getMessage(),
                "invalid Amount");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void triggerIppOfferApiWithInvalidAmountNegativeValueShouldThrowError(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(-500.00)
                .issuerCountryCode(852)
                .merchantId(input.get("merchantId").toString()).build();
        //Act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest,token());
        //assert
        Assert.assertEquals(ippOfferResponse.getErrors()[0].getMessage(),
                "invalid Amount");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void triggerIppOfferApiWithInvalidAccessTokenShouldThrowError(HashMap<Object,Object> input) throws Exception {
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        //Act
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest,"xyz");
        //assert
        Assert.assertEquals(ippOfferResponse.getMsg(),
                "Unauthorized Request");
    }

    @DataProvider
    public Object[][] getData() throws IOException {
            OnlineApiDataPropertiesConfig dataProperties =new OnlineApiDataPropertiesConfig();
            List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                    (System.getProperty("user.dir")+ dataProperties.getProperty("Data"));
            Object[][] obj= new Object[data.size()][1];
            for(int i=0;i<data.size();i++){
                obj[i][0]=data.get(i);}
            return  obj;
    }

}