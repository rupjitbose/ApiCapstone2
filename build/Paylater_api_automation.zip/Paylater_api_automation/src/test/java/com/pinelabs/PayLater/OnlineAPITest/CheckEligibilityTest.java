package com.pinelabs.PayLater.OnlineAPITest;


import com.pinelabs.PayLater.API.Helpers.BaseUtils;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.API.Helpers.RetryTest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.CheckEligibilityRequest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.IppOfferRequest;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.CheckEligibilityResponse;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.IppOfferResponse;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceOnlineAPI;
import org.jetbrains.annotations.NotNull;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

public class CheckEligibilityTest extends BaseUtils {

    @BeforeSuite
    public void setReportName(){
        System.setProperty("ReportName","OnlineAPI");
    }
    private ResponseServiceOnlineAPI responseServiceOnlineAPI;

    @BeforeClass()
    private void beforeClass() {
        responseServiceOnlineAPI = new ResponseServiceOnlineAPI();}
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void brandCheckEligibilityPositiveCase(HashMap<Object,Object> input) throws Exception {

        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();

        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .productCode(input.get("productCode").toString())
                .brandId(input.get("brandId").toString())
                .productAmount(Double.parseDouble(input.get("productAmount").toString()))
                .quantity(Integer.parseInt(input.get("quantity").toString())).build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),200);
        Assert.assertEquals(checkEligibilityResponse.getIsEligible(),"true");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void bankCheckEligibilityPositiveCase(HashMap<Object,Object> input) throws Exception {
        //pre req
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();

        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),200);
        Assert.assertEquals(checkEligibilityResponse.getIsEligible(),"true");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void CheckEligibilityShouldFailWhenMerchantIdInvalid(HashMap<Object,Object> input) throws Exception {

        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();

        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .merchantId("xyz")
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),400);
        Assert.assertEquals(checkEligibilityResponse.getErrors()[0].getMessage(),"Field Name merchantId has invalid value.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void CheckEligibilityShouldShowEligibilityFailureReasonWhenCardNumberInvalid(HashMap<Object,Object> input) throws Exception {

        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();

        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(12345678)
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),200);
        Assert.assertEquals(checkEligibilityResponse.getEligibilityFailureReason(),"Invalid Card Number,");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void CheckEligibilityShouldFailWhenCardNumberNull(HashMap<Object,Object> input) throws Exception {

        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();

        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(null)
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),400);
        Assert.assertEquals(checkEligibilityResponse.getErrors()[0].getMessage(),
                "Invalid Bin Range. Please enter a valid first 8 digits of PAN (card number).");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void CheckEligibilityShouldFailWhenCardNumberLessThan8Digits(HashMap<Object,Object> input) throws Exception {

        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();

        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,7)))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),400);
        Assert.assertEquals(checkEligibilityResponse.getErrors()[0].getMessage(),
                "Invalid Bin Range. Please enter a valid first 8 digits of PAN (card number).");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void CheckEligibilityShouldFailWhenCardNumberMoreThan8Digits(HashMap<Object,Object> input) throws Exception {

        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();

        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,9)))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),400);
        Assert.assertEquals(checkEligibilityResponse.getErrors()[0].getMessage(),
                "Invalid Bin Range. Please enter a valid first 8 digits of PAN (card number).");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void CheckEligibilityShouldFailWhenIssuerIdInvalid(HashMap<Object,Object> input) throws Exception {

        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();

        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .merchantId(input.get("merchantId").toString())
                .issuerId("123456")
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),400);
        Assert.assertEquals(checkEligibilityResponse.getErrors()[0].getMessage(),"Field Name issuerId is either null or has invalid value.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void CheckEligibilityShouldShowEligibilityFailureReasonWhenTenureInvalid(HashMap<Object,Object> input) throws Exception {

        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();

        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("issuerId").toString())
                .tenure(1)
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),200);
        Assert.assertEquals(checkEligibilityResponse.getIsEligible(),"false");
        Assert.assertEquals(checkEligibilityResponse.getEligibilityFailureReason(),"Invalid Tenure,");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void CheckEligibilityShouldShowEligibilityFailureReasonWhenTotalAmountLessThanSchemeRange(HashMap<Object,Object> input) throws Exception {

        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();

        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(Double.parseDouble(input.get("lessTotalAmount").toString()))
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),200);
        Assert.assertEquals(checkEligibilityResponse.getIsEligible(),"false");
        Assert.assertEquals(checkEligibilityResponse.getEligibilityFailureReason(),
                "Amount Not In Range,");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void CheckEligibilityShouldShowEligibilityFailureReasonWhenTotalAmountMoreThanSchemeRange(HashMap<Object,Object> input) throws Exception {

        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();

        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(Double.parseDouble(input.get("moreTotalAmount").toString()))
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),200);
        Assert.assertEquals(checkEligibilityResponse.getIsEligible(),"false");
        Assert.assertEquals(checkEligibilityResponse.getEligibilityFailureReason(),
                "Amount Not In Range,");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void CheckEligibilityShouldFailWhenSchemeIdInvalid(HashMap<Object,Object> input) throws Exception {

        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();

        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId("12345")
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),400);
        Assert.assertEquals(checkEligibilityResponse.getErrors()[0].getMessage(),
                "Field Name schemeId is either null or has invalid value.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void CheckEligibilityShouldFailProgramTypeInvalid(HashMap<Object,Object> input) throws Exception {

        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();

        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType("xyz")
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),400);
        Assert.assertEquals(checkEligibilityResponse.getErrors()[0].getMessage(),
                "Field Name programType is either null or has invalid value.");
    }

    @Test(dataProvider="getErrorData")
    public void CheckEligibilityShouldFailWhenBankSchemeAndProgramTypeMerchant(HashMap<Object,Object> input) throws Exception {
       //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("validCardNo").toString()))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("vaildIssuerId").toString())
                .tenure(3)
                .schemeId(input.get("bankScheme").toString())
                .programType("MERCHANT")
                .totalAmount(1000)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),400);
        Assert.assertEquals(checkEligibilityResponse.getErrors()[0].getMessage(),
                "Field Name programType is either null or has invalid value.");
    }
    @Test(dataProvider="getErrorData")
    public void CheckEligibilityShouldFailWhenBankSchemeAndProgramTypeBrand(HashMap<Object,Object> input) throws Exception {
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("validCardNo").toString()))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("vaildIssuerId").toString())
                .tenure(3)
                .schemeId(input.get("bankScheme").toString())
                .programType("BRAND")
                .totalAmount(1000)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),400);
        Assert.assertEquals(checkEligibilityResponse.getErrors()[0].getMessage(),
                "Field Name programType is either null or has invalid value.");
    }
    @Test(dataProvider="getErrorData")
    public void CheckEligibilityShouldRunWhenBankSchemeAndProgramTypeBank(HashMap<Object,Object> input) throws Exception {
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("validCardNo").toString()))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("vaildIssuerId").toString())
                .tenure(3)
                .schemeId(input.get("bankScheme").toString())
                .programType("BANK")
                .totalAmount(1000)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),200);
    }
    @Test(dataProvider="getErrorData")
    public void CheckEligibilityShouldFailWhenMerchantSchemeAndProgramTypeBank(HashMap<Object,Object> input) throws Exception {
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("validCardNo").toString()))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("vaildIssuerId").toString())
                .tenure(3)
                .schemeId(input.get("merchatscheme").toString())
                .programType("BANK")
                .totalAmount(1000)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),400);
        Assert.assertEquals(checkEligibilityResponse.getErrors()[0].getMessage(),
                "Field Name programType is either null or has invalid value.");
    }
    @Test(dataProvider="getErrorData")
    public void CheckEligibilityShouldFailWhenMerchantSchemeAndProgramTypeBrand(HashMap<Object,Object> input) throws Exception {
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("validCardNo").toString()))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("vaildIssuerId").toString())
                .tenure(3)
                .schemeId(input.get("merchatscheme").toString())
                .programType("BRAND")
                .totalAmount(1000)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),400);
        Assert.assertEquals(checkEligibilityResponse.getErrors()[0].getMessage(),
                "Field Name programType is either null or has invalid value.");
    }
    @Test(dataProvider="getErrorData")
    public void CheckEligibilityShouldRunWhenMerchantSchemeAndProgramTypeMerchant(HashMap<Object,Object> input) throws Exception {
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("validCardNo").toString()))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("vaildIssuerId").toString())
                .tenure(3)
                .schemeId(input.get("merchatscheme").toString())
                .programType("MERCHANT")
                .totalAmount(1000)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),200);
    }
    @Test(dataProvider="getErrorData")
    public void CheckEligibilityShouldFailWhenBrandSchemeAndProgramTypeBank(HashMap<Object,Object> input) throws Exception {
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("validCardNo").toString()))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("vaildIssuerId").toString())
                .tenure(3)
                .schemeId(input.get("brandscheme").toString())
                .programType("BANK")
                .totalAmount(1000)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),400);
        Assert.assertEquals(checkEligibilityResponse.getErrors()[0].getMessage(),
                "Field Name programType is either null or has invalid value.");
    }
    @Test(dataProvider="getErrorData")
    public void CheckEligibilityShouldFailWhenBrandSchemeAndProgramTypeMerchant(HashMap<Object,Object> input) throws Exception {
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("validCardNo").toString()))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("vaildIssuerId").toString())
                .tenure(3)
                .schemeId(input.get("brandscheme").toString())
                .programType("MERCHANT")
                .totalAmount(1000)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),400);
        Assert.assertEquals(checkEligibilityResponse.getErrors()[0].getMessage(),
                "Field Name programType is either null or has invalid value.");
    }
    @Test(dataProvider="getErrorData")
    public void CheckEligibilityShouldShowEligibilityFailureReasonWhenSchemeIdNotMappedWithMerchantAndAmountNotInScheme(HashMap<Object,Object> input) throws Exception {
       //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("invalidSchemeIdsCardNo").toString()))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("vaildIssuerId").toString())
                .tenure(3)
                .schemeId(input.get("invalidSchemeId").toString())
                .programType("MERCHANT")
                .totalAmount(1)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),200);
        Assert.assertEquals(checkEligibilityResponse.getEligibilityFailureReason(),
                "Scheme and Merchant are not related,Amount Not In Range,");
    }
    @Test(dataProvider="getErrorData")
    public void CheckEligibilityShouldShowEligibilityFailureReasonWhenSchemeIdNotMappedWithMerchantAndCardNumberInvalid(HashMap<Object,Object> input) throws Exception {
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("invalidCardNo").toString()))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("vaildIssuerId").toString())
                .tenure(3)
                .schemeId(input.get("invalidSchemeId").toString())
                .programType("MERCHANT")
                .totalAmount(1000)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),200);
        Assert.assertEquals(checkEligibilityResponse.getEligibilityFailureReason(),
                "Scheme and Merchant are not related,Invalid Card Number,");
    }
    @Test(dataProvider="getErrorData")
    public void CheckEligibilityShouldShowEligibilityFailureReasonWhenSchemeIdNotMappedWithMerchantAndTenureInvalid(HashMap<Object,Object> input) throws Exception {
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("invalidSchemeIdsCardNo").toString()))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("vaildIssuerId").toString())
                .tenure(200)
                .schemeId(input.get("invalidSchemeId").toString())
                .programType("MERCHANT")
                .totalAmount(1000)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),200);
        Assert.assertEquals(checkEligibilityResponse.getEligibilityFailureReason(),
                "Scheme and Merchant are not related,Invalid Tenure,");
    }
    @Test(dataProvider="getErrorData")
    public void CheckEligibilityShouldShowEligibilityFailureReasonWhenSchemeIdNotMappedWithMerchantAndTenureAndCardNumberInvalid(HashMap<Object,Object> input) throws Exception {
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("invalidCardNo").toString()))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("vaildIssuerId").toString())
                .tenure(30)
                .schemeId(input.get("invalidSchemeId").toString())
                .programType("MERCHANT")
                .totalAmount(1000)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),200);
        Assert.assertEquals(checkEligibilityResponse.getEligibilityFailureReason(),
                "Scheme and Merchant are not related,Invalid Card Number,Invalid Tenure,");
    }
    @Test(dataProvider="getErrorData")
    public void CheckEligibilityShouldShowEligibilityFailureReasonWhenSchemeIdAndIssuerIdNotMappedWithMerchantAndTenureAndCardNumberInvalid(@NotNull HashMap<Object,Object> input) throws Exception {
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("invalidCardNo").toString()))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("invaildIssuerId").toString())
                .tenure(200)
                .schemeId(input.get("invalidSchemeId").toString())
                .programType("MERCHANT")
                .totalAmount(1000)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),200);
        Assert.assertEquals(checkEligibilityResponse.getEligibilityFailureReason(),
                "Scheme and Merchant are not related,Issuer and Merchant are not related,Invalid Card Number,Invalid Tenure,");
    }
    @Test(dataProvider="getErrorData")
    public void CheckEligibilityShouldShowEligibilityFailureReasonWhenIssuerIdNotMappedWithMerchant(HashMap<Object,Object> input) throws Exception {
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("validCardNo").toString()))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("invaildIssuerId").toString())
                .tenure(3)
                .schemeId(input.get("validSchemeId").toString())
                .programType("MERCHANT")
                .totalAmount(1000)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),200);
        Assert.assertTrue(checkEligibilityResponse.getEligibilityFailureReason().contains(
                "Issuer and Merchant are not related,"));
    }

    @DataProvider
    public Object[][] getErrorData() throws IOException {
        OnlineApiDataPropertiesConfig dataProperties =new OnlineApiDataPropertiesConfig();
        List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                (System.getProperty("user.dir")+ dataProperties.getProperty("CheckEligibilityData"));
        Object[][] obj= new Object[data.size()][1];
        for(int i=0;i<data.size();i++){
            obj[i][0]=data.get(i);}
        return obj;
    }
    @DataProvider
    public Object[][] getData() throws IOException {
        OnlineApiDataPropertiesConfig dataProperties =new OnlineApiDataPropertiesConfig();
        List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                (System.getProperty("user.dir")+ dataProperties.getProperty("Data"));
        Object[][] obj= new Object[data.size()][1];
        for(int i=0;i<data.size();i++){
            obj[i][0]=data.get(i);}
        return obj;
    }

}
