package com.pinelabs.PayLater.CrossBorderTest;

import com.pinelabs.PayLater.API.Helpers.BaseUtils;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.API.Helpers.PLEncrypt.PLEncrypt;
import com.pinelabs.PayLater.API.Helpers.RetryTest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.*;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.IppOfferResponse;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.RefundApiResponse;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.TransactionStatusResponse;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceOnlineAPI;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

public class RefundCrossBorderTest extends BaseUtils {
    @BeforeSuite
    public void setReportName() {System.setProperty("ReportName", "CrossBorderOnlineAPI");}
    private ResponseServiceOnlineAPI responseServiceOnlineAPI;
    @BeforeClass()
    private void beforeClass() {responseServiceOnlineAPI = new ResponseServiceOnlineAPI();}

    @Test(dataProvider = "getData",retryAnalyzer= RetryTest.class,description ="Refund Successful After Transaction Sale For CrossBorder")
    public void refundCrossBorder_TC01(HashMap<Object, Object> input) throws Exception {
        double convertedAmount = currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //Indexing
        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        long transactionId = transactionStatusResponse.getTransactionId();
        //arrange
        RefundApiRequest refundApiRequest=new RefundApiRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                //.refundDateTime(input.get("refundDateTime").toString())
                .transactionId(transactionId)
                .transactionAmount(convertedAmount)
                .build();
        //Act
        RefundApiResponse refundApiResponse= responseServiceOnlineAPI
                .refundRequest(refundApiRequest,token());
        //assert
        Assert.assertEquals(refundApiResponse.getMerchantId(),input.get("merchantId").toString());
        Assert.assertEquals(refundApiResponse.getStatusCode(),200);
        Assert.assertEquals(refundApiResponse.getTransactionId(),transactionId);
    }
    @Test(dataProvider = "getData",retryAnalyzer= RetryTest.class,description ="Refund Successful After Auth Capture For CrossBorder")
    public void refundCrossBorder_TC02(HashMap<Object, Object> input) throws Exception {
        double convertedAmount = currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //Arrange
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        //Indexing
        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);
        IppOfferResponse.EmiSchemeDetails emiSchemeDetails = IppOfferResponse
                .getEmiSchemeDetails(ippOfferResponse, issuerIndex, tenureIndex);
        //Start of Transaction Status API
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(convertedAmount)
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(7)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(emiSchemeDetails.getSchemeId())
                .paymentType(emiSchemeDetails.getProductType())
                .schemeDescription(emiSchemeDetails.getSchemeDescription())
                .installmentConfigID(emiSchemeDetails.getInstallmentConfigID())
                .productType(emiSchemeDetails.getProductType())
                .programType(emiSchemeDetails.getProgramType())
                .geoScope(emiSchemeDetails.getGeoScope())
                .isSchemeValid(emiSchemeDetails.getIsSchemeValid())
                .bankInterestRate(emiSchemeDetails.getBankInterestRate())
                .processingFeeValue(emiSchemeDetails.getProcessingFeeValue())
                .subventionType(emiSchemeDetails.getSubventionType())
                .interestAmountCharged(emiSchemeDetails.getInterestAmountCharged())
                .loanAmount(emiSchemeDetails.getLoanAmount())
                .authAmount(emiSchemeDetails.getAuthAmount())
                .monthlyInstallment(emiSchemeDetails.getMonthlyInstallment())
                .build();
        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        long transactionId = transactionStatusResponse.getTransactionId();
        //perform auth capture
        AuthCaptureRequest authCaptureRequest=new AuthCaptureRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .transactionId(transactionId)
                .build();
        responseServiceOnlineAPI.authCaptureRequest(authCaptureRequest,token());
        //arrange
        RefundApiRequest refundApiRequest=new RefundApiRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                //.refundDateTime(input.get("refundDateTime").toString())
                .transactionId(transactionId)
                .transactionAmount(convertedAmount)
                .build();
        //Act
        RefundApiResponse refundApiResponse= responseServiceOnlineAPI
                .refundRequest(refundApiRequest,token());
        //assert
        Assert.assertEquals(refundApiResponse.getMerchantId(),input.get("merchantId").toString());
        Assert.assertEquals(refundApiResponse.getStatusCode(),200);
        Assert.assertEquals(refundApiResponse.getTransactionId(),transactionId);
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description = "RefundS Fail After Transaction Auth Cancelled For Cross Border")
    public void refundCrossBorder_TC03(HashMap<Object,Object> input) throws Exception {
        double convertedAmount = currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);

        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .cardApprovalCode(input.get("cardApprovalCode").toString())
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(convertedAmount)
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(7)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        long transactionId = transactionStatusResponse.getTransactionId();
        //Auth cancel
        AuthCancelRequest authCancelRequest = new AuthCancelRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .transactionAmount(convertedAmount)
                .transactionId(transactionId).build();
        responseServiceOnlineAPI.authCancelRequest(authCancelRequest, token());
        //arrange
        RefundApiRequest refundApiRequest=new RefundApiRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .refundDateTime(input.get("refundDateTime").toString())
                .transactionId(transactionId)
                .transactionAmount(convertedAmount)
                .build();
        //Act
        RefundApiResponse refundApiResponse= responseServiceOnlineAPI
                .refundRequest(refundApiRequest,token());
        //assert
        Assert.assertEquals(refundApiResponse.getStatusCode(),400);
        Assert.assertEquals(refundApiResponse.getErrors()[0].getMessage(),
                "Transaction Status is Auth Cancel, refund is not allowed.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="Refund should Fail For Already Refunded Transaction For Cross Border" )
    public void refundCrossBorder_TC04(HashMap<Object,Object> input) throws Exception {
        double convertedAmount = currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);

        //Placing sale transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .cardApprovalCode(input.get("cardApprovalCode").toString())
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(convertedAmount)
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        long transactionId = transactionStatusResponse.getTransactionId();

        //arrange
        RefundApiRequest refundApiRequest=new RefundApiRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .refundDateTime(input.get("refundDateTime").toString())
                .transactionId(transactionId)
                .transactionAmount(convertedAmount)
                .build();
        //actual refund
        responseServiceOnlineAPI
                .refundRequest(refundApiRequest,token());
        //re-refund
        RefundApiResponse refundApiResponse= responseServiceOnlineAPI
                .refundRequest(refundApiRequest,token());
        //assertAssert.assertEquals(refundApiResponse.getMerchantId(),input.get("merchantId").toString());
        Assert.assertEquals(refundApiResponse.getStatusCode(),400);
        Assert.assertEquals(refundApiResponse.getErrors()[0].getMessage(),
                "Transaction refund already processed with TransactionId");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="Refund should Fail When MerchantId is Invalid For Cross Border")
    public void refundCrossBorder_TC05(HashMap<Object,Object> input) throws Exception {
        double convertedAmount = currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);

        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .cardApprovalCode(input.get("cardApprovalCode").toString())
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(convertedAmount)
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        long transactionId = transactionStatusResponse.getTransactionId();
        //arrange
        RefundApiRequest refundApiRequest=new RefundApiRequest.Builder()
                .merchantId("01010101010110")
                .pspId(input.get("pspId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .refundDateTime(input.get("refundDateTime").toString())
                .transactionId(transactionId)
                .transactionAmount(convertedAmount)
                .build();
        //Act
        RefundApiResponse refundApiResponse= responseServiceOnlineAPI
                .refundRequest(refundApiRequest,token());
        //assert
        Assert.assertEquals(refundApiResponse.getStatusCode(),400);
        Assert.assertEquals(refundApiResponse.getErrors()[0].getMessage(),
                "Field Name merchantId has invalid value.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="Refund should Fail When PspId Invalid for Cross Border")
    public void refundCrossBorder_TC06(HashMap<Object,Object> input) throws Exception {
        double convertedAmount = currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);

        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .cardApprovalCode(input.get("cardApprovalCode").toString())
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(convertedAmount)
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        Long transactionId = transactionStatusResponse.getTransactionId();
        //arrange
        RefundApiRequest refundApiRequest=new RefundApiRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId("1000000")
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .refundDateTime(input.get("refundDateTime").toString())
                .transactionId(transactionId)
                .transactionAmount(convertedAmount)
                .build();
        //Act
        RefundApiResponse refundApiResponse= responseServiceOnlineAPI
                .refundRequest(refundApiRequest,token());
        //assert
        Assert.assertEquals(refundApiResponse.getStatusCode(),400);
        Assert.assertEquals(refundApiResponse.getErrors()[0].getMessage(),
                "Invalid PSP ID");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="Refund should Fail When Transaction Id Invalid for Cross Border")
    public void refundCrossBorder_TC07(HashMap<Object,Object> input) throws Exception {
        double convertedAmount = currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);

        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .cardApprovalCode(input.get("cardApprovalCode").toString())
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(convertedAmount)
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        long transactionId = transactionStatusResponse.getTransactionId();
        //arrange
        RefundApiRequest refundApiRequest=new RefundApiRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .refundDateTime(input.get("refundDateTime").toString())
                .transactionId(10000000L)
                .transactionAmount(convertedAmount)
                .build();
        //Act
        RefundApiResponse refundApiResponse= responseServiceOnlineAPI
                .refundRequest(refundApiRequest,token());
        //assert
        Assert.assertEquals(refundApiResponse.getStatusCode(),400);
        Assert.assertEquals(refundApiResponse.getErrors()[0].getMessage(),
                "Invalid TransactionId ");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="Refund should Fail When Transaction Id Null for Cross Border")
    public void refundCrossBorder_TC08(HashMap<Object,Object> input) throws Exception {
        double convertedAmount = currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);

        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .cardApprovalCode(input.get("cardApprovalCode").toString())
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(convertedAmount)
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        long transactionId = transactionStatusResponse.getTransactionId();
        //arrange
        RefundApiRequest refundApiRequest=new RefundApiRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .refundDateTime(input.get("refundDateTime").toString())
                .transactionId(null)
                .transactionAmount(convertedAmount)
                .build();
        //Act
        RefundApiResponse refundApiResponse= responseServiceOnlineAPI
                .refundRequest(refundApiRequest,token());
        //assert
        Assert.assertEquals(refundApiResponse.getStatusCode(),400);
        Assert.assertEquals(refundApiResponse.getErrors()[0].getMessage(),
                "Invalid TransactionId ");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="Refund should Fail When Transaction Amount Invalid for Cross Border")
    public void refundCrossBorder_TC09(HashMap<Object,Object> input) throws Exception {
        double convertedAmount = currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);

        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .cardApprovalCode(input.get("cardApprovalCode").toString())
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(convertedAmount)
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        long transactionId = transactionStatusResponse.getTransactionId();
        //arrange
        RefundApiRequest refundApiRequest=new RefundApiRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .refundDateTime(input.get("refundDateTime").toString())
                .transactionId(transactionId)
                .transactionAmount(100000000.00)
                .build();
        //Act
        RefundApiResponse refundApiResponse= responseServiceOnlineAPI
                .refundRequest(refundApiRequest,token());
        //assert
        Assert.assertEquals(refundApiResponse.getStatusCode(),400);
        Assert.assertEquals(refundApiResponse.getErrors()[0].getMessage(),
                "invalid Amount");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="Refund should Fail When Transaction Amount Null for Cross Border")
    public void refundCrossBorder_TC10(HashMap<Object,Object> input) throws Exception {
        double convertedAmount = currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);

        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .cardApprovalCode(input.get("cardApprovalCode").toString())
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(convertedAmount)
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        long transactionId = transactionStatusResponse.getTransactionId();
        //arrange
        RefundApiRequest refundApiRequest=new RefundApiRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .refundDateTime(input.get("refundDateTime").toString())
                .transactionId(transactionId)
                .transactionAmount(null)
                .build();
        //Act
        RefundApiResponse refundApiResponse= responseServiceOnlineAPI
                .refundRequest(refundApiRequest,token());
        //assert
        Assert.assertEquals(refundApiResponse.getStatusCode(),400);
        Assert.assertEquals(refundApiResponse.getErrors()[0].getMessage(),
                "invalid Amount");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="Refund should Fail When Transaction Amount Partial Of Actual Amount for Cross Border")
    public void refundCrossBorder_TC11(HashMap<Object,Object> input) throws Exception {
        double convertedAmount = currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);

        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .cardApprovalCode(input.get("cardApprovalCode").toString())
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(convertedAmount)
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        long transactionId = transactionStatusResponse.getTransactionId();
        //arrange
        RefundApiRequest refundApiRequest=new RefundApiRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .refundDateTime(input.get("refundDateTime").toString())
                .transactionId(transactionId)
                .transactionAmount(convertedAmount/2)
                .build();
        //Act
        RefundApiResponse refundApiResponse= responseServiceOnlineAPI
                .refundRequest(refundApiRequest,token());
        //assert
        Assert.assertEquals(refundApiResponse.getStatusCode(),400);
        Assert.assertEquals(refundApiResponse.getErrors()[0].getMessage(),
                "invalid Amount");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description ="Refund shoild Fail When ReuqestId is Blank")
    public void refundCrossBorder_TC12(HashMap<Object,Object> input) throws Exception {
        double convertedAmount = currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);

        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(convertedAmount)
                .pspId(input.get("pspId").toString())
                .amount(convertedAmount)
                .cardApprovalCode(input.get("cardApprovalCode").toString())
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(convertedAmount)
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(1)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        long transactionId = transactionStatusResponse.getTransactionId();
        //arrange
        RefundApiRequest refundApiRequest=new RefundApiRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .refundDateTime(input.get("refundDateTime").toString())
                .transactionId(transactionId)
                .requestId("")
                .transactionAmount(convertedAmount)
                .build();
        //Act
        RefundApiResponse refundApiResponse= responseServiceOnlineAPI
                .refundRequest(refundApiRequest,token());
        //assert
        Assert.assertEquals(refundApiResponse.getStatusCode(),400);
        Assert.assertEquals(refundApiResponse.getErrors()[0].getMessage(),
                "requestId is required in request body");
    }
    @DataProvider
    public Object[][] getData() throws IOException {
        OnlineApiDataPropertiesConfig dataProperties =new OnlineApiDataPropertiesConfig();
        List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                (System.getProperty("user.dir")+ dataProperties.getProperty("CrossBorderData"));
        Object[][] obj= new Object[data.size()][1];
        for(int i=0;i<data.size();i++){
            obj[i][0]=data.get(i);
        }
        return  obj;
    }

}