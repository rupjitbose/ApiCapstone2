package com.pinelabs.PayLater.OnlineAPITest;

import com.pinelabs.PayLater.API.Helpers.BaseUtils;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.API.Helpers.PLEncrypt.PLEncrypt;
import com.pinelabs.PayLater.API.Helpers.RetryTest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.*;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.AuthCaptureResponse;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.IppOfferResponse;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.TransactionStatusResponse;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceOnlineAPI;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

public class AuthCaptureApiTest extends BaseUtils {
    @BeforeSuite
    public void setReportName(){
        System.setProperty("ReportName","OnlineAPI");
    }
    private ResponseServiceOnlineAPI responseServiceOnlineAPI;

    @BeforeClass
    private void beforeClass() {
        responseServiceOnlineAPI = new ResponseServiceOnlineAPI();}

    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void checkAuthCaptureWithPreAuthPositiveFlow(HashMap<Object,Object> input) throws Exception {

        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);

        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .cardApprovalCode(input.get("cardApprovalCode").toString())
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(7)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(0)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        long transactionId = transactionStatusResponse.getTransactionId();
        //arrange
        AuthCaptureRequest authCaptureRequest=new AuthCaptureRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .transactionId(transactionId)
                .build();
        //Act
        AuthCaptureResponse authCaptureResponse= responseServiceOnlineAPI
                .authCaptureRequest(authCaptureRequest,token());
        //assert
        Assert.assertEquals(authCaptureResponse.getMerchantId(),input.get("merchantId").toString());
        Assert.assertEquals(authCaptureResponse.getStatus(),"success");
        Assert.assertEquals(authCaptureResponse.getStatusCode(),200);
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void authCaptureForSaleTransactionShouldFail(HashMap<Object,Object> input) throws Exception {
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);

        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .cardApprovalCode(input.get("cardApprovalCode").toString())
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(0)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        long transactionId = transactionStatusResponse.getTransactionId();

        //arrange
        AuthCaptureRequest authCaptureRequest=new AuthCaptureRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .transactionId(transactionId)
                .build();
        //Act
        AuthCaptureResponse authCaptureResponse= responseServiceOnlineAPI
                .authCaptureRequest(authCaptureRequest,token());
        //assert
        Assert.assertEquals(authCaptureResponse.getStatus(),"fail");
        Assert.assertEquals(authCaptureResponse.getStatusCode(),400);
        Assert.assertEquals(authCaptureResponse.getErrors()[0].getMessage(),"transaction status of transaction should be 7(AUTH) before updating to 8(CAPTURE)");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void checkAuthCaptureShouldFailWhenAuthCaptureAlreadyPerformedOnTheSameTransactionId(HashMap<Object,Object> input) throws Exception {
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);

        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .cardApprovalCode(input.get("cardApprovalCode").toString())
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(7)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(0)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        long transactionId = transactionStatusResponse.getTransactionId();
        //arrange
        AuthCaptureRequest authCaptureRequest=new AuthCaptureRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .transactionId(transactionId)
                .build();
        //Act
        responseServiceOnlineAPI.authCaptureRequest(authCaptureRequest,token());
        AuthCaptureResponse authCaptureResponse= responseServiceOnlineAPI
                .authCaptureRequest(authCaptureRequest,token());
        //assert
        Assert.assertEquals(authCaptureResponse.getStatus(),"fail");
        Assert.assertEquals(authCaptureResponse.getStatusCode(),400);
        Assert.assertEquals(authCaptureResponse.getErrors()[0].getMessage(),"transaction status of transaction should be 7(AUTH) before updating to 8(CAPTURE)");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void checkAuthCaptureWhenTxnAlreadyRefundedShouldFail(HashMap<Object,Object> input) throws Exception {
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);

        //Placing a transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .cardApprovalCode(input.get("cardApprovalCode").toString())
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(9)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(0)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        long transactionId = transactionStatusResponse.getTransactionId();
        //Do Refund
        RefundApiRequest refundApiRequest=new RefundApiRequest.Builder()
                .transactionAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .transactionId(transactionId)
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .build();
        responseServiceOnlineAPI.refundRequest(refundApiRequest,token());
        //arrange
        AuthCaptureRequest authCaptureRequest=new AuthCaptureRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .transactionId(transactionId)
                .build();
        //Act
        AuthCaptureResponse authCaptureResponse= responseServiceOnlineAPI
                .authCaptureRequest(authCaptureRequest,token());
        //assert
        Assert.assertEquals(authCaptureResponse.getStatus(),"fail");
        Assert.assertEquals(authCaptureResponse.getStatusCode(),400);
        Assert.assertEquals(authCaptureResponse.getErrors()[0].getMessage(),"transaction status of transaction should be 7(AUTH) before updating to 8(CAPTURE)");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void checkAuthCaptureWhenDifferentAmountsFromTxnAmountShouldFail(HashMap<Object,Object> input) throws Exception {
        double txnAmount=1000;
        double authCaptureAmount=800;
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(txnAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);

        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(txnAmount)
                .pspId(input.get("pspId").toString())
                .amount(txnAmount)
                .cardApprovalCode(input.get("cardApprovalCode").toString())
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(txnAmount)
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(7)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(0)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        long transactionId = transactionStatusResponse.getTransactionId();
        //arrange
        AuthCaptureRequest authCaptureRequest=new AuthCaptureRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .amount(authCaptureAmount)
                .transactionId(transactionId)
                .build();
        //Act
        AuthCaptureResponse authCaptureResponse= responseServiceOnlineAPI
                .authCaptureRequest(authCaptureRequest,token());
        //assert

        Assert.assertEquals(authCaptureResponse.getStatus(),"fail");
        Assert.assertEquals(authCaptureResponse.getStatusCode(),400);
        Assert.assertEquals(authCaptureResponse.getErrors()[0].getMessage(),
                "amount in pspResponse in pspDetails does not match with EMI calculated value");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class)
    public void checkAuthCaptureForAlreadyCancelledTxnShouldFail(HashMap<Object,Object> input) throws Exception {
        //Calling IPP offer to get scheme/issuer details to place transaction
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());

        int issuerIndex = IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex = IppOfferResponse.getTenureIndex(ippOfferResponse, issuerIndex, Integer.parseInt(input.get("tenure").toString()));
        String fullCardNo = input.get("cardNumber").toString();
        String comboOfEncryptKey = PLEncrypt.generate(fullCardNo);

        //Placing a pre-auth transaction
        TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest.Builder()
                //data is fetched from OnlineTransaction JSON
                .merchantId(input.get("merchantId").toString())
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0, 8)))
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .cardApprovalCode(input.get("cardApprovalCode").toString())
                .rrn(input.get("rrn").toString())
                .currencyCode(Integer.parseInt(input.get("merchantCurrencyCodeNum").toString()))
                .acquirerId(input.get("acquirerId").toString())
                .acquirerName(input.get("acquirerName").toString())
                .txnTime(input.get("txnTime").toString())
                .cardCurrCode(Integer.parseInt(input.get("cardCurrCode").toString()))
                .cardCurrAmt(Double.parseDouble(input.get("totalAmount").toString()))
                //Dynamic Encryption of Full card number
                .encMcCardNo(PLEncrypt.getencMcCardNo(comboOfEncryptKey))
                .iv(PLEncrypt.getiv(comboOfEncryptKey))
                .wrappedKey(PLEncrypt.getWrappedKey(comboOfEncryptKey))
                //We can directly set some default values to the below fields
                .transactionStatus(7)
                .isDccAuth(0)
                .dccConversionRate("0")
                .isCrossBorder(0)
                .mid("1234543")
                //These values are getting fetched from IPPoffer API
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeId())
                .paymentType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .schemeDescription(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSchemeDescription())
                .installmentConfigID(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInstallmentConfigID())
                .productType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProductType())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProgramType())
                .geoScope(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getGeoScope())
                .isSchemeValid(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getIsSchemeValid())
                .bankInterestRate(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getBankInterestRate())
                .processingFeeValue(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getProcessingFeeValue())
                .subventionType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getSubventionType())
                .interestAmountCharged(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getInterestAmountCharged())
                .loanAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getLoanAmount())
                .authAmount(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getAuthAmount())
                .monthlyInstallment(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                        tenureIndex).getMonthlyInstallment())
                .build();

        TransactionStatusResponse transactionStatusResponse = responseServiceOnlineAPI
                .createTransactionStatusRequest(transactionStatusRequest, token());
        //capture the transaction ID
        long transactionId = transactionStatusResponse.getTransactionId();
        //Do Auth Cancel
        AuthCancelRequest authCancelRequest=new AuthCancelRequest.Builder()
                .transactionAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .transactionId(transactionId)
                .build();
        responseServiceOnlineAPI.authCancelRequest(authCancelRequest,token());
        //arrange
        AuthCaptureRequest authCaptureRequest=new AuthCaptureRequest.Builder()
                .merchantId(input.get("merchantId").toString())
                .pspId(input.get("pspId").toString())
                .amount(Double.parseDouble(input.get("totalAmount").toString()))
                .transactionId(transactionId)
                .build();
        //Act
        AuthCaptureResponse authCaptureResponse= responseServiceOnlineAPI
                .authCaptureRequest(authCaptureRequest,token());
        //assert
        Assert.assertEquals(authCaptureResponse.getStatus(),"fail");
        Assert.assertEquals(authCaptureResponse.getStatusCode(),400);
        Assert.assertEquals(authCaptureResponse.getErrors()[0].getMessage(),
                "No online transaction detail entry found for capture, for transactionId: "+transactionId);
    }

    @DataProvider
    public Object[][] getData() throws IOException {
        OnlineApiDataPropertiesConfig dataProperties =new OnlineApiDataPropertiesConfig();
        List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                (System.getProperty("user.dir")+ dataProperties.getProperty("Data"));
        Object[][] obj= new Object[data.size()][1];
        for(int i=0;i<data.size();i++){
            obj[i][0]=data.get(i);
        }
        return  obj;
    }

}
