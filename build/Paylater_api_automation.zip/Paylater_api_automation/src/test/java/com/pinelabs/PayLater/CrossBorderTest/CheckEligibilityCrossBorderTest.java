package com.pinelabs.PayLater.CrossBorderTest;

import com.pinelabs.PayLater.API.Helpers.BaseUtils;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.API.Helpers.RetryTest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.CheckEligibilityRequest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.IppOfferRequest;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.CheckEligibilityResponse;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.IppOfferResponse;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceOnlineAPI;
import org.jetbrains.annotations.NotNull;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

public class CheckEligibilityCrossBorderTest extends BaseUtils {
    @BeforeSuite
    public void setReportName(){
        System.setProperty("ReportName","CrossBorderOnlineAPI");
    }
    private ResponseServiceOnlineAPI responseServiceOnlineAPI;
    @BeforeClass
    public void beforeClass() {
        responseServiceOnlineAPI = new ResponseServiceOnlineAPI();
    }

    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description="bank Check Eligibility Positive flow for Cross Border")
    public void checkEligibilityCrossBorder_TC01(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        //pre req
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();

        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(convertedAmount)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),200);
        Assert.assertEquals(checkEligibilityResponse.getIsEligible(),"true");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description = "Check Eligibility Should Show Eligibility Failure Reason When Card Number Invalid")
    public void checkEligibilityCrossBorder_TC02(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(12345678)
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(convertedAmount)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),200);
        Assert.assertEquals(checkEligibilityResponse.getEligibilityFailureReason(),"Invalid Card Number,");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description = "Check Eligibility Should Fail When Card Number is Null")
    public void checkEligibilityCrossBorder_TC03(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(null)
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(convertedAmount)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),400);
        Assert.assertEquals(checkEligibilityResponse.getErrors()[0].getMessage(),
                "Invalid Bin Range. Please enter a valid first 8 digits of PAN (card number).");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description = "Check Eligibility Should  Fail When Card Number is less than 8 digits")
    public void checkEligibilityCrossBorder_TC04(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,6)))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(convertedAmount)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),400);
        Assert.assertEquals(checkEligibilityResponse.getErrors()[0].getMessage(),
                "Invalid Bin Range. Please enter a valid first 8 digits of PAN (card number).");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description = "Check Eligibility Should  Fail When Issuer Id Invalid")
    public void checkEligibilityCrossBorder_TC05(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();

        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .merchantId(input.get("merchantId").toString())
                .issuerId("123456")
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(convertedAmount)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),400);
        Assert.assertEquals(checkEligibilityResponse.getErrors()[0].getMessage(),"Field Name issuerId is either null or has invalid value.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description = "Check Eligibility Should Fail When SchemeId Invalid")
    public void checkEligibilityCrossBorder_TC06(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId("Invalid Scheme ID")
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(convertedAmount)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),400);
        Assert.assertEquals(checkEligibilityResponse.getErrors()[0].getMessage(),
                "Field Name schemeId is either null or has invalid value.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description = "Check Eligibility Should Fail Program Type Invalid")
    public void checkEligibilityCrossBorder_TC07(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();

        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType("xyz")
                .totalAmount(Double.parseDouble(input.get("totalAmount").toString()))
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),400);
        Assert.assertEquals(checkEligibilityResponse.getErrors()[0].getMessage(),
                "Field Name programType is either null or has invalid value.");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description = "Check Eligibility Should Show Eligibility Failure Reason When Tenure Invalid")
    public void checkEligibilityCrossBorder_TC08(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();

        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("issuerId").toString())
                .tenure(1)
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(convertedAmount)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),200);
        Assert.assertEquals(checkEligibilityResponse.getIsEligible(),"false");
        Assert.assertEquals(checkEligibilityResponse.getEligibilityFailureReason(),"Invalid tenure,");
    }
    @Test(dataProvider="getData",retryAnalyzer= RetryTest.class,description = "Check Eligibilit yShould Show Eligibility Failure Reason When Total Amount Invalid")
    public void checkEligibilityCrossBorder_TC09(HashMap<Object,Object> input) throws Exception {
        double convertedAmount=currencyConverter(
                input.get("merchantCurrencyCode").toString(),
                input.get("issuerCurrencyCode").toString(),
                Double.parseDouble(input.get("totalAmount").toString()));
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(convertedAmount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();

        IppOfferResponse ippOfferResponse = responseServiceOnlineAPI.createIppOfferRequest(ippOfferRequest, token());
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse,input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));
        //Arrange
        CheckEligibilityRequest checkEligibilityRequest=new CheckEligibilityRequest.Builder()
                .cardNumber(Integer.parseInt(input.get("cardNumber").toString().substring(0,8)))
                .merchantId(input.get("merchantId").toString())
                .issuerId(input.get("issuerId").toString())
                .tenure(Integer.parseInt(input.get("tenure").toString()))
                .schemeId(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getSchemeId())
                .programType(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex,tenureIndex).getProgramType())
                .totalAmount(1)
                .build();
        //Act
        CheckEligibilityResponse checkEligibilityResponse = responseServiceOnlineAPI
                .checkEligibilityRequest(checkEligibilityRequest, token());
        //assert
        Assert.assertEquals(checkEligibilityResponse.getStatusCode(),200);
        Assert.assertEquals(checkEligibilityResponse.getIsEligible(),"false");
        Assert.assertEquals(checkEligibilityResponse.getEligibilityFailureReason(),
                "Amount not in range,");
    }

    @DataProvider
    public Object[][] getData() throws IOException {
        OnlineApiDataPropertiesConfig dataProperties=new OnlineApiDataPropertiesConfig();
        List<HashMap<Object, Object>> data = getJsonArrayToListOfHashMap
                (System.getProperty("user.dir")+ dataProperties.getProperty("CrossBorderData"));
        Object[][] obj= new Object[data.size()][1];
        for(int i=0;i<data.size();i++){
            obj[i][0]=data.get(i);
        }
        return  obj;
    }
}
