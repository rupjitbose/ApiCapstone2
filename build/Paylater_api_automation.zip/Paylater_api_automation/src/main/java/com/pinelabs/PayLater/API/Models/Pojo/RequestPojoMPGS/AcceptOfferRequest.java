package com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
public class AcceptOfferRequest {
    private String termsAndConditionsAcceptance;
    private String deliveryCountry;
    private String cartOfferId;
    private AccountIdentifier accountIdentifier;
    private String currencyCode;
    private String paymentAmount;
    private List<Items> items;

    @Getter
    @Setter
    public static class Items {
        public Items setItems(String sku, int unitAmount, int quantity,String[] serialNumbers) {
            Items item=new Items();
            item.sku=sku;
            item.unitAmount=unitAmount;
            item.quantity = quantity;
            item.serialNumbers= serialNumbers;
            return item;
        }
        private int quantity;
        private String[] serialNumbers;
        private int unitAmount;
        private String sku;
    }

    @Getter
    public static class AccountIdentifier {
        private String raw;
        private String cardNumberPrefix;
        private String mask;
    }

    public AcceptOfferRequest(Builder builder) {
        this.deliveryCountry = builder.deliveryCountry;
        this.termsAndConditionsAcceptance = builder.termsAndConditionsAcceptance;
        this.cartOfferId = builder.cartOfferId;
        this.accountIdentifier = builder.accountIdentifier;
        this.currencyCode = builder.currencyCode;
        this.paymentAmount = builder.paymentAmount;
        this.items= builder.items;
    }

    public static class Builder {
        List<Items> items=new ArrayList<>();
        Items item=new Items();
        private String termsAndConditionsAcceptance;
        private String deliveryCountry;
        private String cartOfferId;
        private AccountIdentifier accountIdentifier = new AccountIdentifier();
        private String currencyCode;
        private String paymentAmount;

        public Builder() {
            //These are to assign default values to the request body
            this.deliveryCountry = "HK";
            this.termsAndConditionsAcceptance = "ACCEPTED";
            this.currencyCode = "HKD";
            this.paymentAmount = "1000";
        }

        public Builder termsAndConditionsAcceptance(String termsAndConditionsAcceptance) {
            this.termsAndConditionsAcceptance = termsAndConditionsAcceptance;
            return this;
        }

        public Builder deliveryCountry(String deliveryCountry) {
            this.deliveryCountry = deliveryCountry;
            return this;
        }

        public Builder cartOfferId(String cartOfferId) {
            this.cartOfferId = cartOfferId;
            return this;
        }

        public Builder cardNumberPrefix(String cardNumberPrefix) {
            this.accountIdentifier.cardNumberPrefix = cardNumberPrefix;
            return this;
        }

        public Builder raw(String raw) {
            this.accountIdentifier.raw = raw;
            return this;
        }

        public Builder mask(String mask) {
            this.accountIdentifier.mask = mask;
            return this;
        }

        public Builder currencyCode(String currencyCode) {
            this.currencyCode = currencyCode;
            return this;
        }

        public Builder paymentAmount(String paymentAmount) {
            this.paymentAmount = paymentAmount;
            return this;
        }
        public Builder items(List<Items> items) {
            this.items = items;
            return this;
        }
        public Builder items() {
            this.items = null;
            return this;
        }

        public AcceptOfferRequest build() {
            AcceptOfferRequest acceptOfferRequest = new AcceptOfferRequest(this);
            return acceptOfferRequest;
        }
    }
}
