package com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
public class IppOfferResponse
{
    @Setter
    private int statusCode;

    private String st;
    private String msgid;
    private String responseCode;
    private String responseMessage;
    private String msg;

    @JsonProperty("merchantId")
    private String merchantId;

    private IssuerDetails[] issuerDetails;

    private String status;

    private Errors[] errors;
    @Getter
    public static class Errors {
        private String code;

        private String message;
    }

    @Getter
    public static class IssuerDetails {
        private String issuerId;

        private String issuerName;

        private EmiTenureDetails[] emiTenureDetails;
    }

    @Getter
    public static class EmiSchemeDetails {
        private String issuerCashbackPercent;
        private String programType;
        private double monthlyInstallment;
        private String processingFeeType;
        private String distributionType;
        private String issuerCashbackType;
        private double bankInterestRate;
        private boolean isSchemeValid;
        public boolean getIsSchemeValid() {
            return isSchemeValid;
        }
        private String schemeId;
        private String subventionType;
        private double authAmount;
        private String issuerCashbackValue;
        private double interestAmountCharged;
        private String schemeDescription;
        private double loanAmount;
        private String termsAndConditions;
        private double processingFeePercent;
        private double processingFeeValue;
        private String subventionAmount;
        private String geoScope;
        private int installmentConfigID;
        private String productType;
        private String additionalChargeSlipText;
    }

    @Getter
    public static class EmiTenureDetails {
        private String tenure;
        private OfferSchemeDetails[] offerSchemeDetails;
    }
    @Getter
    public static class OfferSchemeDetails { private EmiSchemeDetails emiSchemeDetails;}

    public static int getIssuerIndex(IppOfferResponse ippOfferResponse,String issuerId){
        int issuerIndex=0;
        int totalIssuers = ippOfferResponse.getIssuerDetails().length;;
        for(int i=0;i<totalIssuers;i++){
            if(ippOfferResponse.issuerDetails[i].issuerId.equalsIgnoreCase(issuerId)){
                issuerIndex=i;
                break;
            }
        }
        return issuerIndex;
    }
    public static int getTenureIndex(IppOfferResponse ippOfferResponse,int issuerIndex,int tenure){
        int tenureIndex=0;
        int totalTenures = ippOfferResponse.getIssuerDetails()[issuerIndex].getEmiTenureDetails().length;
        for(int i=0;i<totalTenures;i++){
            if(ippOfferResponse.issuerDetails[issuerIndex]
                    .getEmiTenureDetails()[i].tenure.equalsIgnoreCase(String.valueOf(tenure))){
                tenureIndex=i;
                break;
            }
        }
        return tenureIndex;
    }
    public static IppOfferResponse.EmiSchemeDetails getEmiSchemeDetails(IppOfferResponse ippOfferResponse, int issuerIndex, int tenureIndex) {
        int offerSchemeDetailsIndex=0;
        if(ippOfferResponse.getIssuerDetails()[issuerIndex].getEmiTenureDetails()[tenureIndex]
                .getOfferSchemeDetails().length>1){
            offerSchemeDetailsIndex=1;}
        return ippOfferResponse.getIssuerDetails()[issuerIndex]
                .getEmiTenureDetails()[tenureIndex]
                .getOfferSchemeDetails()[offerSchemeDetailsIndex]
                .getEmiSchemeDetails();
    }

}
