package com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI;

import lombok.Getter;
import lombok.Setter;

@Getter
public class LoginApiResponse {
    @Setter
    private  int statusCode;
    private Boolean status;
    private String authtoken;
    private String userid;
    private String responseCode;
    private String responseMessage;

}