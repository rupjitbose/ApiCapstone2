package com.pinelabs.PayLater.API.Helpers.MpgsEncryption;

import org.testng.Reporter;

public class FrameworkException extends Throwable {
    public FrameworkException(String message) {
        super(message);
    }

    public FrameworkException(String message, Throwable throwable) {
        super(message, throwable);
       Reporter.log(throwable.getMessage());
    }

}
