package com.pinelabs.PayLater.API.Models.RequestClient;

import com.google.gson.Gson;
import com.pinelabs.PayLater.API.Helpers.MpgsEncryption.MPGSRequestEncryption;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS.*;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.IppOfferRequest;
import com.pinelabs.PayLater.CommonUtilities.ExtentReport.ExtentReportManager;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import io.restassured.specification.QueryableRequestSpecification;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.SpecificationQuerier;
import org.json.JSONObject;

import java.io.IOException;

public class RequestClientMPGS {
    OnlineApiDataPropertiesConfig dataProperties =new OnlineApiDataPropertiesConfig();
  public String getEnv() throws IOException {
      return  System.getProperty("env") != null ? System.getProperty("env") : dataProperties.getEnv();
  }
    private RequestSpecification getRequestSpecification(Object body) throws Exception {
        RestAssured.useRelaxedHTTPSValidation();
        RequestSpecification requestSpecification=RestAssured.given().log().body()
                .baseUri(dataProperties.getProperty("base-uri"))
                .header("x-rq-usr-id","3213")
                .header("Trace-Id","RSJ3XKBZW64OH")
                .header("x-rq-api-key",dataProperties.getProperty("x-rq-api-key"))
                .header("Accept-Language","en-US;q=1.0, en;q=0.5")
                .contentType(ContentType.JSON)
                .body(body);
        return requestSpecification;
    }
    private static void reportLogger(RequestSpecification requestSpecification, Response response) throws Exception {
        printRequestLogInReport(requestSpecification);
        printResponseLogInReport(response);
    }
    private static void printRequestLogInReport(RequestSpecification  requestSpecification) throws Exception {
        QueryableRequestSpecification queryableRequestSpecification = SpecificationQuerier.query(requestSpecification);
        ExtentReportManager.logInfoDetails("Endpoint is " + queryableRequestSpecification.getBaseUri());
        ExtentReportManager.logInfoDetails("Method is " + queryableRequestSpecification.getMethod());
        ExtentReportManager.logInfoDetails("Headers are ");
        ExtentReportManager.logHeaders(queryableRequestSpecification.getHeaders().asList());
        ExtentReportManager.logInfoDetails("Request body is ");
        ExtentReportManager.logJson(queryableRequestSpecification.getBody().toString());
    }
    private static void printResponseLogInReport(Response response) throws Exception {
        ExtentReportManager.logInfoDetails("Response status is " + response.getStatusCode());
        ExtentReportManager.logInfoDetails("Response body is ");
        ExtentReportManager.logJson(response.getBody().asString());
    }

    public Response merchantCapabilityRequest(MerchantCapabilityRequest body, String token, String merchantId, String requestType) throws Exception {

      RestAssured.defaultParser = Parser.JSON;
        RequestSpecification requestSpecification = null;

        if(getEnv().equalsIgnoreCase("test")) {
            String encryptedPayLoad = "{\"encryptedPayload\":\""+
                    MPGSRequestEncryption.encryptMpgsRequest(new Gson().toJson(body))+"\"}";

            requestSpecification = getRequestSpecification(encryptedPayLoad);
            System.out.println("Actual Body:\n"+ new Gson().toJson(body));
        }
        else if(getEnv().equalsIgnoreCase("uat") || getEnv().equalsIgnoreCase("mig")) {
            requestSpecification = getRequestSpecification(body);
        }
        Response response =requestSpecification.header("Authorization","Bearer "+token)
                .pathParam("merchantId",merchantId)
                .header("Request-Type",requestType)
                .when().post(dataProperties.getProperty("merchantCapability"));
        response.then().log().body();
        reportLogger(requestSpecification, response);
        return response;
    }
    public Response cartOfferRequest(CartOfferRequest body, String token, String merchantId) throws Exception {
        RequestSpecification requestSpecification = null;

        if(getEnv().equalsIgnoreCase("test")) {
            String encryptedPayLoad = "{\"encryptedPayload\":\""+
                    MPGSRequestEncryption.encryptMpgsRequest(new Gson().toJson(body))+"\"}";

            requestSpecification = getRequestSpecification(encryptedPayLoad);
            System.out.println("Actual Body:\n"+ new Gson().toJson(body));
        }
        else if(getEnv().equalsIgnoreCase("uat")) {
            requestSpecification = getRequestSpecification(body);
        }
        Response response =requestSpecification.header("Authorization","Bearer "+token)
                .pathParam("merchantId",merchantId)
                .header("Request-Type","NORMAL")
                .when().post(dataProperties.getProperty("cartOffer"));
        response.then().log().body();
        reportLogger(requestSpecification, response);
        return response;
    }
    public Response skuOfferRequest(SkuOfferRequest body, String token, String merchantId) throws Exception {
        RequestSpecification requestSpecification = null;

        if(getEnv().equalsIgnoreCase("test")) {
            String encryptedPayLoad = "{\"encryptedPayload\":\""+
                    MPGSRequestEncryption.encryptMpgsRequest(new Gson().toJson(body))+"\"}";

            requestSpecification = getRequestSpecification(encryptedPayLoad);
            System.out.println("Actual Body:\n"+ new Gson().toJson(body));
        }
       else if(getEnv().equalsIgnoreCase("uat")) {
            requestSpecification = getRequestSpecification(body);
        }

        Response response =requestSpecification.header("Authorization","Bearer "+token)
                .pathParam("merchantId",merchantId)
                .header("Request-Type","NORMAL")
                .when().post(dataProperties.getProperty("skuOffer"));
        response.then().log().body();
        reportLogger(requestSpecification, response);
        return response;
    }

    public Response acceptOfferRequest(AcceptOfferRequest body, String token, String merchantId,String paymentId) throws Exception {
        RequestSpecification requestSpecification = null;

        if(getEnv().equalsIgnoreCase("test")) {
            String encryptedPayLoad = "{\"encryptedPayload\":\""+
                    MPGSRequestEncryption.encryptMpgsRequest(new Gson().toJson(body))+"\"}";

            requestSpecification = getRequestSpecification(encryptedPayLoad);
            System.out.println("Actual Body:\n"+ new Gson().toJson(body));
        }
        else if(getEnv().equalsIgnoreCase("uat")) {
            requestSpecification = getRequestSpecification(body);
        }
        Response response =requestSpecification.header("Authorization","Bearer "+token)
                .pathParam("merchantId",merchantId)
                .pathParam("paymentId",paymentId)
                .header("Request-Type","NORMAL")
                .when().put(dataProperties.getProperty("acceptOffer"));
        response.then().log().body();
        reportLogger(requestSpecification, response);
        return response;
    }

    public Response serialNumbersRequest(SerialNumbersRequest body, String token, String merchantId, String paymentId) throws Exception {
        RequestSpecification requestSpecification = null;

        if(getEnv().equalsIgnoreCase("test")) {
            String encryptedPayLoad = "{\"encryptedPayload\":\""+
                    MPGSRequestEncryption.encryptMpgsRequest(new Gson().toJson(body))+"\"}";

            requestSpecification = getRequestSpecification(encryptedPayLoad);
            System.out.println("Actual Body:\n"+ new Gson().toJson(body));
        }
        else if(getEnv().equalsIgnoreCase("uat")) {
            requestSpecification = getRequestSpecification(body);
        }
        Response response =requestSpecification.header("Authorization","Bearer "+token)
                .pathParam("merchantId",merchantId)
                .pathParam("paymentId",paymentId)
                .header("Request-Type","NORMAL")
                .when().put(dataProperties.getProperty("serialNumbers"));
        response.then().log().all();
        reportLogger(requestSpecification, response);
        return response;
    }

    public Response postTransactionrequest(PostTransactionRequest body, String token, String merchantId, String paymentId) throws Exception {
        RequestSpecification requestSpecification = null;

        if (getEnv().equalsIgnoreCase("test")) {
            String encryptedPayLoad = "{\"encryptedPayload\":\"" +
                    MPGSRequestEncryption.encryptMpgsRequest(new Gson().toJson(body)) + "\"}";

            requestSpecification = getRequestSpecification(encryptedPayLoad);
            System.out.println("Actual Body:\n" + new Gson().toJson(body));
        } else if (getEnv().equalsIgnoreCase("uat")) {
            requestSpecification = getRequestSpecification(body);
        }
        Response response = requestSpecification.header("Authorization", "Bearer " + token)
                .pathParam("merchantId", merchantId)
                .pathParam("paymentId", paymentId)
                .header("Request-Type", "NORMAL")
                .when().put(dataProperties.getProperty("postTransaction"));
        response.then().log().all();
        reportLogger(requestSpecification, response);
        return response;
    }

    public Response cancelTransactionRequest(String token, String merchantId, String paymentId) throws Exception {
        RequestSpecification requestSpecification = getRequestSpecification("");
        Response response = requestSpecification.header("Authorization", "Bearer " + token)
                .pathParam("merchantId", merchantId)
                .pathParam("paymentId", paymentId)
                .header("Request-Type", "NORMAL")
                .when().put(dataProperties.getProperty("cancelTransaction"));
        response.then().log().all();
        reportLogger(requestSpecification, response);
        return response;
    }
}
