package com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IppOfferRequest {
    private MerchantDetails merchantDetails;
    private PaymentDetails paymentDetails;
    private int issuerCountryCode;
    public IppOfferRequest(IppOfferRequest.Builder builder) {
        this.issuerCountryCode = builder.issuerCountryCode;
        this.paymentDetails=builder.paymentDetails;
        this.merchantDetails=builder.merchantDetails;
    }

    @Getter
    @Setter
    public static class PaymentDetails {
        private Double totalAmount;
    }
    @Getter
    @Setter
    public static class MerchantDetails
    {
        private String merchantId;
    }

    public static class Builder{
        public PaymentDetails paymentDetails=new PaymentDetails();
        public MerchantDetails merchantDetails=new MerchantDetails();
        private int issuerCountryCode;

        public Builder(){
            this.issuerCountryCode=344;
            this.merchantDetails.merchantId="63f88c4d333133790a7912ed";
            this.paymentDetails.totalAmount=500.00;
        }

        public IppOfferRequest.Builder issuerCountryCode(int issuerCountryCode){
            this.issuerCountryCode=issuerCountryCode;
            return this;
        }
        public IppOfferRequest.Builder totalAmount(Double totalAmount){
            this.paymentDetails.totalAmount=totalAmount;
            return this;
        }
        public IppOfferRequest.Builder merchantId(String merchantId){
            this.merchantDetails.merchantId=merchantId;
            return this;
        }

        public IppOfferRequest build(){
            IppOfferRequest ippOfferRequest = new IppOfferRequest(this);
            return ippOfferRequest;
        }
    }

}
