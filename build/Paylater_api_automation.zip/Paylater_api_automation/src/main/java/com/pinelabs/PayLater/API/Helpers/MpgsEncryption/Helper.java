package com.pinelabs.PayLater.API.Helpers.MpgsEncryption;

import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Helper {
    private static final Logger logger = LoggerFactory.getLogger(Helper.class);
    public static String workingDir = System.getProperty("user.dir");

    public Helper() {
    }

    public static Boolean isNullOrEmpty(String value) {
        boolean isNullOrEmpty = false;
        if (value != null && !value.isEmpty()) {
            isNullOrEmpty = true;
        }

        return isNullOrEmpty;
    }

    public static String getCurrentTimeStamp() {
        SimpleDateFormat sdfDate = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss");
        Date now = new Date();
        String strDate = sdfDate.format(now);
        return strDate;
    }

    public static int generate_random_number() {
        Random r = new Random(System.currentTimeMillis());
        return 1000000000 + r.nextInt(200000000);
    }

    public static String generate_random_alphaNumeric(int n) {
        return RandomStringUtils.randomAlphanumeric(n);
    }

    public static boolean isArrayContentsAreSame(String[] arr) {
        for(int i = 1; i < arr.length; ++i) {
            if (!arr[0].equals(arr[i])) {
                return false;
            }
        }

        return true;
    }

    public static String generateRandomNumber(int length) {
        return RandomStringUtils.randomNumeric(length);
    }

    public static void waitForSeconds(String strSeconds) {
        int iSecondsEnd = Integer.parseInt(strSeconds);

        for(int second = 0; second < iSecondsEnd; ++second) {
            try {
                Thread.sleep(1000L);
            } catch (InterruptedException var4) {
                logger.info("WaitForSeconds failed");
            }
        }

    }

    public static void writeToProperty(String key, String value, String pathToPropertyFile) {
        Properties prop = new Properties();
        FileOutputStream output = null;

        try {
            prop.load(new FileInputStream(pathToPropertyFile));
            prop.setProperty(key, value);
            output = new FileOutputStream(pathToPropertyFile);
            prop.store(output, (String)null);
            System.out.println("Writing specified key - Value into property file");
        } catch (IOException var14) {
            var14.printStackTrace();
        } finally {
            if (output != null) {
                try {
                    output.close();
                } catch (IOException var13) {
                    var13.printStackTrace();
                }
            }

        }

    }

    public List<String> extractOnlyNumbersFromString(String Value) {
        List<String> result = null;
        Matcher m = Pattern.compile("\\d+").matcher(Value);
        if (m.find()) {
            result = new ArrayList();
            result.add(m.group());

            while(m.find()) {
                result.add(m.group());
            }
        }

        return result;
    }

    public String getOnlyDigits(String text) {
        text = text.replaceAll("\\D", "").trim();
        return text;
    }
}
