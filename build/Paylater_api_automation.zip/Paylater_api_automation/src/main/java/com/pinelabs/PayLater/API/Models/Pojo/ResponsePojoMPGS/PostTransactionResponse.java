package com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoMPGS;

import lombok.Getter;
import lombok.Setter;

@Getter
public class PostTransactionResponse {
    @Setter
    private int statusCode;
    private String response;
    private String serviceProviderTransactionId;
    private Errors[] errors;
    @Getter
    public static class Errors {
        private String field;
        private String description;
    }
}
