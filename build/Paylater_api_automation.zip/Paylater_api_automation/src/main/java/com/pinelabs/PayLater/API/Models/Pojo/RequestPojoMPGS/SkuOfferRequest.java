package com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class SkuOfferRequest {

    private String merchantCountry;

    private String currencyCode;

    private List<Items> items;

    @Getter
    @Setter
    public static class Items {
        public Items setItems(String sku, int unitAmount) {
            Items item=new Items();
            item.sku=sku;
            item.unitAmount=unitAmount;
            return item;
        }
        private int unitAmount;
        private String sku;

    }


    public SkuOfferRequest(SkuOfferRequest.Builder builder) {
        this.merchantCountry = builder.merchantCountry;
        this.currencyCode=builder.currencyCode;
        this.items= builder.items;
    }

    public static class Builder{
        List<Items> items=new ArrayList<>();
        Items item=new Items();
        private String merchantCountry;
        private String currencyCode;

        public Builder(){

            this.merchantCountry="HK";
            this.currencyCode="HKD";
            this.item.sku="xyz";
            this.item.unitAmount=100;
            List<Items> items=new ArrayList<>();
            items.add(item);
            this.items=items;
        }
        public SkuOfferRequest.Builder merchantCountry(String merchantCountry){
            this.merchantCountry=merchantCountry;
            return this;
        }
        public SkuOfferRequest.Builder currencyCode(String currencyCode){
            this.currencyCode=currencyCode;
            return this;
        }

        public SkuOfferRequest.Builder sku(String sku){
            this.item.sku=sku;
            return this;
        }
        public SkuOfferRequest.Builder unitAmount(int unitAmount){
            this.item.unitAmount=unitAmount;
            return this;
        }

        public SkuOfferRequest.Builder items(List<Items> items){
            this.items=items;
            return this;
        }


        public SkuOfferRequest build(){
            SkuOfferRequest skuOfferRequest = new SkuOfferRequest(this);
            return skuOfferRequest;
        }
    }
}
