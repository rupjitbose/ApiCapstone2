package com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoMPGS;

import lombok.Getter;
import lombok.Setter;

@Getter
public class CartOfferResponse {
    @Setter
    private int statusCode;
    private Offers[] offers;
    private String rejectedInterest;
    private String providerState;

   @Getter
    public static class DeferralPeriod
    {
        private String unitOfMeasure;
        private String count;
    }
   @Getter
    public static class Qualifiers {
        private String qualifierLogo;
        private String qualifierId;
        private String qualifierText;
    }
   @Getter
    public static class Offers {
        private String interestRate;
        private String termsAndConditionsAcceptance;
        private String fees;
        private String subsequentPaymentAmount;
        private TimeBetweenPayments timeBetweenPayments;
        private int cashbackAmount;
        private Qualifiers[] qualifiers;
        private String discount;
        private String firstPaymentAmount;
        private String fundingInstitution;
        private String cashbackHelp;
        private String totalAmount;
        private DeferralPeriod deferralPeriod;
        private String numberOfInstallments;
        private String termsAndConditionsText;
        private String name;
        private String cartOfferId;
        private String currencyCode;
    }

    @Getter
    public static class TimeBetweenPayments {
        private String unitOfMeasure;
        private String count;
    }
    private Errors[] errors;
    @Getter
    public static class Errors {
        private String field;
        private String description;
    }
}
