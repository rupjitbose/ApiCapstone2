package com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI;

import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;

@Getter
@Setter
public class TransactionStatusRequest {
    private PspDetails pspDetails;
    private IppData ippData;
    private String merchantId;
    private int transactionStatus;
    private String requestId;
    private int cardNumber;

    public TransactionStatusRequest(TransactionStatusRequest.Builder builder) {
        this.merchantId=builder.merchantId;
        this.cardNumber=builder.cardNumber;
        this.requestId=builder.requestId;
        this.transactionStatus=builder.transactionStatus;
        this.pspDetails=builder.pspDetails;
        this.pspDetails.pspResponse=builder.pspResponse;
        this.ippData=builder.ippData;
    }
    @Getter
    @Setter
    public static class PspDetails {
        private PspResponse pspResponse;
        private String pspId;
    }
    @Getter
    @Setter
    public static class PspResponse {
        private int isDccAuth;
        private double amount;
        private String encMcCardNo;
        private String dccConversionRate;
        private String mid;
        private String iv;
        private int cardCurrCode;
        private String cardExpiryDate;
        private String paymentType;
        private String rrn;
        private double cardCurrAmt;
        private String txnTime;
        private String refId;
        private int cardCurrMinorUnit;
        private String cardApprovalCode;
        private String acquirerId;
        private int currencyCode;
        private int minorUnit;
        private int isCrossBorder;
        private String acquirerName;
        private String wrappedKey;
    }
    @Getter
    @Setter
    public static class IppData {
        private String programType;
        private double monthlyInstallment;
        private double bankInterestRate;
        private boolean isSchemeValid;
        private String schemeId;
        private String subventionType;
        private double authAmount;
        private double interestAmountCharged;
        private String schemeDescription;
        private double loanAmount;
        private String issuerId;
        private double totalAmount;
        private double processingFeeValue;
        private String geoScope;
        private int tenure;
        private int installmentConfigID;
        private String productType;
    }

    public static class Builder{

        public String merchantId;
        public int cardNumber;
        public String requestId;
        public int transactionStatus;
        public PspDetails pspDetails=new PspDetails();
        public PspResponse pspResponse=new PspResponse();
        public IppData ippData=new IppData();
        public Builder(){
            this.merchantId="";
            this.cardNumber=0;
            this.transactionStatus=9;
            this.requestId="Req"+String.valueOf(Math.random()).substring(3,7);
            this.ippData.issuerId="";
            this.ippData.tenure=9;
            this.ippData.totalAmount=500.00;
            this.ippData.schemeId="";
            this.ippData.schemeDescription="";
            this.ippData.installmentConfigID=1345;
            this.ippData.productType="";
            this.ippData.programType="";
            this.ippData.geoScope="";
            this.ippData.isSchemeValid=true;
            this.ippData.bankInterestRate=0.0;
            this.ippData.processingFeeValue=0.0;
            this.ippData.subventionType="";
            this.ippData.interestAmountCharged=0.0;
            this.ippData.loanAmount=0.0;
            this.ippData.authAmount=0.0;
            this.ippData.monthlyInstallment=0.0;
            this.pspDetails.pspId="";
            this.pspResponse.paymentType="";
            this.pspResponse.refId="Ref"+String.valueOf(Math.random()).substring(3,7);
            this.pspResponse.encMcCardNo="";
            this.pspResponse.iv="";
            this.pspResponse.wrappedKey="";
            this.pspResponse.amount=5;
            this.pspResponse.cardApprovalCode="AC"+String.valueOf(Math.random()).substring(3,7);
            this.pspResponse.rrn="RRN"+String.valueOf(Math.random()).substring(3,7);
            this.pspResponse.currencyCode=0;
            this.pspResponse.minorUnit=2;
            this.pspResponse.acquirerId="";
            this.pspResponse.acquirerName="";
            this.pspResponse.mid="";
            this.pspResponse.txnTime=new Timestamp(System.currentTimeMillis()).toString().substring(0,19)
                    .replaceAll("[^a-zA-Z0-9]","");
            this.pspResponse.isDccAuth=0;
            this.pspResponse.dccConversionRate="";
            this.pspResponse.isCrossBorder=0;
            this.pspResponse.cardCurrCode=702;
            this.pspResponse.cardCurrMinorUnit=2;
            this.pspResponse.cardCurrAmt=0;
            this.pspResponse.cardExpiryDate="11/29";
        }
        public TransactionStatusRequest.Builder merchantId(String merchantId){
            this.merchantId=merchantId;
            return this;
        }
        public TransactionStatusRequest.Builder cardNumber(int cardNumber){
            this.cardNumber=cardNumber;
            return this;
        }
        public TransactionStatusRequest.Builder requestId(String merchantId){
            this.requestId=requestId;
            return this;
        }
        public TransactionStatusRequest.Builder transactionStatus(int transactionStatus){
            this.transactionStatus=transactionStatus;
            return this;
        }
        public TransactionStatusRequest.Builder issuerId(String issuerId){
            this.ippData.issuerId=issuerId;
            return this;
        }
        public TransactionStatusRequest.Builder tenure(int tenure){
            this.ippData.tenure=tenure;
            return this;
        }
        public TransactionStatusRequest.Builder totalAmount(double totalAmount){
            this.ippData.totalAmount=totalAmount;
            return this;
        }
        public TransactionStatusRequest.Builder schemeId(String schemeId){
            this.ippData.schemeId=schemeId;
            return this;
        }
        public TransactionStatusRequest.Builder schemeDescription(String schemeDescription){
            this.ippData.schemeDescription=schemeDescription;
            return this;
        }
        public TransactionStatusRequest.Builder installmentConfigID(int installmentConfigID){
            this.ippData.installmentConfigID=installmentConfigID;
            return this;
        }
        public TransactionStatusRequest.Builder productType(String productType){
            this.ippData.productType=productType;
            return this;
        }
        public TransactionStatusRequest.Builder programType(String programType){
            this.ippData.programType=programType;
            return this;
        }
        public TransactionStatusRequest.Builder geoScope(String geoScope){
            this.ippData.geoScope=geoScope;
            return this;
        }
        public TransactionStatusRequest.Builder isSchemeValid(boolean isSchemeValid){
            this.ippData.isSchemeValid=isSchemeValid;
            return this;
        }
        public TransactionStatusRequest.Builder bankInterestRate(double bankInterestRate){
            this.ippData.bankInterestRate=bankInterestRate;
            return this;
        }
        public TransactionStatusRequest.Builder processingFeeValue(double processingFeeValue){
            this.ippData.processingFeeValue=processingFeeValue;
            return this;
        }

        public TransactionStatusRequest.Builder subventionType(String subventionType) {
            this.ippData.subventionType = subventionType;
            return this;
        }
        public TransactionStatusRequest.Builder interestAmountCharged(double interestAmountCharged) {
            this.ippData.interestAmountCharged = interestAmountCharged;
            return this;
        }
        public TransactionStatusRequest.Builder loanAmount(double loanAmount) {
            this.ippData.loanAmount = loanAmount;
            return this;
        }
        public TransactionStatusRequest.Builder authAmount(double authAmount) {
            this.ippData.authAmount = authAmount;
            return this;
        }
        public TransactionStatusRequest.Builder monthlyInstallment(double monthlyInstallment) {
            this.ippData.monthlyInstallment = monthlyInstallment;
            return this;
        }
        public TransactionStatusRequest.Builder pspId(String pspId) {
            this.pspDetails.pspId = pspId;
            return this;
        }
        public TransactionStatusRequest.Builder paymentType(String paymentType) {
            this.pspResponse.paymentType = paymentType;
            return this;
        }

        public TransactionStatusRequest.Builder refId(String refId) {
            this.pspResponse.refId = refId;
            return this;
        }
        public TransactionStatusRequest.Builder encMcCardNo(String encMcCardNo) {
            this.pspResponse.encMcCardNo = encMcCardNo;
            return this;
        }
        public TransactionStatusRequest.Builder iv(String iv) {
            this.pspResponse.iv = iv;
            return this;
        }
        public TransactionStatusRequest.Builder wrappedKey(String wrappedKey) {
            this.pspResponse.wrappedKey = wrappedKey;
            return this;
        }
        public TransactionStatusRequest.Builder amount(double amount) {
            this.pspResponse.amount = amount;
            return this;
        }
        public TransactionStatusRequest.Builder cardApprovalCode(String cardApprovalCode) {
            this.pspResponse.cardApprovalCode = cardApprovalCode;
            return this;
        }

        public TransactionStatusRequest.Builder rrn(String rrn) {
            this.pspResponse.rrn = rrn;
            return this;
        }
        public TransactionStatusRequest.Builder currencyCode(int currencyCode) {
            this.pspResponse.currencyCode = currencyCode;
            return this;
        }
        public TransactionStatusRequest.Builder minorUnit(int minorUnit) {
            this.pspResponse.minorUnit = minorUnit;
            return this;
        }
        public TransactionStatusRequest.Builder acquirerId(String acquirerId) {
            this.pspResponse.acquirerId = acquirerId;
            return this;
        }
        public TransactionStatusRequest.Builder acquirerName(String acquirerName) {
            this.pspResponse.acquirerName = acquirerName;
            return this;
        }
        public TransactionStatusRequest.Builder mid(String mid) {
            this.pspResponse.mid = mid;
            return this;
        }
        public TransactionStatusRequest.Builder txnTime(String txnTime) {
            this.pspResponse.txnTime = txnTime;
            return this;
        }
        public TransactionStatusRequest.Builder isDccAuth(int isDccAuth) {
            this.pspResponse.isDccAuth = isDccAuth;
            return this;
        }
        public TransactionStatusRequest.Builder dccConversionRate(String dccConversionRate) {
            this.pspResponse.dccConversionRate = dccConversionRate;
            return this;
        }
        public TransactionStatusRequest.Builder isCrossBorder(int isCrossBorder) {
            this.pspResponse.isCrossBorder = isCrossBorder;
            return this;
        }
        public TransactionStatusRequest.Builder cardCurrCode(int cardCurrCode) {
            this.pspResponse.cardCurrCode = cardCurrCode;
            return this;
        }
        public TransactionStatusRequest.Builder cardCurrMinorUnit(int cardCurrMinorUnit) {
            this.pspResponse.cardCurrMinorUnit = cardCurrMinorUnit;
            return this;
        }
        public TransactionStatusRequest.Builder cardCurrAmt(double cardCurrAmt) {
            this.pspResponse.cardCurrAmt = cardCurrAmt;
            return this;
        }
        public TransactionStatusRequest.Builder cardExpiryDate(String cardExpiryDate) {
            this.pspResponse.cardExpiryDate = cardExpiryDate;
            return this;
        }
        public TransactionStatusRequest build(){
            TransactionStatusRequest transactionStatusRequest = new TransactionStatusRequest(this);
            return transactionStatusRequest;
        }
    }
}
