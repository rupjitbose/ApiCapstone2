package com.pinelabs.PayLater.API.Helpers;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class OnlineApiDataPropertiesConfig {
    private String value="";
    private Properties properties;


    public String getEnv() throws IOException {
        properties=new Properties();
        FileInputStream fis=new FileInputStream(System.getProperty("user.dir")+"/src/main/resources/MCI_Online_data/setEnv.properties");
        properties.load(fis);
        value=System.getProperty("env")!=null ?System.getProperty("env"):properties.getProperty("env");
        return value;
    }
    public String setEnv(String env1) throws IOException {
        properties=new Properties();
        FileInputStream fis=new FileInputStream(System.getProperty("user.dir")+"/src/main/resources/MCI_Online_data/ENV.properties");
        properties.load(fis);
        value=System.getProperty("uat")!=null ?System.getProperty("uat"):properties.getProperty(env1);
        value=System.getProperty("test")!=null ?System.getProperty("test"):properties.getProperty(env1);
        return value;
    }

    public String getProperty(String key) throws IOException {
        properties=new Properties();
        FileInputStream fis=new FileInputStream(System.getProperty("user.dir")+setEnv(getEnv()));
        properties.load(fis);
        value=System.getProperty("Data")!=null ?System.getProperty("Data"):properties.getProperty(key);
        return value;
    }
}
