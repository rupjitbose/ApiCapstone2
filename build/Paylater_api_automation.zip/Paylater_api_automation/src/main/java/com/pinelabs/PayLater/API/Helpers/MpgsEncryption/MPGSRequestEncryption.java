package com.pinelabs.PayLater.API.Helpers.MpgsEncryption;

import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.RSADecrypter;
import com.nimbusds.jose.crypto.RSAEncrypter;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jwt.SignedJWT;

import org.apache.commons.codec.binary.Hex;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.text.ParseException;
import java.util.Base64;
import java.util.zip.GZIPOutputStream;

public class MPGSRequestEncryption {

	private static PrivateKey privateKey;
	private static RSAPublicKey publicKey;
	
	static {
		try {
			loadKeys();
		} catch (ConfigPropertyException | FrameworkException e) {
			e.printStackTrace();
		}
	}
	
	private static void loadKeys() throws ConfigPropertyException, FrameworkException {
		String base64PrivateKey = LoadProperties.getPropertyValue("mpgs.privatekey");
		String base64PublicKey = LoadProperties.getPropertyValue("pinelabs.publickey");
		privateKey = getPrivateKey(base64PrivateKey);
		publicKey = getPublicKey(base64PublicKey);
	}
	
	public static String encryptMpgsRequest(String payloadString) throws Exception {

		// Generate SH256 Thumbprint of Public key
		// Create Header
		JWSHeader header = new JWSHeader.Builder(JWSAlgorithm.PS256)
				//.x509CertSHA256Thumbprint(Base64URL.from(thumbprint))
				.build();
		// Add Payload
		Payload payload = new Payload(getCompressedRequest(payloadString));
		JWSObject jwsObject = new JWSObject(header, payload);

		// Sign the message
		jwsObject.sign(getSigner(privateKey));

		// Encrypt the message.
		JWEObject jweObject = new JWEObject(buildJweHeaderForSignAndEncrypt(""),
				new Payload(jwsObject.serialize()));
		jweObject.encrypt(getEncrypter(publicKey));

		// Serialize the payload
		String encryptedPayload = jweObject.serialize();
		return encryptedPayload;
	}
	
	private static byte[] getCompressedRequest(String toCompress) throws IOException {
		final ByteArrayOutputStream out = new ByteArrayOutputStream(toCompress.length());
		try (final GZIPOutputStream gzip = new GZIPOutputStream(out)) {
			gzip.write(toCompress.getBytes(StandardCharsets.UTF_8));
			gzip.finish();
			byte[] compressedBytes = out.toByteArray();
			return compressedBytes;
		}
	}
	
	public static void decryptMpgsRequest(String encryptedPayload) throws ParseException, JOSEException {
		JWEObject jwt = JWEObject.parse(encryptedPayload);
      
        //Decrypt using Pine Labs private key
        jwt.decrypt(new RSADecrypter(privateKey));

        // Verify the Signature and get the payload using MPGS Public Key
        SignedJWT signedJWT = jwt.getPayload().toSignedJWT();
        boolean isVerified = signedJWT.verify(new RSASSAVerifier(publicKey));

        System.out.println("Message Verified : " + isVerified);
        String data = signedJWT.getPayload().toString();

        System.out.println("Payload :" + data);
	}
	
	public static RSAPublicKey getPublicKey(String base64PublicKey) {
		RSAPublicKey publicKey = null;
		try {
			X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(base64PublicKey.getBytes()));
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			publicKey = (RSAPublicKey) keyFactory.generatePublic(keySpec);
			return publicKey;
		} catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
			System.out.println("Error in getPublicKey "+ e);
		}
		return publicKey;
	}

	public static PrivateKey getPrivateKey(String base64PrivateKey) {
		PrivateKey privateKey = null;
		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(base64PrivateKey.getBytes()));
		KeyFactory keyFactory = null;
		try {
			keyFactory = KeyFactory.getInstance("RSA");
			privateKey = keyFactory.generatePrivate(keySpec);
		} catch (NoSuchAlgorithmException |InvalidKeySpecException e) {
			System.out.println("Error in getPrivateKey "+ e);
		}
		return privateKey;
	}

	private static JWEEncrypter getEncrypter(RSAPublicKey key) {
		JWEEncrypter encrypter = new RSAEncrypter(key);
		encrypter.getJCAContext().setSecureRandom(new SecureRandom());
		return encrypter;
	}

	private static JWEHeader buildJweHeaderForSignAndEncrypt(String thumbprint) throws CertificateEncodingException {
		EncryptionMethod encryptionMethod = EncryptionMethod.A256GCM;
		JWEAlgorithm jweAlgorithm = JWEAlgorithm.RSA_OAEP_256;
		return new JWEHeader.Builder(jweAlgorithm, encryptionMethod)
				//.x509CertSHA256Thumbprint(Base64URL.from(thumbprint))
				.build();
	}

	private static String getHexEncodedThumbprint(X509Certificate certificate) throws Exception {
		String algorithm = "SHA-256";
		MessageDigest md = MessageDigest.getInstance(algorithm);
		byte[] digest = md.digest(certificate.getEncoded());
		return Hex.encodeHexString(digest).toLowerCase();
	}

	private static JWSSigner getSigner(PrivateKey privateKey) {
		JWSSigner signer = new RSASSASigner(privateKey);
		return signer;
	}
}
