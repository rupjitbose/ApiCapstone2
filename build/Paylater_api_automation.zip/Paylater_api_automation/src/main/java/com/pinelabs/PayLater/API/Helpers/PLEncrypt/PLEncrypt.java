package com.pinelabs.PayLater.API.Helpers.PLEncrypt;


import com.nimbusds.jose.EncryptionMethod;
import com.nimbusds.jose.JWEAlgorithm;
import com.nimbusds.jose.JWEHeader;
import com.nimbusds.jose.JWEObject;
import com.nimbusds.jose.util.Base64URL;
import com.pinelabs.PayLater.API.Helpers.ConstantFilePath;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource.PSpecified;
import javax.xml.bind.DatatypeConverter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.MGF1ParameterSpec;
import java.util.Base64;
import java.util.Scanner;

public class PLEncrypt {
    private static final Integer SYMMETRIC_KEY_SIZE = 128;
    protected static final String SYMMETRIC_KEY_TYPE = "AES";
    private static final String ASYMMETRIC_CYPHER = "RSA/ECB/OAEPWith{ALG}AndMGF1Padding";
    private static final String OAEP_PADDING_DIGEST_ALGO = "SHA-256";
    private static final String SYMMETRIC_CYPHER = "AES/CBC/PKCS5Padding";

    public PLEncrypt() {
    }

    public static void main(String[] var0) throws Exception {
        System.out.println("Enter the Pan: ");
        Scanner sc =new Scanner(System.in);
        String var1 =sc.nextLine();
        generateKey(var1);
    }

    public static String generateKey(String fullPanNo) throws Exception {

        String combinedEncp="";
        if(fullPanNo.length() !=0) {
            combinedEncp=generate(fullPanNo);
        }
        else{
            System.out.println("!!!!!!!!!!!!!Please enter valid clearPAN!!!!!!!!!!!!!!!!!!");
        }

        return combinedEncp;
    }
    public static String getencMcCardNo(String combinedEncp){
        return combinedEncp.split(",")[0];
    }
    public static String getiv(String combinedEncp){
        return combinedEncp.split(",")[1];
    }
    public static String getWrappedKey(String combinedEncp){
        return combinedEncp.split(",")[2];
    }
    public static String generate(String input) throws Exception {
        IvParameterSpec var1 = generateIv();
        String var2 = DatatypeConverter.printBase64Binary(var1.getIV());
        SecretKey var3 = generateSecretKey();
        byte[] var4 = wrapSecretKey(var3);
        byte[] var6 = input.getBytes(StandardCharsets.UTF_8);
        byte[] var7 = encryptBytes(var3, var1, var6);
        System.out.println("clearPAN : " + input);
        System.out.println("-----------------------");
        System.out.println("{");
        System.out.println("\"encMcCardNo\" : \"" + DatatypeConverter.printBase64Binary(var7) + "\",");
        System.out.println("\"iv\" :\"" + var2 + "\",");
        System.out.println("\"wrappedKey\" :\"" + DatatypeConverter.printBase64Binary(var4) + "\"");
        System.out.println("}");
        System.out.println("-----------------------");
        return DatatypeConverter.printBase64Binary(var7)+","+var2+","+DatatypeConverter.printBase64Binary(var4);
    }


    protected static byte[] encryptBytes(Key key, AlgorithmParameterSpec algorithmParameterSpec, byte[] b2) throws GeneralSecurityException {
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(1, key, algorithmParameterSpec);
        return cipher.doFinal(b2);
    }

    private static IvParameterSpec generateIv() throws Exception {
        try {
            SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
            byte[] b1 = new byte[16];
            secureRandom.nextBytes(b1);
            return new IvParameterSpec(b1);
        } catch (GeneralSecurityException e) {
            throw new Exception("Failed to generate an IV value!", e);
        }
    }

    private static SecretKey generateSecretKey() throws Exception {
        try {
            KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
            keyGenerator.init(SYMMETRIC_KEY_SIZE);
            SecretKey secretKey = keyGenerator.generateKey();
            return secretKey;
        } catch (GeneralSecurityException e) {
            throw new Exception("Failed to generate a secret key!", e);
        }
    }

    protected static byte[] wrapSecretKey(Key key) throws Exception {

        String path= ConstantFilePath.ENCRYPTCERTIFICATE;
        try {
            PublicKey var1 = loadEncryptionCertificate(path).getPublicKey();
            MGF1ParameterSpec var2 = new MGF1ParameterSpec("SHA-256");
            String var3 = "RSA/ECB/OAEPWith{ALG}AndMGF1Padding".replace("{ALG}", var2.getDigestAlgorithm());
            Cipher var4 = Cipher.getInstance(var3);
            var4.init(3, var1, getOaepParameterSpec(var2));
            byte[] var5 = var4.wrap(key);
            return var5;
        } catch (GeneralSecurityException var6) {
            throw new Exception("Failed to wrap secret key!", var6);
        } catch (Exception var7) {
            throw new Exception("Failed to wrap secret key!", var7);
        }
    }

    private static OAEPParameterSpec getOaepParameterSpec(MGF1ParameterSpec MGF1ParameterSpec) {
        return new OAEPParameterSpec(MGF1ParameterSpec.getDigestAlgorithm(), "MGF1", MGF1ParameterSpec, PSpecified.DEFAULT);
    }

    public static Certificate loadEncryptionCertificate(String path) throws CertificateException, FileNotFoundException {
        CertificateFactory var1 = CertificateFactory.getInstance("X.509");
        Certificate var2 = var1.generateCertificate(new FileInputStream(path));
        return var2;
    }

    public static String getMpgsEncryptedAccountIdentifier(String cardNumber) throws Exception {
        JWEAlgorithm alg = JWEAlgorithm.RSA_OAEP_256;
        EncryptionMethod enc = EncryptionMethod.A256GCM;

        JWEHeader header = new JWEHeader(alg, enc);

        SecretKey generateSecretKey = generateSecretKey();
        byte[] wrapSecretKey = wrapSecretKey(generateSecretKey);
        String wrappedKey =Base64.getEncoder().encodeToString(wrapSecretKey);
        Base64URL secondPart = new Base64URL(wrappedKey);

        IvParameterSpec generateIv = generateIv();
        String printBase64BIV = Base64.getEncoder().encodeToString(generateIv.getIV());
        Base64URL thirdPart = new Base64URL(printBase64BIV);

        byte[] encryptBytes = encryptBytes(generateSecretKey, generateIv, cardNumber.getBytes(StandardCharsets.UTF_8.name()));
        String encryptedPAN = Base64.getEncoder().encodeToString(encryptBytes);
        Base64URL fourthPart = new Base64URL(encryptedPAN);

        JWEObject jweObject = new JWEObject(header.toBase64URL(), secondPart, thirdPart, fourthPart, null);

        return jweObject.serialize();
    }

}
