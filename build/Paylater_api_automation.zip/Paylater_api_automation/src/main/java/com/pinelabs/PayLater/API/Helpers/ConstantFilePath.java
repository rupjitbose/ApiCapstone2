package com.pinelabs.PayLater.API.Helpers;

import java.io.File;

public class ConstantFilePath {
    public static final String ENCRYPTCERTIFICATE = System.getProperty("user.dir") + File.separator + "src"
            +File.separator+"main"+File.separator+"java"
            +File.separator+"com"+File.separator+"pinelabs"+File.separator+"PayLater"
            +File.separator+"API"+File.separator+"Helpers"+File.separator+"PLEncrypt"
            +File.separator+"mtf.InstallmentsMobile.mastercard.int.pem";
    public static final String ENCRYPTMPGS = System.getProperty("user.dir") + File.separator + "src"
            +File.separator+"main"+File.separator+"java"
            +File.separator+"com"+File.separator+"pinelabs"+File.separator+"PayLater"
            +File.separator+"API"+File.separator+"Helpers"+File.separator+"MpgsEncryption"
            +File.separator+"config.properties";
}
