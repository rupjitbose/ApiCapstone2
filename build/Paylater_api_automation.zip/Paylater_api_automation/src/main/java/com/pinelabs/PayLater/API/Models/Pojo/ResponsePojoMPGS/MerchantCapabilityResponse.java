package com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoMPGS;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;

@Getter
public class MerchantCapabilityResponse {

    private Object object;
    @Setter
    private int statusCode;
    private int cachePeriod;
    private ArrayList<String> supportedPans;
    private ArrayList<String> supportedCurrencies;
    private String supportedOfferTypes;
    private Object supportedQualifiers;
    private ArrayList<Object> offersSupportedForSkus;
    private Object standingOffers;
    private Introduction introduction;
    private Object paymentModes;
    private Object providerState;
    private Object operations;

    @Getter
    public static class Introduction{
        private String text;
        private String logo;
    }
    public ArrayList<Error> errors;
    @Getter
    public static class Error{
        private Object field;
        private String description;
    }

}
