package com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI;

import lombok.Getter;

import java.sql.Timestamp;

@Getter
public class RefundApiRequest {
    private String merchantId;
    private String pspId;
    private Long transactionId;
    private String requestId;
    private Double transactionAmount;
    private int cardNumber;
    private String cardApprovalCode;
    private String refundDateTime;

    public RefundApiRequest(RefundApiRequest.Builder builder) {
        this.merchantId = builder.merchantId;
        this.pspId = builder.pspId;
        this.transactionId = builder.transactionId;
        this.requestId = builder.requestId;
        this.transactionAmount = builder.transactionAmount;
        this.cardNumber = builder.cardNumber;
        this.cardApprovalCode = builder.cardApprovalCode;
        this.refundDateTime = builder.refundDateTime;

    }

    public static class Builder{
        private String merchantId;
        private String pspId;
        private Long transactionId;
        private String requestId;
        private Double transactionAmount;
        private int cardNumber;
        private String cardApprovalCode;
        private String refundDateTime;
        public Builder(){
            this.merchantId = "";
            this.pspId = "";
            this.requestId = "req"+String.valueOf(Math.random()).substring(3,7);
            this.transactionAmount = 0.0;
            this.cardNumber = 12345678;
            this.cardApprovalCode = "AC"+String.valueOf(Math.random()).substring(3,7);
            this.refundDateTime = new Timestamp(System.currentTimeMillis()).toString().substring(0,19)
                    .replace("-","")
                    .replace(" ","")
                    .replace(":","");
        }


        public RefundApiRequest.Builder merchantId(String merchantId){
            this.merchantId=merchantId;
            return this;
        }
        public RefundApiRequest.Builder requestId(String requestId){
            this.requestId=requestId;
            return this;
        }
        public RefundApiRequest.Builder transactionId(Long transactionId){
            this.transactionId=transactionId;
            return this;
        }
        public RefundApiRequest.Builder pspId(String pspId){
            this.pspId=pspId;
            return this;
        }
        public RefundApiRequest.Builder transactionAmount(Double transactionAmount){
            this.transactionAmount=transactionAmount;
            return this;
        }
        public RefundApiRequest.Builder cardNumber(int cardNumber){
            this.cardNumber=cardNumber;
            return this;
        }
        public RefundApiRequest.Builder refundDateTime(String refundDateTime){
            this.refundDateTime=refundDateTime;
            return this;
        }
        public RefundApiRequest build(){
            RefundApiRequest refundApiRequest = new RefundApiRequest(this);
            return refundApiRequest;
        }
    }
}
