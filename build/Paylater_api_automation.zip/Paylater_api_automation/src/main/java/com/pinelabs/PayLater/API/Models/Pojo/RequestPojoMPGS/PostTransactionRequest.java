package com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS;

import lombok.Getter;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

@Getter
public class PostTransactionRequest {
    private String providerAcquirerId;
    private String acquirerMerchantId;
    private Transaction transaction;

    @Getter
    public static class Transaction {
        private String authorizationCode;
        private String stan;
        private String encryptedAccountIdentifier;
        private String transactionDate;
        private String type;
        private String rrn;
    }

    public PostTransactionRequest(Builder builder) {
        this.providerAcquirerId = builder.providerAcquirerId;
        this.acquirerMerchantId = builder.acquirerMerchantId;
        this.transaction = builder.transaction;

    }

    public static class Builder {
        private String transactionDate;
        private String providerAcquirerId;
        private String acquirerMerchantId;
        private Transaction transaction = new Transaction();
        private String rrn;
        private String authorizationCode;

        public Builder() {
            //These are to assign default values to the request body
            this.transaction.transactionDate = (new Timestamp(System.currentTimeMillis()).toString().substring(0,19)
                    .replace(" ","T")+"Z");
            this.transaction.rrn ="RRN" + String.valueOf(Math.random()).substring(3, 7);
            this.transaction.authorizationCode = "AC" + String.valueOf(Math.random()).substring(3, 7);
            this.providerAcquirerId = "59";
        }
        public Builder providerAcquirerId(String providerAcquirerId) {
            this.providerAcquirerId = providerAcquirerId;
            return this;
        }

        public Builder acquirerMerchantId(String acquirerMerchantId) {
            this.acquirerMerchantId = acquirerMerchantId;
            return this;
        }
        public Builder authorizationCode(String authorizationCode) {
            this.transaction.authorizationCode = authorizationCode;
            return this;
        }
        public Builder stan(String stan) {
            this.transaction.stan = stan;
            return this;
        }
        public Builder encryptedAccountIdentifier(String encryptedAccountIdentifier) {
            this.transaction.encryptedAccountIdentifier = encryptedAccountIdentifier;
            return this;
        }
        public Builder transactionDate(String transactionDate) {
            this.transaction.transactionDate = transactionDate;
            return this;
        }
        public Builder type(String type) {
            this.transaction.type = type;
            return this;
        }
        public Builder rrn(String rrn) {
            this.transaction.rrn = rrn;
            return this;
        }

        public PostTransactionRequest build() {
            PostTransactionRequest postTransactionRequest = new PostTransactionRequest(this);
            return postTransactionRequest;
        }
    }
}
