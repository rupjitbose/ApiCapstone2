package com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class LoginApiRequest {

    private String username;
    private String password;

    public LoginApiRequest(LoginApiRequest.Builder builder) {
        this.username = builder.username;
        this.password = builder.password;
    }

    public static class Builder{
        private String username;
        private String password;
        public Builder(){
            this.username="mastercarduseruat";
            this.password="9cfa8b4a48bbaecb9c3ca375ae3315890910c5044727a0ea";
        }


        public LoginApiRequest.Builder username(String username){
            this.username=username;
            return this;
        }
        public LoginApiRequest.Builder password(String password){
            this.password=password;
            return this;
        }
        public LoginApiRequest build(){
            LoginApiRequest loginApiRequest = new LoginApiRequest(this);
            return loginApiRequest;
        }
    }


}