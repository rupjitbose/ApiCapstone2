package com.pinelabs.PayLater.API.Helpers;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryTest implements IRetryAnalyzer {
    int c=0;
    int max=1;
 @Override
    public boolean retry(ITestResult result) {
        if(c<max) {
            c++;
            return true;
        }
    return false;
    }
}
