package com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI;

import lombok.Getter;
import lombok.Setter;

@Getter
public class MciCurrencyConversionResponse {
    @Setter
    private int statusCode;
    private Data data;
    private String date;
    private String description;
    private String name;
    private Object type;
    @Getter
    public class Data{
        private double conversionRate;
        private double crdhldBillAmt;
        private double transAmt;
        private String fxDate;
        private String transCurr;
        private String crdhldBillCurr;
        private Object bankFee;
        private Object errorCode;
        private Object errorMessage;
    }
}
