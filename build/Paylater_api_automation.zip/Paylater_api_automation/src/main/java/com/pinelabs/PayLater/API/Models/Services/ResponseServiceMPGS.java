package com.pinelabs.PayLater.API.Models.Services;

import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS.*;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoMPGS.*;
import com.pinelabs.PayLater.API.Models.RequestClient.RequestClientMPGS;
import io.restassured.response.Response;

public class ResponseServiceMPGS {
    public MerchantCapabilityResponse merchantCapabilityRequest
            (MerchantCapabilityRequest merchantCapabilityRequest, String token, String merchantId, String requestType) throws Exception {
        Response response=new RequestClientMPGS().merchantCapabilityRequest(merchantCapabilityRequest,token, merchantId, requestType);
        MerchantCapabilityResponse merchantCapabilityResponse = response.as(MerchantCapabilityResponse.class);
        merchantCapabilityResponse.setStatusCode(response.statusCode());
        return merchantCapabilityResponse;
    }

    public Response RequestHeaderType
            (MerchantCapabilityRequest merchantCapabilityRequest, String token, String merchantId, String requestType) throws Exception {
        Response response=new RequestClientMPGS().merchantCapabilityRequest(merchantCapabilityRequest,token, merchantId, requestType);
        return response;
    }

    public CartOfferResponse cartOfferRequest
            (CartOfferRequest cartOfferRequest, String token, String merchantId) throws Exception {
        Response response=new RequestClientMPGS().cartOfferRequest(cartOfferRequest,token, merchantId);
        CartOfferResponse cartOfferResponse = response.as(CartOfferResponse.class);
        cartOfferResponse.setStatusCode(response.statusCode());
        return cartOfferResponse;
    }
    public SkuOfferResponse skuOfferRequest
            (SkuOfferRequest skuOfferRequest, String token, String merchantId) throws Exception {
        Response response=new RequestClientMPGS().skuOfferRequest(skuOfferRequest,token, merchantId);
        SkuOfferResponse skuOfferResponse = response.as(SkuOfferResponse.class);
        skuOfferResponse.setStatusCode(response.statusCode());
        return skuOfferResponse;
    }

    public AcceptOfferResponse acceptOfferRequest
            (AcceptOfferRequest acceptOfferRequest, String token, String merchantId,String paymentId) throws Exception {
        Response response=new RequestClientMPGS().acceptOfferRequest(acceptOfferRequest,token, merchantId, paymentId);
        AcceptOfferResponse acceptOfferResponse = response.as(AcceptOfferResponse.class);
        acceptOfferResponse.setStatusCode(response.statusCode());
        return acceptOfferResponse;
    }

    public SerialNumbersResponse serialNumbersRequest
            (SerialNumbersRequest serialNumbersRequest, String token, String merchantId,String paymentId) throws Exception {
        Response response=new RequestClientMPGS().serialNumbersRequest(serialNumbersRequest,token, merchantId, paymentId);
        SerialNumbersResponse serialNumbersResponse = response.as(SerialNumbersResponse.class);
        serialNumbersResponse.setStatusCode(response.statusCode());
        return serialNumbersResponse;
    }

    public PostTransactionResponse postTransactionRequest
            (PostTransactionRequest postTransactionRequest, String token, String merchantId,String paymentId) throws Exception {
        Response response=new RequestClientMPGS().postTransactionrequest(postTransactionRequest,token, merchantId, paymentId);
        PostTransactionResponse postTransactionResponse = response.as(PostTransactionResponse.class);
        postTransactionResponse.setStatusCode(response.statusCode());
        return postTransactionResponse;
    }

    public CancelTransactionResponse cancelTransactionRequest
            (String token, String merchantId,String paymentId) throws Exception {
        Response response = new RequestClientMPGS().cancelTransactionRequest(token, merchantId, paymentId);
        CancelTransactionResponse cancelTransactionResponse = response.as(CancelTransactionResponse.class);
        cancelTransactionResponse.setStatusCode(response.statusCode());
        return cancelTransactionResponse;
    }
}
