package com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI;

import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.IppOfferRequest;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceOnlineAPI;
import lombok.Getter;
import lombok.Setter;
import org.testng.Assert;

import java.util.HashMap;

@Getter
public class EmiCalculatorResponse {

    @Setter
    private int statusCode;
    private String msg;
    private String st;
    private String msgid;

    private String devErrorMessage;

    private Attrs[] attrs;

    @Getter
    public static class Attrs {
        private String isHighlighted;

        private String position;

        private String type;

        private String value;
    }

    private Errors[] errors;

    private String status;
    @Getter
    public static class Errors {
        private String code;

        private String message;
    }

    public static void assertEmiCalculatorValueWithIppOffer(HashMap<Object, Object> input, EmiCalculatorResponse emiCalculatorResponse, String token, ResponseServiceOnlineAPI rs,double amount) throws Exception {
        IppOfferRequest ippOfferRequest = new IppOfferRequest.Builder()
                .totalAmount(amount)
                .issuerCountryCode(Integer.parseInt(input.get("issuerCountryCodeNum").toString()))
                .merchantId(input.get("merchantId").toString()).build();
        IppOfferResponse ippOfferResponse = rs.createIppOfferRequest(ippOfferRequest,token);
        int issuerIndex=IppOfferResponse.getIssuerIndex(ippOfferResponse, input.get("issuerId").toString());
        int tenureIndex=IppOfferResponse.getTenureIndex(ippOfferResponse,issuerIndex,Integer.parseInt(input.get("tenure").toString()));

        if(emiCalculatorResponse.getAttrs()[14].getValue().equalsIgnoreCase("BANK")){
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[0].getValue().replace("%",""),String.valueOf(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                    tenureIndex).getBankInterestRate()));
            Assert.assertEquals(Double.parseDouble(emiCalculatorResponse.getAttrs()[4].getValue()),
                    IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex, tenureIndex).getAuthAmount());
            Assert.assertEquals(Double.parseDouble(emiCalculatorResponse.getAttrs()[5].getValue()),IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                    tenureIndex).getLoanAmount());
            Assert.assertEquals(Double.parseDouble(emiCalculatorResponse.getAttrs()[7].getValue()),IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                    tenureIndex).getInterestAmountCharged());
            Assert.assertEquals(Double.parseDouble(emiCalculatorResponse.getAttrs()[8].getValue()),IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                    tenureIndex).getMonthlyInstallment());
            Assert.assertEquals(Double.parseDouble(emiCalculatorResponse.getAttrs()[17].getValue()),IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                    tenureIndex).getProcessingFeeValue());
        }
        else if(emiCalculatorResponse.getAttrs()[18].getValue().equalsIgnoreCase("MERCHANT")){
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[0].getValue().replace("%",""),String.valueOf(IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                    tenureIndex).getBankInterestRate()));
            Assert.assertEquals(Double.parseDouble(emiCalculatorResponse.getAttrs()[4].getValue()),
                    IppOfferResponse.getEmiSchemeDetails(ippOfferResponse,issuerIndex, tenureIndex).getAuthAmount());
            Assert.assertEquals(Double.parseDouble(emiCalculatorResponse.getAttrs()[5].getValue()),IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                    tenureIndex).getLoanAmount());
            Assert.assertEquals(Double.parseDouble(emiCalculatorResponse.getAttrs()[7].getValue()),IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                    tenureIndex).getInterestAmountCharged());
            Assert.assertEquals(Double.parseDouble(emiCalculatorResponse.getAttrs()[8].getValue()),IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                    tenureIndex).getMonthlyInstallment());
            Assert.assertEquals(Double.parseDouble(emiCalculatorResponse.getAttrs()[22].getValue()),IppOfferResponse.getEmiSchemeDetails(ippOfferResponse, issuerIndex,
                    tenureIndex).getProcessingFeeValue());
        }

    }

    public static void assertCalculatedValue(HashMap<Object, Object> input, EmiCalculatorResponse emiCalculatorResponse) {
        if(input.get("installmentConfigType").toString().equalsIgnoreCase("MERCHANT")){
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[0].getValue(), input.get("Interest Rate"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[1].getValue(), input.get("Instalment Plan Product Price"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[2].getValue(), input.get("Transaction Amount"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[3].getValue(), input.get("Tenure"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[4].getValue(), input.get("Auth Amount"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[5].getValue(), input.get("Loan Amount"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[6].getValue(), input.get("Interest Rate Charged to CH"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[7].getValue(), input.get("Total Interest Amount to CH"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[8].getValue(), input.get("EMI Amount"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[9].getValue(), input.get("Cost to Customer"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[10].getValue(), input.get("Issuer Cash Back Percentage"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[11].getValue(), input.get("Issuer Fixed Cashback Amount"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[12].getValue(), input.get("Final Cashback Amount"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[13].getValue(), input.get("Cashback Type"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[14].getValue(), input.get("Merchant Subvention Percentage"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[15].getValue(), input.get("Merchant Subvention Amt"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[16].getValue(), input.get("Merchant Cashback Percentage"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[17].getValue(), input.get("Merchant Cashback Amt"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[18].getValue(), input.get("Instalment Program Type"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[19].getValue(), input.get("Subvention Type"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[20].getValue(), input.get("Distribution Type"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[21].getValue(), input.get("Customer Processing Fee"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[22].getValue(), input.get("Customer Processing Amount"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[23].getValue(), input.get("Interest Amount Charged"));
        }
        else if (input.get("installmentConfigType").toString().equalsIgnoreCase("BANK")){
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[0].getValue(), input.get("Interest Rate"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[1].getValue(), input.get("Instalment Plan Product Price"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[2].getValue(), input.get("Transaction Amount"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[3].getValue(), input.get("Tenure"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[4].getValue(), input.get("Auth Amount"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[5].getValue(), input.get("Loan Amount"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[6].getValue(), input.get("Interest Rate Charged to CH"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[7].getValue(), input.get("Total Interest Amount to CH"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[8].getValue(), input.get("EMI Amount"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[9].getValue(), input.get("Cost to Customer"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[10].getValue(), input.get("Issuer Cash Back Percentage"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[11].getValue(), input.get("Issuer Fixed Cashback Amount"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[12].getValue(), input.get("Final Cashback Amount"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[13].getValue(), input.get("Cashback Type"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[14].getValue(), input.get("Instalment Program Type"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[15].getValue(), input.get("Distribution Type"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[16].getValue(), input.get("Customer Processing Fee"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[17].getValue(), input.get("Customer Processing Amount"));
            Assert.assertEquals(emiCalculatorResponse.getAttrs()[18].getValue(), input.get("Interest Amount Charged"));
        }
    }
}


