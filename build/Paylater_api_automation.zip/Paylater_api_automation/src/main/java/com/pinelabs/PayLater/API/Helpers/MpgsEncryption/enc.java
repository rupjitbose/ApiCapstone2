package com.pinelabs.PayLater.API.Helpers.MpgsEncryption;

import com.pinelabs.PayLater.API.Helpers.PLEncrypt.PLEncrypt;
import org.testng.annotations.Test;

import java.sql.Timestamp;

public class enc {
    @Test
    public void env() throws Exception {
        System.out.println(PLEncrypt.getMpgsEncryptedAccountIdentifier("5420840012345678"));
    }
}
