package com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI;

import lombok.Getter;
import lombok.Setter;

@Getter
public class MciCurrencyConversionRequest {
    private double bankFee;
    private String crdhldBillCurr;
    private String fxDate;
    private double transAmt;
    private String transCurr;

    public MciCurrencyConversionRequest(MciCurrencyConversionRequest.Builder builder) {
        this.bankFee = builder.bankFee;
        this.crdhldBillCurr=builder.crdhldBillCurr;
        this.fxDate=builder.fxDate;
        this.transAmt=builder.transAmt;
        this.transCurr=builder.transCurr;
    }


    public static class Builder{
        private double bankFee;
        private String crdhldBillCurr;
        private String fxDate;
        private double transAmt;
        private String transCurr;

        public Builder(){
            this.bankFee=0.0;
            this.crdhldBillCurr="SGD";
            this.fxDate="0000-00-00";
            this.transCurr="HKD";
        }

        public MciCurrencyConversionRequest.Builder bankFee(double bankFee){
            this.bankFee=bankFee;
            return this;
        }
        public MciCurrencyConversionRequest.Builder crdhldBillCurr(String crdhldBillCurr){
            this.crdhldBillCurr=crdhldBillCurr;
            return this;
        }
        public MciCurrencyConversionRequest.Builder fxDate(String fxDate){
            this.fxDate=fxDate;
            return this;
        }
        public MciCurrencyConversionRequest.Builder transCurr(String transCurr){
            this.transCurr=transCurr;
            return this;
        }
        public MciCurrencyConversionRequest.Builder transAmt(double transAmt){
            this.transAmt=transAmt;
            return this;
        }


        public MciCurrencyConversionRequest build(){
            MciCurrencyConversionRequest mciCurrencyConversionRequest = new MciCurrencyConversionRequest(this);
            return mciCurrencyConversionRequest;
        }
    }

}
