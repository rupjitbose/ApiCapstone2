package com.pinelabs.PayLater.API.Helpers;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.LoginApiRequest;
import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.MciCurrencyConversionRequest;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.LoginApiResponse;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.MciCurrencyConversionResponse;
import com.pinelabs.PayLater.API.Models.Services.ResponseServiceOnlineAPI;
import org.apache.commons.io.FileUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;

public class BaseUtils {
    public static String token() throws Exception {
        OnlineApiDataPropertiesConfig dataPropertiesConfig=new OnlineApiDataPropertiesConfig();
        ResponseServiceOnlineAPI responseServiceOnlineAPI = new ResponseServiceOnlineAPI();
        LoginApiRequest loginApiRequest = new LoginApiRequest.Builder()
                .username(dataPropertiesConfig.getProperty("username"))
                .password(dataPropertiesConfig.getProperty("password")).build();
        LoginApiResponse loginApiResponse = responseServiceOnlineAPI.createLoginRequest(loginApiRequest);
        return loginApiResponse.getAuthtoken();
    }
    public static double currencyConverter(String merchantCurrencyCode,String issuerCurrencyCode,double transAmt) throws Exception {
        ResponseServiceOnlineAPI responseServiceOnlineAPI = new ResponseServiceOnlineAPI();
        MciCurrencyConversionRequest mciCurrencyConversionRequest=new MciCurrencyConversionRequest.Builder()
                .crdhldBillCurr(merchantCurrencyCode)
                .transCurr(issuerCurrencyCode)
                .transAmt(transAmt)
                .build();
        MciCurrencyConversionResponse mciCurrencyConversionResponse=responseServiceOnlineAPI.
                currencyConversionRequest(mciCurrencyConversionRequest,token());
        final DecimalFormat df = new DecimalFormat("0.00");
        double roundOfValue= Double.parseDouble(df.format(mciCurrencyConversionResponse.getData().getCrdhldBillAmt()));
        return roundOfValue;
    }

    public static void assertTransactionInDB(long transactionId,int transactionStatus) throws SQLException {
        PostgresqlConnection postgresqlConnection=new PostgresqlConnection();
        Assert.assertTrue(postgresqlConnection
                .checkInDB("select transaction_status,fk_transaction_id,* from public.tbl_online_transaction_detail\n" +
                        "where (fk_transaction_id in ("+transactionId+")\n" +
                        "or refund_original_transaction_id in ("+transactionId+"))\n" +
                        "and transaction_status="+transactionStatus+";"));
    }
    public static void assertFormulaCalculationInTransactionDB(long transactionId,String field,String formula) throws SQLException {
        PostgresqlConnection postgresqlConnection=new PostgresqlConnection();
        String query="select Cast (* as decimal(20,2)) from public.tbl_online_transaction_detail " +
                "where fk_transaction_id="+transactionId+";";
        Assert.assertEquals(postgresqlConnection.fetchFromDB(query.replace("*",field)),
                postgresqlConnection.fetchFromDB(query.replace("*",formula)));
    }
    public static void assertFieldValueInTransactionDB(String transactionType, long transactionId, String field, Object value) throws SQLException {
        PostgresqlConnection postgresqlConnection=new PostgresqlConnection();
        String query=null;

        if(transactionType.equalsIgnoreCase("refund")){
            query="select # from public.tbl_online_transaction_detail " +
                    "where refund_original_transaction_id="+transactionId+";";
        }
        else {
            query="select # from public.tbl_online_transaction_detail " +
                    "where fk_transaction_id="+transactionId+";";
        }

        if(field.contains("_time")){
            Assert.assertEquals(postgresqlConnection.
                            fetchFromDB(query.replace("#", field)).toString()
                            .replaceAll("[^0-9]",""), value);
        }
        else if(value.getClass().toString().replace("class java.lang.","")
                .equalsIgnoreCase("Double")){
            Assert.assertEquals(Double.parseDouble(postgresqlConnection.
                    fetchFromDB(query.replace("#","Cast ("+field+" as decimal(20,2))"))),
                    Double.parseDouble(value.toString()));
        }
        else if(value.getClass().toString().replace("class java.lang.","")
                .equalsIgnoreCase("Integer")){
            Assert.assertEquals(Integer.parseInt(postgresqlConnection.
                    fetchFromDB(query.replace("#", field))),
                    Integer.parseInt(value.toString()));
        }
        else if(value.getClass().toString().replace("class java.lang.","")
                .equalsIgnoreCase("String")){
            Assert.assertEquals(String.valueOf(postgresqlConnection.
                    fetchFromDB(query.replace("#", field))),
                    String.valueOf(value));
        }

    }
//    @Test
//    public void check(){
//    String value=null;
//        System.out.println(String.valueOf(value).getClass());
//    }

    public static List<HashMap<Object,Object>> getJsonArrayToListOfHashMap(String path) throws IOException {
        //Read Json as String
        String jstring = FileUtils.readFileToString(new File(path), StandardCharsets.UTF_8);
        // Convert String to HashMap
        ObjectMapper mapper = new ObjectMapper();
        List<HashMap<Object, Object>> data = mapper.readValue(jstring, new TypeReference<List<HashMap<Object,Object>>>() {});
        return data;
    }
    public static void assertAcceptOfferInDB(String cartOfferId,String acceptOfferResponse) throws SQLException {
        PostgresqlConnection postgresqlConnection=new PostgresqlConnection();
        Assert.assertTrue(postgresqlConnection
                .checkInDB("select cart_offer_id,accept_offer_response,* from public.tbl_mpgs_accepted_offer_details\n" +
                        "where cart_offer_id in ('"+cartOfferId+"');"));
    }

}
