package com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI;

import lombok.Getter;
import lombok.Setter;

@Getter
public class AuthCancelResponse {
    @Setter
    private int statusCode;
    private String merchantId;
    private long transactionId;
    private String status;
    private Errors[] errors;

    @Getter
    public static class Errors {
        private String code;
        private String message;

    }
}


