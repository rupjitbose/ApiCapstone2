package com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
public class SerialNumbersRequest {
    private List<UpdatedItems> updatedItems;

    public SerialNumbersRequest(Builder builder) {
        this.updatedItems= builder.updatedItems;
    }

    @Getter
    @Setter
    public static class UpdatedItems {
        public UpdatedItems setItems(String sku,String[] serialNumbers) {
            UpdatedItems updatedItems=new UpdatedItems();
            updatedItems.sku=sku;
            updatedItems.serialNumbers= serialNumbers;
            return updatedItems;
        }
        private String[] serialNumbers;
        private String sku;
    }

    public static class Builder {
        List<UpdatedItems> updatedItems=new ArrayList<>();
        UpdatedItems updatedItem=new UpdatedItems();

        public Builder updatedItems(List<UpdatedItems> updatedItems) {
            this.updatedItems = updatedItems;
            return this;
        }
        public Builder updatedItems() {
            this.updatedItems = null;
            return this;
        }
        public SerialNumbersRequest build() {
            SerialNumbersRequest serialNumbersRequest = new SerialNumbersRequest(this);
            return serialNumbersRequest;
        }
    }
}
