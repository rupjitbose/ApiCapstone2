package com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthCaptureRequest {

    private String merchantId;
    private String requestId;
    private long transactionId;
    private int transactionStatus;
    private PspDetails pspDetails;

    public AuthCaptureRequest(AuthCaptureRequest.Builder builder) {
        this.merchantId = builder.merchantId;
        this.requestId=builder.requestId;
        this.transactionId=builder.transactionId;
        this.transactionStatus=builder.transactionStatus;
        this.pspDetails=builder.pspDetails;
        this.pspDetails.pspResponse=builder.pspResponse;
    }

    @Getter
    @Setter
    public static class PspDetails{
        public String pspId;
        public PspResponse pspResponse;
    }
    @Getter
    @Setter
    public static class PspResponse{
        public double amount;
    }

    public static class Builder{
        public String merchantId;
        public String requestId;
        public long transactionId;
        public int transactionStatus;

        public PspDetails pspDetails=new PspDetails();
        public PspResponse pspResponse=new PspResponse();
        public Builder(){
            this.requestId="REQ"+String.valueOf(Math.random()).substring(3,7);
            this.transactionStatus=8;
            this.pspDetails.pspId="";
            this.pspResponse.amount=0.0;
        }
        public AuthCaptureRequest.Builder merchantId(String merchantId){
            this.merchantId=merchantId;
            return this;
        }
        public AuthCaptureRequest.Builder requestId(String requestId){
            this.requestId=requestId;
            return this;
        }
        public AuthCaptureRequest.Builder transactionId(long transactionId){
            this.transactionId=transactionId;
            return this;
        }
        public AuthCaptureRequest.Builder transactionStatus(int transactionStatus){
            this.transactionStatus=transactionStatus;
            return this;
        }
        public AuthCaptureRequest.Builder pspId(String pspId){
            this.pspDetails.pspId=pspId;
            return this;
        }
        public AuthCaptureRequest.Builder amount(double amount){
            this.pspResponse.amount=amount;
            return this;
        }
        public AuthCaptureRequest build(){
            AuthCaptureRequest authCaptureRequest = new AuthCaptureRequest(this);
            return authCaptureRequest;
        }
    }

}
