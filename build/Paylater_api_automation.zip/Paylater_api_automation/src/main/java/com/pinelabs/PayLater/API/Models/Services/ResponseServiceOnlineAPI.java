package com.pinelabs.PayLater.API.Models.Services;

import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.*;
import com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI.*;
import com.pinelabs.PayLater.API.Models.RequestClient.RequestClientOnlineAPI;
import io.restassured.response.Response;

public class ResponseServiceOnlineAPI {
    public LoginApiResponse createLoginRequest(LoginApiRequest body) throws Exception {
        Response response=new RequestClientOnlineAPI().createLoginRequest(body);
        LoginApiResponse createBlogPostResponse = response.as(LoginApiResponse.class);
        createBlogPostResponse.setStatusCode(response.statusCode());
        return createBlogPostResponse;
    }
    public IppOfferResponse createIppOfferRequest(IppOfferRequest body, String token) throws Exception {
        Response response=new RequestClientOnlineAPI().createIppOfferRequest(body,token);
        IppOfferResponse ippOfferResponse = response.as(IppOfferResponse.class);
        ippOfferResponse.setStatusCode(response.statusCode());
        return ippOfferResponse;
    }
    public TransactionStatusResponse createTransactionStatusRequest(TransactionStatusRequest body, String token) throws Exception {
        Response response=new RequestClientOnlineAPI().createTransactionStatusRequest(body,token);
        TransactionStatusResponse transactionStatusResponse = response.as(TransactionStatusResponse.class);
        transactionStatusResponse.setStatusCode(response.statusCode());
        return transactionStatusResponse;
    }
    public EmiCalculatorResponse emiCalculatorRequest(EmiCalculatorRequest emiCalculatorRequestBody, String token) throws Exception {
        Response response = new RequestClientOnlineAPI().emiCalculatorRequest(emiCalculatorRequestBody,token);
        EmiCalculatorResponse emiCalculatorResponseAll = response.as(EmiCalculatorResponse.class);
        emiCalculatorResponseAll.setStatusCode(response.statusCode());
        return emiCalculatorResponseAll;
    }
    public CheckEligibilityResponse checkEligibilityRequest(CheckEligibilityRequest body, String token) throws Exception {
        Response response=new RequestClientOnlineAPI().checkEligibilityRequest(body,token);
        CheckEligibilityResponse checkEligibilityResponse = response.as(CheckEligibilityResponse.class);
        checkEligibilityResponse.setStatusCode(response.statusCode());
        return checkEligibilityResponse;
    }
    public AuthCancelResponse authCancelRequest(AuthCancelRequest body, String token) throws Exception {
        Response response = new RequestClientOnlineAPI().authCancelRequest(body,token);
        AuthCancelResponse authCancelResponse = response.as(AuthCancelResponse.class);
        authCancelResponse.setStatusCode(response.statusCode());
        return authCancelResponse;
    }
    public AuthCaptureResponse authCaptureRequest(AuthCaptureRequest body, String token) throws Exception {
        Response response = new RequestClientOnlineAPI().authCaptureRequest(body,token);
        AuthCaptureResponse authCaptureResponse = response.as(AuthCaptureResponse.class);
        authCaptureResponse.setStatusCode(response.statusCode());
        return authCaptureResponse;
    }
    public RefundApiResponse refundRequest(RefundApiRequest body, String token) throws Exception {
        Response response = new RequestClientOnlineAPI().refundRequest(body,token);
        RefundApiResponse refundApiResponse = response.as(RefundApiResponse.class);
        refundApiResponse.setStatusCode(response.statusCode());
        return refundApiResponse;
    }
    public MciCurrencyConversionResponse currencyConversionRequest(MciCurrencyConversionRequest body, String token) throws Exception {
        Response response = new RequestClientOnlineAPI().currencyConversionRequest(body,token);
        MciCurrencyConversionResponse mciCurrencyConversionResponse = response.as(MciCurrencyConversionResponse.class);
        mciCurrencyConversionResponse.setStatusCode(response.statusCode());
        return mciCurrencyConversionResponse;
    }

}
