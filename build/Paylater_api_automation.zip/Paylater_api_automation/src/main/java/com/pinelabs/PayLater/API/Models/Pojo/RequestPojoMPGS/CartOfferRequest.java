package com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
public class CartOfferRequest {
    private String deliveryCountry;
    private String currencyCode;
    private int paymentAmount;
    private List<Items> items;

   @Getter
   @Setter
    public static class Items {
       public Items setItems(String sku, int unitAmount, int quantity) {
           Items item=new Items();
           item.sku=sku;
           item.unitAmount=unitAmount;
           item.quantity = quantity;
           item.serialNumbers= new String[]{"3635"};
           return item;
       }
        int quantity;
        String[] serialNumbers;
        int unitAmount;
        String sku;
    }
    public CartOfferRequest(CartOfferRequest.Builder builder) {
        this.deliveryCountry = builder.deliveryCountry;
        this.currencyCode = builder.currencyCode;
        this.paymentAmount = builder.paymentAmount;
        this.items= builder.items;
    }

    public static class Builder {
        List<Items> items=new ArrayList<>();
        Items item=new Items();
        private String deliveryCountry;
        private String currencyCode;
        private int paymentAmount;

        public Builder() {
            //These are to assign default values to the request body
            this.deliveryCountry = "HK";
            this.currencyCode = "HKD";
            this.paymentAmount = 1000;
//            List<Items> items=new ArrayList<>();
//            items.add(item);
//            this.items=items;
        }

        public CartOfferRequest.Builder deliveryCountry(String deliveryCountry) {
            this.deliveryCountry = deliveryCountry;
            return this;
        }

        public CartOfferRequest.Builder currencyCode(String currencyCode) {
            this.currencyCode = currencyCode;
            return this;
        }

        public CartOfferRequest.Builder paymentAmount(int paymentAmount) {
            this.paymentAmount = paymentAmount;
            return this;
        }
        public CartOfferRequest.Builder items(List<Items> items) {
            this.items = items;
            return this;
        }
        public CartOfferRequest.Builder items() {
            this.items = null;
            return this;
        }

        public CartOfferRequest build() {
            CartOfferRequest cartOfferRequest = new CartOfferRequest(this);
            return cartOfferRequest;
        }
    }
}
