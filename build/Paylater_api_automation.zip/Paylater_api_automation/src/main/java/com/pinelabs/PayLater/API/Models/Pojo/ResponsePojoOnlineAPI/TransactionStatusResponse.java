package com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI;

import lombok.Getter;
import lombok.Setter;

@Getter
public class TransactionStatusResponse {
    @Setter
    public int statusCode;
    public String status;
    public String merchantId;
    public String issuerId;
    public int cardNumber;
    public long transactionId;
    public String requestId;
    private Errors[] errors;
    @Getter
    public static class Errors {
        private String code;
        private String message;
    }
}
