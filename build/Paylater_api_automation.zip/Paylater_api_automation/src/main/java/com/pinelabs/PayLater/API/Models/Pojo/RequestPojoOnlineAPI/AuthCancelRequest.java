package com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI;

import lombok.Getter;

@Getter
public class AuthCancelRequest {
    private String merchantId;
    private String requestId;
    private double transactionAmount;
    private String pspId;
    private long transactionId;

    public AuthCancelRequest(AuthCancelRequest.Builder builder) {

        this.merchantId = builder.merchantId;
        this.requestId = builder.requestId;
        this.transactionAmount = builder.transactionAmount;
        this.pspId = builder.pspId;
        this.transactionId = builder.transactionId;
    }

    public static class Builder {
        public String merchantId;
        public String requestId;
        public double transactionAmount;
        public String pspId;
        public long transactionId;

        public Builder(){
            this.requestId="REQ"+String.valueOf(Math.random()).substring(3,7);
        }

        public AuthCancelRequest.Builder merchantId(String merchantId) {
            this.merchantId = merchantId;
            return this;
        }
        public AuthCancelRequest.Builder transactionAmount(double transactionAmount) {
            this.transactionAmount = transactionAmount;
            return this;
        }
        public AuthCancelRequest.Builder requestId(String requestId) {
            this.requestId = requestId;
            return this;
        }
        public AuthCancelRequest.Builder pspId(String pspId) {
            this.pspId = pspId;
            return this;
        }
        public AuthCancelRequest.Builder transactionId(long transactionId) {
            this.transactionId = transactionId;
            return this;
        }
        public AuthCancelRequest build(){
            AuthCancelRequest authCancelRequest = new AuthCancelRequest(this);
            return authCancelRequest;
        }

    }
}
