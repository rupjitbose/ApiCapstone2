package com.pinelabs.RnD.API.Models.New.Pojo;

import lombok.Getter;

@Getter
public class EmiCalRequest {

    public String amount;
    public String installmentConfigId;
    public String installmentConfigType;
    public String issuerId;
    public String terminalId;
    public int tenure;
    public String merchantCurrencyCode;
    public String issuerCurrencyCode;
    public int issuerCountryCodeNum;

    public EmiCalRequest(EmiCalRequest.Builder builder) {

        this.amount = builder.amount;
        this.installmentConfigId = builder.installmentConfigId;
        this.installmentConfigType = builder.installmentConfigType;
        this.issuerId = builder.issuerId;
        this.terminalId = builder.terminalId;
        this.tenure = builder.tenure;
        this.merchantCurrencyCode = builder.merchantCurrencyCode;
        this.issuerCurrencyCode = builder.issuerCurrencyCode;
        this.issuerCountryCodeNum = builder.issuerCountryCodeNum;
    }

    public static class Builder {
        public String amount;
        public String installmentConfigId;
        public String installmentConfigType;
        public String issuerId;
        public String terminalId;
        public int tenure;
        public String merchantCurrencyCode;
        public String issuerCurrencyCode;
        public int issuerCountryCodeNum;

        public Builder() {
            this.amount = "3000";
            this.installmentConfigId = "635319343";
            this.installmentConfigType = "MERCHANT";
            this.issuerId = "6024d33321db3aa7f1d27b40";
            this.terminalId = "123";
            this.tenure = 3;
            this.merchantCurrencyCode = "HKD";
            this.issuerCurrencyCode = "HKD";
            this.issuerCountryCodeNum = 852;
        }


        public EmiCalRequest.Builder amount(String amount) {
            this.amount = amount;
            return this;
        }

        public EmiCalRequest.Builder installmentConfigId(String installmentConfigId) {
            this.installmentConfigId = installmentConfigId;
            return this;
        }
        public EmiCalRequest.Builder installmentConfigType(String installmentConfigType) {
            this.installmentConfigType = installmentConfigType;
            return this;
        }
        public EmiCalRequest.Builder issuerId(String issuerId) {
            this.issuerId = issuerId;
            return this;
        }
        public EmiCalRequest.Builder terminalId(String terminalId) {
            this.terminalId = terminalId;
            return this;
        }
        public EmiCalRequest.Builder tenure(int tenure) {
            this.tenure = tenure;
            return this;
        }
        public EmiCalRequest.Builder merchantCurrencyCode(String merchantCurrencyCode) {
            this.merchantCurrencyCode = merchantCurrencyCode;
            return this;
        }
        public EmiCalRequest.Builder issuerCurrencyCode(String issuerCurrencyCode) {
            this.issuerCurrencyCode = issuerCurrencyCode;
            return this;
        }
        public EmiCalRequest.Builder issuerCountryCodeNum(int issuerCountryCodeNum) {
            this.issuerCountryCodeNum = issuerCountryCodeNum;
            return this;
        }
        public EmiCalRequest build(){
            EmiCalRequest emiCalRequest = new EmiCalRequest(this);
            return emiCalRequest;
        }

    }
}
