package com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoMPGS;

import lombok.Getter;
import lombok.Setter;
@Getter
public class AcceptOfferResponse {
    @Setter
    private int statusCode;
    private SerialNumbersRequired serialNumbersRequired;
    private String response;
    private String adjustedAmount;
    private Rejection rejection;
    private String serialNumberRejections;
    private String providerState;
    private String adjustedAmountType;
    private Errors[] errors;


   @Getter
    public class SerialNumbersRequired {
        private String[] skus;
        private String by;
    }
    @Getter
    public static class Errors {
        private String field;
        private String description;
    }

    @Getter
    public class Rejection {
        private String reason;
        private String code;
    }
}

