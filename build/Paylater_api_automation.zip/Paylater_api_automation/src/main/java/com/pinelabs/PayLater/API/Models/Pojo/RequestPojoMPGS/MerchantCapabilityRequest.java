package com.pinelabs.PayLater.API.Models.Pojo.RequestPojoMPGS;

import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.EmiCalculatorRequest;
import lombok.Getter;

@Getter
public class MerchantCapabilityRequest {
    private String merchantCountry;

    public MerchantCapabilityRequest(MerchantCapabilityRequest.Builder builder) {
        this.merchantCountry = builder.merchantCountry;
    }
        public static class Builder {
        public String merchantCountry;
        public String reqType;

        public Builder() {
            //These are to assign default values to the request body
            this.merchantCountry = "HK";
        }

        public MerchantCapabilityRequest.Builder merchantCountry(String merchantCountry) {
            this.merchantCountry = merchantCountry;
            return this;
        }

        public MerchantCapabilityRequest build() {
            MerchantCapabilityRequest merchantCapabilityRequest = new MerchantCapabilityRequest(this);
            return merchantCapabilityRequest;
        }
    }
}
