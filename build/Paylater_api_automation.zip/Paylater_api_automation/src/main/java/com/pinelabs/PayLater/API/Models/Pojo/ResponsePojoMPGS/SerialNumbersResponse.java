package com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoMPGS;

import lombok.Getter;
import lombok.Setter;

@Getter
public class SerialNumbersResponse {
    @Setter
    private int statusCode;
    private String response;
    private String rejection;
    private SerialNumberRejections[] serialNumberRejections;
    private String providerState;
    private Errors[] errors;

    @Getter
    public static class SerialNumberRejections {
        private String reason;

        private String serialNumber;
    }

    @Getter
    public static class Errors {
        private String field;
        private String description;
    }
}
