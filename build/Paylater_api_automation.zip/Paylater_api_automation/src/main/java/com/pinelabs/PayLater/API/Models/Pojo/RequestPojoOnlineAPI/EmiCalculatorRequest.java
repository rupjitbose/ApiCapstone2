package com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI;

import lombok.Getter;

@Getter
public class EmiCalculatorRequest {

    public double amount;
    public String installmentConfigId;
    public String installmentConfigType;
    public String issuerId;
    public String terminalId;
    public int tenure;
    public String merchantCurrencyCode;
    public String issuerCurrencyCode;
    public int issuerCountryCodeNum;

    public EmiCalculatorRequest(EmiCalculatorRequest.Builder builder) {

        this.amount = builder.amount;
        this.installmentConfigId = builder.installmentConfigId;
        this.installmentConfigType = builder.installmentConfigType;
        this.issuerId = builder.issuerId;
        this.terminalId = builder.terminalId;
        this.tenure = builder.tenure;
        this.merchantCurrencyCode = builder.merchantCurrencyCode;
        this.issuerCurrencyCode = builder.issuerCurrencyCode;
        this.issuerCountryCodeNum = builder.issuerCountryCodeNum;
    }

    public static class Builder {
        public double amount;
        public String installmentConfigId;
        public String installmentConfigType;
        public String issuerId;
        public String terminalId;
        public int tenure;
        public String merchantCurrencyCode;
        public String issuerCurrencyCode;
        public int issuerCountryCodeNum;

        public Builder() {
            //These are to assign default values to the request body
            this.amount = 3000.00;
            this.installmentConfigId = "635319343";
            this.installmentConfigType = "MERCHANT";
            this.issuerId = "6024d33321db3aa7f1d27b40";
            this.terminalId = "123";
            this.tenure = 3;
            this.merchantCurrencyCode = "HKD";
            this.issuerCurrencyCode = "HKD";
            this.issuerCountryCodeNum = 344;
        }

        public EmiCalculatorRequest.Builder amount(double amount) {
            this.amount = amount;
            return this;
        }

        public EmiCalculatorRequest.Builder installmentConfigId(String installmentConfigId) {
            this.installmentConfigId = installmentConfigId;
            return this;
        }
        public EmiCalculatorRequest.Builder installmentConfigType(String installmentConfigType) {
            this.installmentConfigType = installmentConfigType;
            return this;
        }
        public EmiCalculatorRequest.Builder issuerId(String issuerId) {
            this.issuerId = issuerId;
            return this;
        }
        public EmiCalculatorRequest.Builder terminalId(String terminalId) {
            this.terminalId = terminalId;
            return this;
        }
        public EmiCalculatorRequest.Builder tenure(int tenure) {
            this.tenure = tenure;
            return this;
        }
        public EmiCalculatorRequest.Builder merchantCurrencyCode(String merchantCurrencyCode) {
            this.merchantCurrencyCode = merchantCurrencyCode;
            return this;
        }
        public EmiCalculatorRequest.Builder issuerCurrencyCode(String issuerCurrencyCode) {
            this.issuerCurrencyCode = issuerCurrencyCode;
            return this;
        }
        public EmiCalculatorRequest.Builder issuerCountryCodeNum(int issuerCountryCodeNum) {
            this.issuerCountryCodeNum = issuerCountryCodeNum;
            return this;
        }
        public EmiCalculatorRequest build(){
            EmiCalculatorRequest emiCalculatorRequest = new EmiCalculatorRequest(this);
            return emiCalculatorRequest;
        }

    }
}

