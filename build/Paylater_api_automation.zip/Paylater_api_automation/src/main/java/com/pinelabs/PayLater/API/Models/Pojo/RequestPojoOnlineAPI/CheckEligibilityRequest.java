package com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CheckEligibilityRequest {

    public String merchantId;
    public Integer cardNumber;
    public IppData ippData;

    public CheckEligibilityRequest(CheckEligibilityRequest.Builder builder) {
        this.merchantId = builder.merchantId;
        this.cardNumber=builder.cardNumber;
        this.ippData=builder.ippData;
        this.ippData.product=builder.product;
    }

    @Getter
    @Setter
    public static class Product{
        public String productCode;
        public String brandId;
        public double productAmount;
        public int quantity;
    }
    @Getter
    @Setter
    public static class IppData{
        public String issuerId;
        public int tenure;
        public double totalAmount;
        public String schemeId;
        public String programType;
        public Product product;
    }


    public static class Builder{

        public String merchantId;
        public Integer cardNumber;
        public CheckEligibilityRequest.Product product=new CheckEligibilityRequest.Product();
        public CheckEligibilityRequest.IppData ippData=new CheckEligibilityRequest.IppData();

        public Builder(){
            this.product.productAmount=856.50;
            this.product.productCode="";
            this.product.quantity=1;
            this.product.brandId="";
            this.ippData.issuerId="";
            this.ippData.programType="BANK";
            this.ippData.schemeId="";
            this.ippData.totalAmount=500.50;
            this.ippData.tenure=3;
            this.merchantId="63f88c4d333133790a7912ed";
            this.cardNumber=12345678;
        }

        public CheckEligibilityRequest.Builder productAmount(double productAmount){
            this.product.productAmount=productAmount;
            return this;
        }
        public CheckEligibilityRequest.Builder quantity(int quantity){
            this.product.quantity=quantity;
            return this;
        }
        public CheckEligibilityRequest.Builder productCode(String productCode){
            this.product.productCode=productCode;
            return this;
        }

        public CheckEligibilityRequest.Builder brandId(String brandId){
            this.product.brandId=brandId;
            return this;
        }

        public CheckEligibilityRequest.Builder issuerId(String issuerId){
            this.ippData.issuerId=issuerId;
            return this;
        }
        public CheckEligibilityRequest.Builder programType(String programType){
            this.ippData.programType=programType;
            return this;
        }

        public CheckEligibilityRequest.Builder schemeId(String schemeId){
            this.ippData.schemeId=schemeId;
            return this;
        }

        public CheckEligibilityRequest.Builder totalAmount(double totalAmount){
            this.ippData.totalAmount=totalAmount;
            return this;
        }
        public CheckEligibilityRequest.Builder tenure(int tenure){
            this.ippData.tenure=tenure;
            return this;
        }

        public CheckEligibilityRequest.Builder merchantId(String merchantId){
            this.merchantId=merchantId;
            return this;
        }

        public CheckEligibilityRequest.Builder cardNumber(Integer cardNumber){
            this.cardNumber=cardNumber;
            return this;
        }

        public CheckEligibilityRequest build(){
            CheckEligibilityRequest checkEligibilityRequest = new CheckEligibilityRequest(this);
            return checkEligibilityRequest;
        }
    }
}
