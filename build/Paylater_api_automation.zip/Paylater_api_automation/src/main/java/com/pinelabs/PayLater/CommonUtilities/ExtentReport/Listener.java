package com.pinelabs.PayLater.CommonUtilities.ExtentReport;

import com.aventstack.extentreports.Status;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import org.testng.IReporter;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

public class Listener implements ITestListener {

    OnlineApiDataPropertiesConfig dataPropertiesConfig=new OnlineApiDataPropertiesConfig();
    private static ExtentReports extentReports;

    public static ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>();

    public void onStart(ITestContext context) {
        String fileName = ExtentReportManager.getReportNameWithTimeStamp();

        String fullReportPath = System.getProperty("user.dir") +File.separator+
                "target"+ File.separator+"OnlineApiAutomation_Reports"+File.separator + fileName;

        try {
            extentReports = ExtentReportManager.createInstance(fullReportPath,
                    "Test API Automation Report: "+dataPropertiesConfig.getEnv()+
                            " ENV", "Test ExecutionReport");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void onFinish(ITestContext context) {
        if (extentReports != null)
            extentReports.flush();
    }

    public void onTestStart(ITestResult result) {
        ExtentTest test = extentReports.createTest(result.getMethod().getRealClass().getSimpleName()
                + " - " + result.getMethod().getMethodName() + " - "
                +result.getMethod().getDescription());
        extentTest.set(test);
    }

    @Override
    public void onTestSuccess(ITestResult iTestResult) {

    }

    public void onTestFailure(ITestResult result) {
        try {
            ExtentReportManager.logFailureDetails(result.getThrowable().getMessage());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        String stackTrace = Arrays.toString(result.getThrowable().getStackTrace());
        stackTrace = stackTrace.replaceAll(",", "<br>");
        String formmatedTrace = "<details>\n" +
                "    <summary>Click Here To See Exception Logs</summary>\n" +
                "    " + stackTrace + "\n" +
                "</details>\n";
        try {
            ExtentReportManager.logExceptionDetails(formmatedTrace);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public void onTestSkipped(ITestResult iTestResult) {
        extentTest.get().log(Status.SKIP,"Test Skipped Due to Validation Error and Will be Retried!");
    }
    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult iTestResult) {

    }
}
