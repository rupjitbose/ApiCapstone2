package com.pinelabs.PayLater.API.Models.Pojo.ResponsePojoOnlineAPI;

import lombok.Getter;
import lombok.Setter;

@Getter
public class RefundApiResponse {
    @Setter
    private int statusCode;
    private String status;
    private String merchantId;
    private long transactionId;
    private int refundId;
    private Errors[] errors;
    @Getter
    public static class Errors {
        private String code;
        private String message;
    }
}
