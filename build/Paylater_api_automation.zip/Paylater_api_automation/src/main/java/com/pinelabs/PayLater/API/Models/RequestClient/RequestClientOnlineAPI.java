package com.pinelabs.PayLater.API.Models.RequestClient;

import com.pinelabs.PayLater.API.Models.Pojo.RequestPojoOnlineAPI.*;
import com.pinelabs.PayLater.API.Helpers.OnlineApiDataPropertiesConfig;
import com.pinelabs.PayLater.CommonUtilities.ExtentReport.ExtentReportManager;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.QueryableRequestSpecification;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.SpecificationQuerier;

public class RequestClientOnlineAPI {
    OnlineApiDataPropertiesConfig dataProperties =new OnlineApiDataPropertiesConfig();
    private RequestSpecification getRequestSpecification(Object body) throws Exception {
        RestAssured.useRelaxedHTTPSValidation();
        RequestSpecification requestSpecification=RestAssured.given()
                .baseUri(dataProperties.getProperty("base-uri"))
                .contentType(ContentType.JSON)
                .body(body);
        return requestSpecification;
    }
    private static void reportLogger(RequestSpecification requestSpecification, Response response) throws Exception {
        printRequestLogInReport(requestSpecification);
        printResponseLogInReport(response);
    }
    private static void printRequestLogInReport(RequestSpecification  requestSpecification) throws Exception {
        QueryableRequestSpecification queryableRequestSpecification = SpecificationQuerier.query(requestSpecification);
        ExtentReportManager.logInfoDetails("Endpoint is " + queryableRequestSpecification.getBaseUri());
        ExtentReportManager.logInfoDetails("Method is " + queryableRequestSpecification.getMethod());
        //ExtentReportManager.logInfoDetails("Headers are ");
        //ExtentReportManager.logHeaders(queryableRequestSpecification.getHeaders().asList());
        ExtentReportManager.logInfoDetails("Request body is ");
        ExtentReportManager.logJson(queryableRequestSpecification.getBody().toString());
    }
    private static void printResponseLogInReport(Response response) throws Exception {
        ExtentReportManager.logInfoDetails("Response status is " + response.getStatusCode());
        ExtentReportManager.logInfoDetails("Response body is ");
        ExtentReportManager.logJson(response.getBody().asString());
    }
    public Response createLoginRequest(LoginApiRequest body) throws Exception {
        RequestSpecification requestSpecification = getRequestSpecification(body);
        Response response = requestSpecification
                    .when().post(dataProperties.getProperty("client-login"));
        response.then();
        return response;
    }
    public Response createIppOfferRequest(IppOfferRequest body,String token) throws Exception {
        RequestSpecification requestSpecification = getRequestSpecification(body).log().body();
        Response response =requestSpecification.header("Authorization","Bearer "+token)
                .when().post(dataProperties.getProperty("ippOffers"));
        response.then().log().body();
        reportLogger(requestSpecification, response);
        return response;
    }
    public Response createTransactionStatusRequest(TransactionStatusRequest body,String token) throws Exception {
        RequestSpecification requestSpecification = getRequestSpecification(body).log().body();
        Response response =requestSpecification.header("Authorization","Bearer "+token)
                .when().post(dataProperties.getProperty("transactionStatus"));
        response.then().log().body();
        reportLogger(requestSpecification, response);
        return response;
    }
    public Response emiCalculatorRequest(EmiCalculatorRequest body, String token) throws Exception {
        RequestSpecification requestSpecification = getRequestSpecification(body).log().body();
        Response response =requestSpecification.header("Authorization","Bearer "+token)
                .when().post(dataProperties.getProperty("emiCalculator"));
        response.then().log().body();
        reportLogger(requestSpecification, response);
        return response;
    }
    public Response checkEligibilityRequest(CheckEligibilityRequest body, String token) throws Exception {
        RequestSpecification requestSpecification = getRequestSpecification(body).log().body();
        Response response =requestSpecification.header("Authorization","Bearer "+token)
                .when().post(dataProperties.getProperty("checkEligibility"));
        response.then().log().body();
        reportLogger(requestSpecification, response);
        return response;
    }
    public Response authCancelRequest(AuthCancelRequest body, String token) throws Exception {
    RequestSpecification requestSpecification = getRequestSpecification(body).log().body();;
    Response response =requestSpecification.header("Authorization","Bearer "+token)
            .when().post(dataProperties.getProperty("authCancel"));
    response.then().log().body();
    reportLogger(requestSpecification, response);
    return response;
    }
    public Response authCaptureRequest(AuthCaptureRequest body, String token) throws Exception {
        RequestSpecification requestSpecification = getRequestSpecification(body).log().body();
        Response response =requestSpecification.header("Authorization","Bearer "+token)
                .when().post(dataProperties.getProperty("transactionStatus"));
        response.then().log().body();
        reportLogger(requestSpecification, response);
        return response;
    }
    public Response refundRequest(RefundApiRequest body, String token) throws Exception {
        RequestSpecification requestSpecification = getRequestSpecification(body).log().body();
        Response response =requestSpecification.header("Authorization","Bearer "+token)
                .when().post(dataProperties.getProperty("refund"));
        response.then().log().body();
        reportLogger(requestSpecification, response);
        return response;
    }
    public Response currencyConversionRequest(MciCurrencyConversionRequest body, String token) throws Exception {
        RequestSpecification requestSpecification = getRequestSpecification(body).log().body();
        Response response =requestSpecification.header("Authorization","Bearer "+token)
                .when().post(dataProperties.getProperty("currencyConversion"));
        response.then().log().body();
        reportLogger(requestSpecification, response);
        return response;
    }


}
