package com.pinelabs.PayLater.API.Helpers;

import org.testng.annotations.Test;

import java.sql.*;

public class PostgresqlConnection {
    OnlineApiDataPropertiesConfig dataProperties =new OnlineApiDataPropertiesConfig();
    public boolean checkInDB(String query) {
        Connection c = null;
        Statement stmt = null;
        int count=0;
        try {
            Class.forName("org.postgresql.Driver");
            c = DriverManager
                    .getConnection(dataProperties.getProperty("TransactDBurl"),
                            dataProperties.getProperty("dbUsername"),
                            dataProperties.getProperty("dbPassword"));
            //System.out.println("DB connected!!!");
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                //rs.getInt(column);
                count++;
            }
            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.out.println("DB not connecting!!!!");
            e.printStackTrace();

            System.err.println(e.getClass().getName()+": "+e.getMessage());
        }
        if (count>=1)
            return true;
        else
            return false;
    }
    public String fetchFromDB(String query) {
        Connection c = null;
        Statement stmt = null;
        String result = null;
        int count=0;
        try {
            Class.forName("org.postgresql.Driver");
            c = DriverManager
                    .getConnection(dataProperties.getProperty("TransactDBurl"),
                            dataProperties.getProperty("dbUsername"),
                            dataProperties.getProperty("dbPassword"));
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                result=rs.getString(1);
                count++;
            }
            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.out.println("DB not connecting!!!!");
            e.printStackTrace();
            System.err.println(e.getClass().getName()+": "+e.getMessage());
        }
        if(count!=0)
            return result;
        else
            return "NO DATA FOUND ERROR";
    }
    @Test
    public void DBConnectionTestCode() {
        Connection c = null;
        Statement stmt = null;
        int count=0;
        try {
            Class.forName("org.postgresql.Driver");
            c = DriverManager
                    .getConnection("jdbc:postgresql://192.168.100.30:5454/testTransactDB",
                            "svcTestMCIReportingTransactDB",
                            "QR&kWP6OL58z!9#d2OT5kl0m");
            System.out.println("DB connected!!!");
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("select * from public.tbl_online_transaction_detail\n" +
                    "limit 1");
            while (rs.next()) {
                //rs.getInt(column);
                count++;
            }
            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.out.println("DB not connecting!!!!");
            e.printStackTrace();
            System.err.println(e.getClass().getName()+": "+e.getMessage());
        }
        System.out.println(count);
    }
    @Test
    public void checkFetchQuery(){
        System.out.println(fetchFromDB("select rrn from public.tbl_online_transaction_detail\n" +
                "where fk_transaction_id=100001023851"));
    }
}


