package com.pinelabs.PayLater.API.Helpers.MpgsEncryption;

public class ConfigPropertyException extends Exception {
    public ConfigPropertyException(String message) {
        super(message);
    }

    public ConfigPropertyException(String message, Throwable throwable) {
        super(message, throwable);
    }
}
