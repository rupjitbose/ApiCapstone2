package com.pinelabs.PayLater.API.Helpers.MpgsEncryption;


import com.pinelabs.PayLater.API.Helpers.ConstantFilePath;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

public class LoadProperties {
    private static final Logger logger = LoggerFactory.getLogger(LoadProperties.class);
    static String defaultPropertiesFile = ConstantFilePath.ENCRYPTMPGS;
    private static Properties confProperties = new Properties();

    public LoadProperties() {
    }

    private static void loadPropFromResource(String fileName) throws FrameworkException {
        try {
            InputStream inputStream = LoadProperties.class.getClassLoader().getResourceAsStream(fileName);
            new FileReader(fileName);
            InputStream inputStream1 = new FileInputStream(fileName);
            confProperties.load(inputStream1);
        } catch (IOException var4) {
            var4.printStackTrace();
            logger.error("Failed  to load prop files -- " + var4);
            throw new FrameworkException("Unable to load or read properties file information", var4);
        }
    }

    public static String readProperty(String Key, String filename) {
        File file = new File(filename);
        Properties prop = new Properties();
        FileInputStream fileInput = null;

        try {
            fileInput = new FileInputStream(file);
        } catch (FileNotFoundException var7) {
            var7.printStackTrace();
            logger.error("Unable to find : " + filename + "---" + var7.getMessage());
        }

        try {
            prop.load(fileInput);
        } catch (IOException var6) {
            var6.printStackTrace();
            logger.error("Failed to load property file : " + filename + "---" + var6.getMessage());
        }

        logger.info("Successfully read property file: " + filename);
        return prop.getProperty(Key);
    }

    public static String readConfigProperty(String key) {
        String value = null;

        try {
            loadPropFromResource(defaultPropertiesFile);
            value = confProperties.getProperty(key);
        } catch (Exception | FrameworkException var3) {
            var3.printStackTrace();
            logger.error("Unable to find property - " + key + " check the properties file---" + var3);
        }

        return value;
    }

    public static HashMap<String, String> loadValuesToMap(String filePath) {
        HashMap propertyValues = new HashMap();

        try {
            File file = new File(filePath);
            Properties props = new Properties();
            FileInputStream fileInput = null;

            try {
                fileInput = new FileInputStream(file);
                props.load(new InputStreamReader(fileInput, Charset.forName("UTF-8")));
            } catch (FileNotFoundException var7) {
                logger.error("Unable to find : " + filePath + "---" + var7.getMessage());
            }

            Iterator var5 = props.entrySet().iterator();

            while(var5.hasNext()) {
                Map.Entry<Object, Object> entry = (Map.Entry)var5.next();
                propertyValues.put((String)entry.getKey(), (String)entry.getValue());
            }
        } catch (Exception var8) {
            var8.printStackTrace();
            logger.error("Failed to load values to hash map" + var8.getMessage());
        }

        return propertyValues;
    }

    public static String getAppUrl() throws FrameworkException, ConfigPropertyException {
        String appUrl = null;
        appUrl = getPropertyValue("appUrl");
        return appUrl;
    }

    public static String getBrowserType() throws FrameworkException, ConfigPropertyException {
        String browserType = null;
        browserType = getPropertyValue("browserType");
        return browserType;
    }

    public static String getMobileBrowserType() throws FrameworkException, ConfigPropertyException {
        String browserType = null;
        browserType = getPropertyValue("mobileBrowserType");
        return browserType;
    }

    public static String getMobileAppType() throws FrameworkException, ConfigPropertyException {
        String appType = null;
        appType = getPropertyValue("appType");
        return appType;
    }

    public static String getPropertyValue(String propertyKey) throws FrameworkException, ConfigPropertyException {
        String propertyValue;
        if (Helper.isNullOrEmpty(System.getProperty(propertyKey))) {
            propertyValue = System.getProperty(propertyKey);
        } else {
            propertyValue = readConfigProperty(propertyKey);
        }

        if (propertyValue == null) {
            throw new ConfigPropertyException("property " + propertyKey + " is missing, please add it as system property or in config.properties files");
        } else {
            return propertyValue;
        }
    }

    public static String getAdminUrl() throws FrameworkException, ConfigPropertyException {
        return getPropertyValue("AdminUrl");
    }

    public static String getDBConnectionUrl() throws FrameworkException, ConfigPropertyException {
        return getPropertyValue("DBConnectionUrl");
    }

    public static String getDBConnectionUrl(String environment) throws FrameworkException, ConfigPropertyException {
        return getPropertyValue(environment + "DBConnectionUrl");
    }

    public static String getDBUserName(String environment) throws FrameworkException, ConfigPropertyException {
        return getPropertyValue(environment + "DBUserName");
    }

    public static String getDBUserName() throws FrameworkException, ConfigPropertyException {
        return getPropertyValue("DBUserName");
    }

    public static String getDBPassword(String environment) throws FrameworkException, ConfigPropertyException {
        return getPropertyValue(environment + "DBPassword");
    }

    public static String getDBPassword() throws FrameworkException, ConfigPropertyException {
        return getPropertyValue("DBPassword");
    }

    public static String getDBName() throws FrameworkException, ConfigPropertyException {
        return getPropertyValue("DBName");
    }

    public static String getAdminUserName() throws FrameworkException, ConfigPropertyException {
        return getPropertyValue("adminUsername");
    }

    public static String getAdminPwd() throws FrameworkException, ConfigPropertyException {
        return getPropertyValue("adminPwd");
    }

    public static int getElementWaitDuration() throws FrameworkException {
        String configValue = readConfigProperty("elementWaitInSeconds").trim();
        return Integer.parseInt(configValue);
    }

    public static String getAppUserName() throws FrameworkException, ConfigPropertyException {
        return getPropertyValue("username");
    }

    public static String getAppPassword() throws FrameworkException, ConfigPropertyException {
        return getPropertyValue("pwd");
    }

    public static String getEnvironmentName() throws FrameworkException, ConfigPropertyException {
        return getPropertyValue("Environment");
    }

    public static String getAPIHost() throws FrameworkException, ConfigPropertyException {
        return getPropertyValue("APIHost");
    }

    public static String getAPIBuildUrl() throws FrameworkException, ConfigPropertyException {
        return getPropertyValue("APIBuildUrl");
    }

    public static String getTestEmailID() throws FrameworkException, ConfigPropertyException {
        return getPropertyValue("TestEmailID");
    }

    public static String getTestEmailPassword() throws FrameworkException, ConfigPropertyException {
        return getPropertyValue("TestEmailPassword");
    }

    public static String getMySqlEnvironment() {
        String dbEnv = null;

        try {
            dbEnv = getPropertyValue("MySQLDBEnvironment");
        } catch (Exception | FrameworkException var2) {
            logger.error("Missing MySQLDBEnvironment property value in system property or in config.properties files.Please add it if incase required");
        }

        return dbEnv;
    }

    public static String getMySqlDBName() {
        String dbName = null;

        try {
            dbName = getPropertyValue("MySQLDBName");
        } catch (Exception | FrameworkException var2) {
            logger.error("Missing MySQLDBName property value in system property or in config.properties files.Please add it if incase required");
        }

        return dbName;
    }

    public static Boolean isPropertyKeyPresent(String keyName) {
        boolean isKeyPresent = false;
        if (confProperties.containsKey(keyName)) {
            isKeyPresent = true;
        }

        return isKeyPresent;
    }
}

